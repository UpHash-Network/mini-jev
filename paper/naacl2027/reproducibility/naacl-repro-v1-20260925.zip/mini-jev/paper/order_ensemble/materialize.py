#!/usr/bin/env python3
"""Reconstruct the existing frozen selection from pinned upstream files.

Unlike prepare, this does not make a new selection, inspect changing Git history,
or overwrite any study receipt. Works from a source archive without .git.
"""
import argparse
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from paper.external_expanded import prepare as original
from paper.order_ensemble.prepare import verify_source


def reconstruct(raw_dir):
    protocol = json.loads((ROOT/'paper/external_expanded/PROTOCOL.json').read_text())
    selection = json.loads((HERE/'SELECTION.json').read_text())
    rows_by_source, specs, indexes = {}, {}, {}
    for spec in protocol['sources']+[protocol['overlap_reference']]+protocol['license_sources']:
        path = raw_dir/spec['file']
        raw = path.read_bytes()
        if len(raw) != spec['bytes'] or original.sha(raw) != spec['sha256']:
            raise ValueError('Pinned source mismatch: '+spec['file'])
        if 'dataset' not in spec:
            continue
        source = (spec['dataset'], spec['split'])
        rows_by_source[source] = [json.loads(line) for line in raw.splitlines() if line.strip()]
        specs[source] = spec
        indexes[source] = {str(row[spec['id_field']]): row for row in rows_by_source[source]}
        if len(indexes[source]) != len(rows_by_source[source]):
            raise ValueError('Duplicate upstream ID')
    components, _ = original.caption_components(rows_by_source['JSTS', 'valid'], rows_by_source['JNLI', 'valid'])
    questions = []
    for reference in selection['items']:
        source = reference['dataset'], reference['split']
        row = indexes[source][reference['original_id']]
        question = original.convert(row, specs[source], protocol['prompts'][source[0]])
        if source[0] == 'JSTS':
            question['group'] = components['JSTS:'+reference['original_id']]
        if original.reference(row, specs[source], question, selection['salt']) != reference:
            raise ValueError('Frozen selected reference differs from reconstruction')
        questions.append(question)
    raw = ''.join(original.canonical(q)+'\n' for q in questions).encode()
    if len(raw) != selection['questions_bytes'] or original.sha(raw) != selection['questions_sha256']:
        raise ValueError('Reconstructed selection bytes differ')
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.resolve().is_relative_to(ROOT):
        parser.error('Question text must stay outside the repository')
    raw = reconstruct(args.raw_dir)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('xb') as stream:
        stream.write(raw)
    rows = verify_source(args.output)
    print(original.canonical({'reconstructed_items': len(rows), 'sha256': original.sha(raw), 'model_calls': 0}))


if __name__ == '__main__':
    main()
