# Positioning the order-ensemble study

Primary sources checked on 2026-09-22. This is a focused positioning note, not a
systematic literature review or a claim that the present experiment is novel.

**Zheng et al., _Large Language Models Are Not Robust Multiple Choice
Selectors_.** In arXiv v4, the permutation-averaging baseline is introduced in
**Section 3.1, Equation (1)**; Section 3.2 concerns probability decomposition.
Their cyclic construction averages prediction distributions using K rather than
K! permutations. Crucially, their formulation keeps option IDs in their default
display order while permuting option contents, thereby changing which ID denotes
each meaning. Their separate PriDe method estimates an option-ID prior; our
study does not implement that method.
[Primary paper, v4](https://arxiv.org/html/2309.03882v4#S3.SS1)

Our requests instead keep every output-token/semantic-key/meaning binding fixed
and move the complete displayed lines. Thus this is an application of an
established averaging idea to a different perturbation, **not a faithful
replication of Zheng et al.'s permutation baseline**, and it cannot establish
removal of option-token priors. An eventual claim of superiority over their
baseline would require implementing and evaluating that baseline with its actual
rebinding semantics under an appropriate comparison protocol.

**Pezeshkpour and Hruschka (2024), _Large Language Models Sensitivity to The Order
of Options in Multiple-Choice Questions_.** This Findings of NAACL paper
documents answer-order sensitivity and investigates how uncertainty among leading
candidates relates to placement effects. It also evaluates mitigation approaches.
This establishes that option-order sensitivity and attempts to reduce it precede
Mini Jev. The authors' explanation of a mechanism should not be treated as proof
that the same mechanism causes every change in our typed-decision setting.
[Primary publication and abstract](https://aclanthology.org/2024.findings-naacl.130/)

The present study's prospective scope is narrower: measure quality, orientation
sensitivity and actual call cost when the candidate-token meanings remain fixed,
including binary probabilities and continuous expectations over an ordinal
0–5 scale. It evaluates three specified checkpoints on newly selected project
evaluation IDs, while disclosing public-development provenance and remaining
source dependencies. Whether its findings amount to a useful contribution
depends on the executed results and subsequent comparisons; the existence of an
averaging implementation alone is insufficient.

Algebraic properties must be distinguished from observations. Averaging every
cyclic rotation is invariant to a change in cyclic starting point. For two
candidates, the two orientations reuse the same two calls. Averaging the unique
dihedral union is invariant to both rotation and reversal. These facts follow
from identical sets of inputs, assuming identical evaluations, and are not
experimental discoveries. For five or six distinct candidates, the two cyclic
orientations are disjoint, so equality of their means is not guaranteed. Quality
against the fixed single-prompt baseline, nonbinary orientation changes, constant
prediction failures and computation cost are empirical outcomes to report.

Improvements of an average probability vector over the *average* member loss can
also follow convexity. The planned baseline comparisons should therefore not be
presented as a discovery of Jensen's inequality, nor should structural stability
be equated with predictive usefulness or calibrated correctness.
