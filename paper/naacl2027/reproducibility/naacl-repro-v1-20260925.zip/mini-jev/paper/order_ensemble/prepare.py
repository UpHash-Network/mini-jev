#!/usr/bin/env python3
"""Select unused evaluation items by fixed ID hashes; never run a model.

Original benchmark text remains in the explicitly external cache. Public records
contain IDs, hashes, gold/group metadata and provenance, not source examples.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from paper.external_expanded import prepare as original
from native_engine import options_for

SALT = "mini-jev-order-ensemble-unused-v1:20260922:"
TARGETS = {"JCoLA:in_domain_valid": 100, "JCoLA:out_of_domain_valid": 100,
           "JSTS:valid": 200, "JCommonsenseQA:valid": 200}
DATASETS = {"JCoLA", "JSTS", "JCommonsenseQA", "JNLI"}
PREFIX_DATASET = {dataset.lower(): dataset for dataset in DATASETS}
PROTOCOL_PATH = ROOT / "paper/external_expanded/PROTOCOL.json"
canonical, sha, sha_object = original.canonical, original.sha, original.sha_object


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def records(raw, path):
    value = json.loads(raw) if path.endswith(".json") else [json.loads(line) for line in raw.splitlines() if line.strip()]
    return value.get("items", []) if isinstance(value, dict) else value


def write_new(path, data):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def git(*arguments, allow_missing=False):
    result = subprocess.run(["git", *arguments], cwd=ROOT, capture_output=True, check=False)
    if result.returncode:
        if allow_missing:
            return None
        raise ValueError("git provenance query failed")
    return result.stdout


def historical_inventory():
    """All reachable historical JSONL/SELECTION blobs, including current copies.

    Rows without recognized upstream dataset IDs are classified as local/other;
    no prediction score or correctness value participates in selection.
    """
    names = set(git("log", "--all", "--format=", "--name-only").decode().splitlines())
    names.update(git("ls-files").decode().splitlines())
    paths = sorted(path for path in names if path and not path.startswith("paper/order_ensemble/")
                   and (path.endswith(".jsonl") or Path(path).name == "SELECTION.json"))
    inventory, blobs, seen = [], {}, set()
    for path in paths:
        versions = git("log", "--all", "--format=%H", "--", path).decode().splitlines()
        for commit in versions:
            blob_raw = git("rev-parse", commit + ":" + path, allow_missing=True)
            if blob_raw is None:
                continue
            blob = blob_raw.decode().strip()
            key = (path, blob)
            if key in seen:
                continue
            seen.add(key)
            raw = git("cat-file", "blob", blob)
            digest = sha(raw)
            inventory.append({"path": path, "git_blob": blob, "sha256": digest, "bytes": len(raw),
                              "observed_at_commit": commit, "origin": "reachable_git_history"})
            blobs[path, digest] = raw
        current = ROOT / path
        if current.is_file():
            raw = current.read_bytes()
            digest = sha(raw)
            if (path, digest) not in blobs:
                inventory.append({"path": path, "git_blob": None, "sha256": digest, "bytes": len(raw),
                                  "origin": "current_working_tree"})
                blobs[path, digest] = raw
    return sorted(inventory, key=lambda x: (x["path"], x["sha256"])), blobs


def upstream_identity(row, path):
    dataset = row.get("dataset")
    identity = row.get("item_id", row.get("id"))
    if isinstance(identity, str) and identity.split(":", 1)[0] in PREFIX_DATASET:
        pieces = identity.split(":")
        if len(pieces) != 3:
            raise ValueError("unexpected upstream experiment ID")
        parsed = PREFIX_DATASET[pieces[0]]
        if dataset is not None and dataset != parsed:
            raise ValueError("inconsistent upstream dataset identity")
        return parsed, pieces[1], pieces[2]
    if dataset in DATASETS and "original_id" in row:
        return dataset, row["split"], str(row["original_id"])
    if "external_pilot/" in path and "sentence_pair_id" in row:
        return "JNLI", "valid", str(row["sentence_pair_id"])
    if dataset in DATASETS:
        raise ValueError("recognized upstream dataset lacks an auditable ID")
    return None


def prior_evaluations(inventory, blobs):
    identities, text_hashes, sources = set(), set(), defaultdict(set)
    summary = []
    for (path, digest), raw in sorted(blobs.items()):
        values = records(raw, path)
        recognized = 0
        for row in values:
            if not isinstance(row, dict):
                raise ValueError("historical record must be an object")
            identity = upstream_identity(row, path)
            if identity is None:
                continue
            identities.add(identity)
            sources[identity].add(path)
            recognized += 1
            text_hashes.update(row.get("text_sha256", []))
            text_hashes.update(row[key] for key in ("sentence1_sha256", "sentence2_sha256") if key in row)
        summary.append({"path": path, "sha256": digest, "rows": len(values), "recognized_upstream_rows": recognized})
    return identities, text_hashes, sources, summary


def audit_availability(raw_dir):
    protocol = load(PROTOCOL_PATH)
    specifications = protocol["sources"] + [protocol["overlap_reference"]]
    raw_sources, raw_records, source_manifest = {}, {}, []
    for spec in specifications + protocol["license_sources"]:
        path = raw_dir / spec["file"]
        raw = path.read_bytes()
        if path.is_symlink() or len(raw) != spec["bytes"] or sha(raw) != spec["sha256"]:
            raise ValueError("cached raw source or license hash mismatch: " + spec["file"])
        source_manifest.append({key: spec[key] for key in ("file", "url", "bytes", "sha256")})
        if "dataset" not in spec:
            continue
        source = spec["dataset"] + ":" + spec["split"]
        rows = [json.loads(line) for line in raw.splitlines() if line.strip()]
        if len({str(row[spec["id_field"]]) for row in rows}) != len(rows):
            raise ValueError("duplicate source IDs")
        raw_sources[source] = rows
        for row in rows:
            raw_records[spec["dataset"], spec["split"], str(row[spec["id_field"]])] = row
    inventory, blobs = historical_inventory()
    prior_ids, prior_texts, prior_owners, history_counts = prior_evaluations(inventory, blobs)
    missing = prior_ids - set(raw_records)
    if missing:
        raise ValueError("prior evaluated upstream IDs are absent from the verified raw cache")
    for identity in prior_ids:
        row = raw_records[identity]
        prior_texts.update(sha(value.encode()) for value in original.source_texts(row, identity[0]))
    # Verify historical original-row digests whenever a record exposes one.
    checked_row_hashes = 0
    for (path, _), raw in blobs.items():
        for row in records(raw, path):
            identity = upstream_identity(row, path)
            if identity and "row_sha256" in row:
                if sha_object(raw_records[identity]) != row["row_sha256"]:
                    raise ValueError("historical selected source row hash mismatch")
                checked_row_hashes += 1
    prior_bibliography = {sha(raw_records[i]["source"].encode()) for i in prior_ids if i[0] == "JCoLA"}
    prior_bibliography_by_split = {split: {sha(raw_records[i]["source"].encode()) for i in prior_ids
                                          if i[0] == "JCoLA" and i[1] == split}
                                   for split in ("in_domain_valid", "out_of_domain_valid")}
    full_bibliography_by_split = {split: {sha(row["source"].encode()) for row in raw_sources["JCoLA:"+split]}
                                  for split in prior_bibliography_by_split}
    components, component_summary = original.caption_components(raw_sources["JSTS:valid"], raw_sources["JNLI:valid"])
    prior_caption_groups = {components[dataset + ":" + identifier] for dataset, _, identifier in prior_ids if dataset in {"JSTS", "JNLI"}}
    prior_images = {image for identity in prior_ids if identity[0] in {"JSTS", "JNLI"}
                    for image in original.caption_images(raw_records[identity]["yjcaptions_id"])}
    available, eligible = {}, []
    for spec in specifications:
        dataset, split = spec["dataset"], spec["split"]
        source = dataset + ":" + split
        rows = raw_sources[source]
        unused, clean, strict = [], [], []
        for row in rows:
            identity = dataset, split, str(row[spec["id_field"]])
            if identity in prior_ids:
                continue
            unused.append(row)
            hashes = {sha(value.encode()) for value in original.source_texts(row, dataset)}
            if hashes & prior_texts:
                continue
            clean.append(row)
            if dataset == "JSTS" and components["JSTS:" + identity[2]] in prior_caption_groups:
                continue
            strict.append(row)
            if source in TARGETS:
                eligible.append((spec, row))
        report = {"available_rows": len(rows), "previously_evaluated_ids": len(rows)-len(unused),
                  "unused_ids": len(unused), "unused_ids_without_prior_exact_query_or_sentence": len(clean),
                  "strict_eligible_rows": len(strict)}
        if dataset == "JCoLA":
            report.update(distinct_eligible_texts=len({sha(row["sentence"].encode()) for row in strict}),
                          eligible_bibliographic_groups=len({sha(row["source"].encode()) for row in strict}),
                          eligible_rows_from_previously_unseen_bibliographic_groups=sum(
                              sha(row["source"].encode()) not in prior_bibliography for row in strict))
        if dataset == "JSTS":
            report.update(no_prior_direct_image_rows=sum(not any(image in prior_images for image in original.caption_images(row["yjcaptions_id"])) for row in clean),
                          strict_distinct_components=len({components["JSTS:"+str(row["sentence_pair_id"])] for row in strict}))
        if dataset == "JCommonsenseQA":
            report["distinct_eligible_questions"] = len({sha(row["question"].encode()) for row in strict})
        available[source] = report
    provenance = {"schema_version": 1, "prior_unique_upstream_ids": len(prior_ids),
                  "prior_unique_ids_by_dataset": dict(sorted(Counter(i[0] for i in prior_ids).items())),
                  "prior_unique_ids_by_dataset_split": dict(sorted(Counter(i[0]+":"+i[1] for i in prior_ids).items())),
                  "prior_unique_query_or_sentence_hashes": len(prior_texts),
                  "historical_row_hash_checks": checked_row_hashes,
                  "history_inventory": inventory, "history_record_counts": history_counts,
                  "source_files": source_manifest, "availability": available,
                  "full_JSTS_JNLI_dev_component_graph": component_summary,
                  "prior_caption_components": len(prior_caption_groups),
                  "prior_source_images": len(prior_images), "prior_bibliographic_groups": len(prior_bibliography),
                  "JCoLA_bibliography_overlap": {
                      "full_dev_group_counts_by_split": {s: len(g) for s, g in full_bibliography_by_split.items()},
                      "full_dev_cross_split_shared_group_count": len(set.intersection(*full_bibliography_by_split.values())),
                      "prior_group_counts_by_split": {s: len(g) for s, g in prior_bibliography_by_split.items()},
                      "prior_cross_split_shared_group_count": len(set.intersection(*prior_bibliography_by_split.values()))},
                  "history_scope": "All reachable Git-history JSONL and SELECTION.json versions plus current tracked copies outside this new study. Recognized JCoLA/JSTS/JCQA/JNLI IDs form the exclusion union; other local/synthetic rows are recorded as outside these upstream ID spaces.",
                  "raw_text_in_public_records": False, "inference_calls": 0}
    return {"protocol": protocol, "specifications": specifications, "eligible": eligible,
            "components": components, "prior_ids": prior_ids, "prior_texts": prior_texts,
            "prior_bibliography": prior_bibliography, "prior_caption_groups": prior_caption_groups,
            "prior_bibliography_by_split": prior_bibliography_by_split,
            "prior_images": prior_images, "provenance": provenance}


def select(audit):
    """One label-independent global rank order with fixed four-source quotas."""
    ordered = sorted(audit["eligible"], key=lambda item: (original.rank(item[1], item[0], SALT),
                                                       item[0]["dataset"], item[0]["split"], original.source_id(item[1], item[0])))
    selected, counts, used_texts, used_components = [], Counter(), set(), set()
    excluded = Counter()
    for spec, row in ordered:
        source = spec["dataset"] + ":" + spec["split"]
        if counts[source] >= TARGETS[source]:
            continue
        texts = {sha(value.encode()) for value in original.source_texts(row, spec["dataset"])}
        if texts & used_texts:
            excluded["exact_text_duplicate_within_new_panel"] += 1
            continue
        group = audit["components"].get("JSTS:"+str(row.get("sentence_pair_id"))) if spec["dataset"] == "JSTS" else None
        if group is not None and group in used_components:
            excluded["caption_component_duplicate_within_new_panel"] += 1
            continue
        question = original.convert(row, spec, audit["protocol"]["prompts"][spec["dataset"]])
        if group is not None:
            question["group"] = group
            used_components.add(group)
        selected.append((spec, row, question))
        used_texts.update(texts)
        counts[source] += 1
    if dict(counts) != TARGETS:
        raise ValueError("Strict disjoint selection cannot fill fixed quotas; do not silently relax constraints")
    return selected, dict(excluded)


def selection_outputs(audit, selected, skipped):
    questions = [question for _, _, question in selected]
    references = [original.reference(row, spec, question, SALT) for spec, row, question in selected]
    data = "".join(canonical(row)+"\n" for row in questions).encode()
    shared_jcola = [r for r in references if r["dataset"] == "JCoLA" and r["bibliographic_source_sha256"] in audit["prior_bibliography"]]
    selected_jcola_groups = {split: {r["bibliographic_source_sha256"] for r in references
                                     if r["dataset"] == "JCoLA" and r["split"] == split}
                              for split in ("in_domain_valid", "out_of_domain_valid")}
    checks = {
        "selected_count": len(questions), "counts_by_source": dict(sorted(Counter(q["dataset"]+":"+q["split"] for q in questions).items())),
        "group_counts": {dataset: len({q["group"] for q in questions if q["dataset"] == dataset}) for dataset in TARGET_DATASETS},
        "prior_id_overlap": sum((r["dataset"], r["split"], r["original_id"]) in audit["prior_ids"] for r in references),
        "prior_exact_query_or_sentence_overlap": sum(bool(set(r["text_sha256"]) & audit["prior_texts"]) for r in references),
        "prior_JSTS_caption_component_overlap": sum(q["group"] in audit["prior_caption_groups"] for q in questions if q["dataset"] == "JSTS"),
        "prior_JSTS_image_overlap": sum(bool(set(r["image_ids"]) & audit["prior_images"]) for r in references if r["dataset"] == "JSTS"),
        "within_panel_repeated_exact_query_or_sentence_values": sum(n > 1 for n in Counter(t for r in references for t in set(r["text_sha256"])).values()),
        "within_panel_repeated_JSTS_components": sum(n > 1 for n in Counter(q["group"] for q in questions if q["dataset"] == "JSTS").values()),
        "JCoLA_rows_sharing_previous_bibliographic_sources": len(shared_jcola),
        "JCoLA_shared_previous_bibliographic_source_groups": len({r["bibliographic_source_sha256"] for r in shared_jcola}),
        "JCoLA_source_group_overlap": {
            "selected_group_counts_by_split": {s: len(g) for s, g in selected_jcola_groups.items()},
            "selected_cross_split_shared_group_count": len(set.intersection(*selected_jcola_groups.values())),
            "new_in_vs_prior_out_group_count": len(selected_jcola_groups["in_domain_valid"] & audit["prior_bibliography_by_split"]["out_of_domain_valid"]),
            "new_out_vs_prior_in_group_count": len(selected_jcola_groups["out_of_domain_valid"] & audit["prior_bibliography_by_split"]["in_domain_valid"])},
        "selection_skips_before_quotas_filled": skipped,
        "inference_calls": 0, "selection_uses_labels_or_predictions": False,
        "model_pretraining_or_posttraining_contamination": "unknown",
    }
    overlap_keys = [key for key in checks if key.startswith("prior_") or key.startswith("within_panel_")]
    if any(checks[key] != 0 for key in overlap_keys):
        raise ValueError("Disjointness assertion failed")
    return data, {"schema_version": 1, "count": len(questions), "questions_sha256": sha(data),
                  "questions_bytes": len(data), "salt": SALT, "targets": TARGETS, "items": references,
                  "selection_audit": checks}


TARGET_DATASETS = ("JCoLA", "JSTS", "JCommonsenseQA")


def verify_source(path):
    """Runner interface: verify external question bytes and every selected row."""
    path = Path(path).resolve()
    if path.is_relative_to(ROOT):
        raise ValueError("benchmark text must remain outside the repository")
    raw, selection = path.read_bytes(), load(HERE / "SELECTION.json")
    if len(raw) != selection["questions_bytes"] or sha(raw) != selection["questions_sha256"]:
        raise ValueError("selected questions hash or byte count mismatch")
    questions = [json.loads(line) for line in raw.splitlines() if line.strip()]
    if len(questions) != selection["count"] or selection["count"] != 600 or len(selection["items"]) != 600:
        raise ValueError("expected exactly 600 questions")
    if len({q["id"] for q in questions}) != 600:
        raise ValueError("duplicate selected IDs")
    for question, item in zip(questions, selection["items"]):
        options_for(question)
        if sha_object(question) != item["question_sha256"]:
            raise ValueError("selected question row digest mismatch")
        for key in ("id", "dataset", "split", "type", "group"):
            if question[key] != item[key]:
                raise ValueError("selected metadata mismatch")
        gold_key = "gold_score" if question["type"] == "score" else "label"
        if question[gold_key] != item[gold_key]:
            raise ValueError("selected gold metadata mismatch")
    if Counter(q["dataset"]+":"+q["split"] for q in questions) != TARGETS:
        raise ValueError("selected source quotas mismatch")
    return questions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("availability", "prepare", "verify"))
    parser.add_argument("--raw-dir", type=Path)
    parser.add_argument("--cache-dir", type=Path, required=True)
    args = parser.parse_args()
    cache = args.cache_dir.resolve()
    if cache.is_relative_to(ROOT) or ROOT.is_relative_to(cache):
        parser.error("cache must be outside and must not contain the repository")
    if args.mode == "verify":
        rows = verify_source(cache / "questions.jsonl")
        print(canonical({"verified": True, "count": len(rows)}))
        return
    if not args.raw_dir:
        parser.error("availability/prepare require --raw-dir")
    audit = audit_availability(args.raw_dir.resolve())
    if args.mode == "availability":
        print(json.dumps({key: value for key, value in audit["provenance"].items()
                          if key not in {"history_inventory", "history_record_counts", "source_files"}}, ensure_ascii=False, indent=2))
        return
    public_files = [HERE / name for name in ("DATA_FREEZE.json", "SELECTION.json", "DATA_PROVENANCE.json")]
    if any(path.exists() for path in public_files) or (cache / "questions.jsonl").exists():
        parser.error("refusing to overwrite a previous selection or prospective freeze")
    cache.mkdir(parents=True, exist_ok=True)
    freeze = {"schema_version": 1, "created_at": datetime.now(timezone.utc).isoformat(),
              "stage": "before_selecting_new_item_IDs_and_before_any_inference", "salt": SALT, "targets": TARGETS,
              "selection_policy": "Sort eligible rows by SHA256(salt+dataset+colon+split+colon+originalID), then dataset/split/ID. Scan this single global rank order and fill fixed four-source quotas. Skip exact source query/sentence reuse across new items and take at most one JSTS full-dev caption component. No labels, predictions, lengths, difficulty or semantic filters enter ranking or eligibility.",
              "exclusions": "Every prior evaluated upstream ID; every exact source query/sentence from prior evaluations; every JSTS component touching prior JSTS or JNLI evaluations in the entire cached JSTS+JNLI public-dev sentence/image graph. JCoLA bibliography-source overlap is permitted and measured.",
              "source_sha256": {"prepare": sha(Path(__file__).read_bytes()), "prior_prepare": sha(Path(original.__file__).read_bytes()),
                                "prior_protocol": sha(PROTOCOL_PATH.read_bytes()), "native_formatter": sha((ROOT / "native_engine.py").read_bytes())},
              "head_at_availability_audit": git("rev-parse", "HEAD").decode().strip(),
              "availability_and_history": audit["provenance"],
              "registration": "Local prospective freeze; not independent public preregistration. Salt fixed and availability reported before selection."}
    write_new(public_files[0], freeze)
    selected, skipped = select(audit)
    data, selection = selection_outputs(audit, selected, skipped)
    with (cache / "questions.jsonl").open("xb") as stream:
        stream.write(data)
    write_new(public_files[1], selection)
    write_new(public_files[2], {"schema_version": 1, "prepared_at": datetime.now(timezone.utc).isoformat(),
              "data_freeze_sha256": sha(public_files[0].read_bytes()), "selection_sha256": sha(public_files[1].read_bytes()),
              "questions_sha256": sha(data), "questions_bytes": len(data), "selection_audit": selection["selection_audit"],
              "licenses": "Derived benchmark metadata follows upstream CC-BY-SA-4.0. Project MIT code does not relicense datasets.",
              "interpretation": "New evaluation IDs and measured exact-text/caption-component disjointness relative to audited project history. These remain public-development data with unknown model training contamination and possible unmeasured semantic dependence. JCoLA source groups are explicitly shared with earlier evaluations.",
              "raw_question_text_published": False, "model_calls": 0})
    verify_source(cache / "questions.jsonl")
    print(json.dumps(selection["selection_audit"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
