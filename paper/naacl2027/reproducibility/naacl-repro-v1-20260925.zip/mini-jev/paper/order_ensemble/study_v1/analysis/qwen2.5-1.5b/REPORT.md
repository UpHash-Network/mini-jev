# Fixed cyclic probability averaging: descriptive results

Model: qwen2.5-1.5b. 4800 / 4800 physical requests are valid, covering 600 source items. 3000 / 3000 derived answers are available.

The primary method averages all K semantic candidate probability vectors with equal weights. All K members must be valid; incomplete pools are unavailable. Single baselines reuse measured pool members. This uses K physical forwards per answer, not one. Dihedral averaging uses the unique union of both pools.

| Dataset | Method | Valid / planned items | Accuracy | MCC | Balanced accuracy | Expected-score MAE | Physical forwards per answer |
|---|---|---:|---:|---:|---:|---:|---:|
| JCoLA | baseline | 200 / 200 | 0.790000 | 0.135453 | 0.511628 | — | 1 |
| JCoLA | reverse_single | 200 / 200 | 0.790000 | 0.135453 | 0.511628 | — | 1 |
| JCoLA | cyclic_forward | 200 / 200 | 0.790000 | 0.135453 | 0.511628 | — | 2 |
| JCoLA | cyclic_reverse | 200 / 200 | 0.790000 | 0.135453 | 0.511628 | — | 2 |
| JCoLA | dihedral | 200 / 200 | 0.790000 | 0.135453 | 0.511628 | — | 2 |
| JCommonsenseQA | baseline | 200 / 200 | 0.800000 | — | — | — | 1 |
| JCommonsenseQA | reverse_single | 200 / 200 | 0.720000 | — | — | — | 1 |
| JCommonsenseQA | cyclic_forward | 200 / 200 | 0.835000 | — | — | — | 5 |
| JCommonsenseQA | cyclic_reverse | 200 / 200 | 0.790000 | — | — | — | 5 |
| JCommonsenseQA | dihedral | 200 / 200 | 0.820000 | — | — | — | 10 |
| JSTS | baseline | 200 / 200 | — | — | — | 1.275832 | 1 |
| JSTS | reverse_single | 200 / 200 | — | — | — | 1.266332 | 1 |
| JSTS | cyclic_forward | 200 / 200 | — | — | — | 1.271610 | 6 |
| JSTS | cyclic_reverse | 200 / 200 | — | — | — | 1.257274 | 6 |
| JSTS | dihedral | 200 / 200 | — | — | — | 1.264413 | 12 |

Paired quality changes compare each method with its fixed single reference on exactly the same complete items. Positive accuracy/MCC differences and negative MAE differences favor the ensemble. Prediction/gold class counts, both JCoLA recalls, ties and JSTS score variance accompany the scalar metrics.

| Dataset | Complete / eligible orientation comparisons | Empirical comparison applicable | Primary change: cyclic minus single | Descriptive group interval |
|---|---:|---|---:|---:|
| JCoLA | 200 / 200 | False | Structural identity | Not an empirical interval |
| JCommonsenseQA | 200 / 200 | True | -0.135000 | [-0.200125, -0.070000] |
| JSTS | 200 / 200 | True | -0.041570 | [-0.049929, -0.033055] |

The classification primary stability outcome is the change in JCQA semantic flip rate. For JSTS it is the change in absolute expected-score difference between orientations. Negative values mean less observed sensitivity. For binary JCoLA, both pools reuse the same two requests, so orientation equality is structural and supplies no empirical robustness evidence. The complete dihedral set is also structurally invariant under rotations/reversal; arbitrary-permutation invariance is not established for K≥4.

Intervals use2000 fixed-seed whole-group percentile replicates and are descriptive, unadjusted for multiple comparisons. JCoLA source groups are sampled within split and stratum totals are normalized to their original item counts. Combined intervals are omitted if a source crosses splits; split intervals remain subject to group-count/undefined-estimate checks. An interval is also omitted if any replicate is undefined. Small groups and remaining source dependence limit interpretation.

New selected IDs are relative to the audited earlier project evaluations; public-development data can still overlap model training. No fitted calibration, significance decision, causal size effect or universal improvement is claimed. Some improvements relative to average member losses/distances follow convexity; this study's primary comparison is against fixed single baselines. Summed per-forward durations describe observed computational work, not separately benchmarked optimized ensemble latency. A stable constant prediction need not discriminate classes; assess class marginals and quality alongside stability.
