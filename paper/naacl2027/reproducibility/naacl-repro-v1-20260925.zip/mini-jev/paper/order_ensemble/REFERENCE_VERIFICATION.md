# Focused primary-source reference verification

Checked 2026-09-22 for the ten references currently cited in
`JOURNAL_MANUSCRIPT_DRAFT.md`. No material bibliographic correction was found.
This is a bounded citation check, not a systematic literature review. No model
was loaded or called, and no manuscript or frozen study file was edited.

| Ref. | Verified bibliographic information | Primary source and cited scope |
|---|---|---|
| 1 | Diogo Almeida; 2026; TypeSafe company blog. The page is dated 15 September 2026. Title matches. | [Introducing System One Models & Jev](https://typesafe.ai/blog/introducing-system-one-models-and-jev). Supports attribution of interface inspiration. The manuscript correctly does not adopt the vendor's performance or calibration claims as independent evidence. |
| 2 | Timo Schick and Hinrich Schütze; EACL 2021; pp. 255–269. Title and author order match. | [ACL record](https://aclanthology.org/2021.eacl-main.20/) and [paper](https://aclanthology.org/2021.eacl-main.20.pdf). Section 3 defines a verbalizer mapping labels to vocabulary words; pp. 256–257 support the narrow label-to-token precedent. PET includes training and masked-LM inference, so it is not cited as an implementation-equivalent frozen causal readout method. |
| 3 | Yanzhao Zhang et al.; 2025; arXiv:2506.05176. Title and first author match; the inspected version is v3, 11 June 2025. | [Author-submitted paper](https://arxiv.org/abs/2506.05176) and [official Qwen3-Reranker-8B model card](https://huggingface.co/Qwen/Qwen3-Reranker-8B). Its `compute_logits` example gathers final-position `yes`/`no` logits, normalizes those two scores and returns the yes probability. This directly supports the manuscript's narrow reranking precedent. It does not establish correctness calibration. |
| 4 | Saibo Geng, Martin Josifoski, Maxime Peyrard and Robert West; EMNLP 2023; pp. 10932–10952. Title and order match. | [ACL publication](https://aclanthology.org/2023.emnlp-main.674/). The abstract describes grammar-controlled output structure and input-dependent grammars. It supports structured-output validity; the manuscript does not claim that valid structure guarantees correct content. |
| 5 | Chuan Guo, Geoff Pleiss, Yu Sun and Kilian Q. Weinberger; ICML 2017; PMLR 70, pp. 1321–1330. Title and order match. | [PMLR publication](https://proceedings.mlr.press/v70/guo17a.html). Supports temperature scaling as a post-processing calibration method. It does not supply calibration results for the present checkpoints or tasks. |
| 6 | Zihao Zhao, Eric Wallace, Shi Feng, Dan Klein and Sameer Singh; ICML 2021; PMLR 139, pp. 12697–12706. Title and order match. | [PMLR publication](https://proceedings.mlr.press/v139/zhao21c.html). Supports contextual calibration using a content-free input to estimate answer bias. The present manuscript correctly says that it fits no such calibration. |
| 7 | Pouya Pezeshkpour and Estevam Hruschka; Findings of NAACL 2024; pp. 2006–2017. Title, including its capitalization, matches the official record. | [ACL publication](https://aclanthology.org/2024.findings-naacl.130/). Supports prior work on option-order sensitivity and mitigation. The manuscript does not turn the authors' proposed mechanism into a demonstrated cause for the present system. |
| 8 | Chujie Zheng, Hao Zhou, Fandong Meng, Jie Zhou and Minlie Huang; ICLR 2024. Title and author order match. | [Official ICLR proceedings](https://proceedings.iclr.cc/paper_files/paper/2024/hash/54dd9e0cff6d9214e20d97eb2a3bae49-Abstract-Conference.html), [proceedings PDF](https://proceedings.iclr.cc/paper_files/paper/2024/file/54dd9e0cff6d9214e20d97eb2a3bae49-Paper-Conference.pdf), and [cited arXiv v4, Section 3.1](https://arxiv.org/html/2309.03882v4#S3.SS1). Equation (1) averages semantic-option probabilities; the following paragraph gives cyclic K-call rather than K!-call enumeration. Option contents move while output IDs retain their normal order. The manuscript accurately distinguishes this rebinding from its fixed token/key/meaning line moves and from PriDe. |
| 9 | Taiga Someya, Yushi Sugimoto and Yohei Oseki; LREC-COLING 2024; pp. 9477–9488. Title and order match. | [ACL publication](https://aclanthology.org/2024.lrec-main.828/). Supports JCoLA's acceptability task, source bibliography and in-/out-of-domain distinction. Actual release versions and selected IDs remain governed by the separately pinned data manifests. |
| 10 | Kentaro Kurihara, Daisuke Kawahara and Tomohide Shibata; LREC 2022; pp. 2957–2966. Title and order match. | [ACL publication](https://aclanthology.org/2022.lrec-1.317/). Supports attribution of the JGLUE benchmark. The paper is not being used as a substitute for the exact versioned dataset provenance. |

Minor optional citation improvements: add the full blog date to reference 1;
add the official ICLR proceedings link to reference 8 while retaining the versioned
arXiv anchor for its equation. Neither is a correction to the current author,
year, title, venue or cited scientific scope.

Retrieval note: direct TypeSafe blog opens returned HTTP 503, but the search tool
returned the primary-domain indexed page with the author and publication date.
OpenReview returned a browser-verification page, so ICLR venue confirmation used
the accessible official proceedings. These access limitations do not concern
the local experiment or the validity of its recorded results.
