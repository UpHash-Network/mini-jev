#!/usr/bin/env python3
"""Plot complete frozen study summaries; never call models or choose methods."""
import argparse
import hashlib
import json
from pathlib import Path

MODELS = ('qwen3.6-35b-a3b', 'qwen2.5-0.5b', 'qwen2.5-1.5b')
LABELS = ['Qwen3.6\n35B-A3B Q4', 'Qwen2.5\n0.5B FP32', 'Qwen2.5\n1.5B FP32']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    summaries, hashes = [], {}
    for model in MODELS:
        path = args.study/'analysis'/model/'SUMMARY.json'
        raw = path.read_bytes()
        summary = json.loads(raw)
        if summary['accounting']['valid_physical_requests'] != 4800 or summary['accounting']['failure_code_counts']:
            raise ValueError('Plot requires the complete no-failure panel; inspect coverage explicitly otherwise')
        summaries.append(summary)
        hashes[model] = hashlib.sha256(raw).hexdigest()
    args.output.mkdir(parents=True, exist_ok=False)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 12,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.titleweight': 'bold', 'svg.fonttype': 'none'})

    def bar_panel(ax, single, cyclic, title, ylabel, percent=False):
        for position, (values, label, color) in enumerate(((single, 'Canonical single', '#356DA3'),
                                                         (cyclic, 'Cyclic average', '#D17635'))):
            locations = [i+(position-.5)*.34 for i in range(3)]
            bars = ax.bar(locations, values, .31, label=label, color=color)
            for bar, value in zip(bars, values):
                ax.annotate(f'{value:.1f}%' if percent else f'{value:.3f}',
                    (bar.get_x()+bar.get_width()/2, value), xytext=(-5 if position == 0 else 5, 4),
                    textcoords='offset points', ha='center', va='bottom', fontsize=11)
        ax.set_xticks(range(3), LABELS)
        ax.set_title(title, pad=14)
        ax.set_ylabel(ylabel)
        upper = max(single+cyclic)*1.23
        ax.set_ylim(0, 110 if percent else max(upper, .05))
        if percent:
            ax.set_yticks([0, 25, 50, 75, 100])
        ax.yaxis.grid(True, alpha=.18)
        ax.set_axisbelow(True)

    fig, axes = plt.subplots(1, 2, figsize=(10, 5.7))
    for ax, dataset, field, title, ylabel, scale in [
            (axes[0], 'JCommonsenseQA', 'label_flip_mean', 'JCQA: answer changes after reversal', 'Changed answers (%)', 100),
            (axes[1], 'JSTS', 'absolute_expected_score_difference_mean', 'JSTS: change in expected score', 'Mean absolute change (0–5 score)', 1)]:
        rows = [next(r for r in s['orientation_stability'] if r['dataset'] == dataset and r['scope'] == 'all') for s in summaries]
        bar_panel(ax, [r['single_'+field]*scale for r in rows], [r['cyclic_'+field]*scale for r in rows], title, ylabel, scale == 100)
    axes[0].legend(loc='upper right', frameon=False)
    fig.suptitle('Display-order sensitivity on 600 new evaluation items', y=.98, fontsize=16)
    fig.text(.5, .035, '200 items/task. Lower is less sensitivity. Binary JCoLA is excluded: its shared-pool invariance is structural.\n'
             'Cyclic answers use K calls (JCQA 5; JSTS 6). Models also differ in family, precision and backend.',
             ha='center', fontsize=11)
    fig.subplots_adjust(left=.07, right=.985, top=.83, bottom=.23, wspace=.3)
    for suffix in ('png', 'svg', 'pdf'):
        fig.savefig(args.output/('orientation_sensitivity.'+suffix), dpi=180)
    plt.close(fig)

    fig, grid = plt.subplots(2, 2, figsize=(9, 8.5))
    axes = list(grid.flat)
    for ax, dataset, field, title, ylabel, scale in [
            (axes[0], 'JCoLA', 'balanced_accuracy', 'JCoLA: class discrimination', 'Balanced accuracy (%)', 100),
            (axes[1], 'JCommonsenseQA', 'accuracy', 'JCQA: answer quality', 'Accuracy (%)', 100),
            (axes[2], 'JSTS', 'expected_score_mae', 'JSTS: score error', 'Expected-score MAE (lower is better)', 1)]:
        method_values = []
        for method in ('baseline', 'cyclic_forward'):
            method_values.append([next(r[field] for r in s['method_quality'] if r['dataset'] == dataset and r['scope'] == 'all' and r['method'] == method)*scale for s in summaries])
        bar_panel(ax, *method_values, title, ylabel, scale == 100)
    axes[0].axhline(50, color='#6B7280', linestyle=':', linewidth=1)
    midpoint_path = args.study.parent/'POSTHOC_MIDPOINT_DIAGNOSTIC.json'
    midpoint = json.loads(midpoint_path.read_text())
    axes[2].axhline(midpoint['mae'], color='#6B7280', linestyle='--', linewidth=1)
    reverse_mae = next(row['expected_score_mae'] for row in summaries[0]['method_quality']
                       if row['dataset'] == 'JSTS' and row['scope'] == 'all' and row['method'] == 'reverse_single')
    axes[0].legend(loc='upper right', frameon=False)
    fig.suptitle('Quality must accompany stability', y=.985, fontsize=16)
    axes[3].axis('off')
    axes[3].text(0, .98,
        'Same 200 items per task.\n'
        'Cyclic answers require 2 / 5 / 6 calls.\n\n'
        'JSTS dashed line: always predict 2.5.\n'
        'Added post hoc after 0.5B collapse.\n\n'
        f'35B reversed single: MAE {reverse_mae:.3f}.\n'
        'Cyclic averaging is not best among\n'
        'all measured display orders.\n\n'
        'JCoLA source groups partly overlap\n'
        'earlier evaluations. Paired intervals\n'
        'and class marginals are in the tables.',
        va='top', fontsize=11, linespacing=1.3, transform=axes[3].transAxes)
    fig.subplots_adjust(left=.09, right=.985, top=.895, bottom=.075, wspace=.37, hspace=.62)
    for suffix in ('png', 'svg', 'pdf'):
        fig.savefig(args.output/('quality_and_cost.'+suffix), dpi=180)
    plt.close(fig)
    manifest = {'matplotlib_version': matplotlib.__version__, 'summary_sha256': hashes,
                'posthoc_midpoint_diagnostic_sha256': hashlib.sha256(midpoint_path.read_bytes()).hexdigest(),
                'plot_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'files_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in args.output.iterdir()},
                'meaning': 'Descriptive paired point estimates, not significance tests; no error bars are fabricated from difference intervals.'}
    (args.output/'MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')


if __name__ == '__main__':
    main()
