# Previously unused evaluation items

This panel contains **600 newly selected evaluation IDs**: JCoLA 100 in-domain
and 100 out-of-domain, JSTS 200, and JCommonsenseQA 200. It is drawn from the same
pinned public-development releases used earlier. It is **not a hidden test set**;
model pretraining/post-training exposure remains unknown.

The private `questions.jsonl` has SHA-256
`0f2f0bc991ee8d32244b304c334929e95570584d0c2d30ef89aabad32f3cb6ff`
and is 443,390 bytes. Its source text remains outside this repository.

## Prospective selection and provenance

`DATA_FREEZE.json` was written before choosing the new item IDs and before any
inference. It records the fixed salt, quotas, source hashes, availability audit
and historical exclusion inventory. `SELECTION.json` records selected IDs,
original labels/continuous scores, hashes and dependence-group metadata.
`DATA_PROVENANCE.json` binds the resulting artifacts to that earlier freeze.
This is a local prospective freeze, not an independent public preregistration.

The salt was fixed before inspecting eligible ranks:

```text
mini-jev-order-ensemble-unused-v1:20260922:
```

Eligible rows are ranked by
`SHA256(salt + dataset + ':' + split + ':' + original_id)`, with dataset/split/ID
tie-breaking. One global rank scan fills the four fixed source quotas. It skips
exact query/sentence reuse between new items and selects at most one row from each
JSTS caption component. Labels, prior predictions, length, difficulty and semantic
judgments are absent from eligibility and ranking. Four ranked candidates were
skipped for within-panel exact-text reuse before the quotas filled.

The audit examined **46 historical/current JSONL or selection-file versions**
from reachable Git history and current tracked copies. Recognized upstream IDs
formed a union of **900 prior IDs**: JCoLA 200, JSTS 200, JCommonsenseQA 200, and
JNLI 300. Repeated evaluations in the matched, robustness and cross-model studies
did not add new upstream IDs. Other tracked local/synthetic rows are inventoried
separately from these upstream ID spaces. Untracked work outside the audited
repository is not claimed to be exhaustively known.

## Availability before selection

| Source | Raw rows | Prior evaluated IDs | Eligible after strict exclusions | Selected |
| --- | ---: | ---: | ---: | ---: |
| JCoLA in-domain | 865 | 100 | 765 | 100 |
| JCoLA out-of-domain | 685 | 100 | 585 | 100 |
| JSTS | 1,457 | 200 | 1,186, in 1,085 components | 200 |
| JCommonsenseQA | 1,119 | 200 | 917 unique questions | 200 |

All prior IDs and exact source query/sentence texts are excluded. For JSTS, the
audit constructs a graph over **all 1,457 JSTS and 2,434 JNLI development rows**,
connecting rows that share an exact sentence or caption image ID. It excludes
every component touching a prior JSTS or JNLI evaluation, including transitive
connections through otherwise unused rows. The complete graph has 2,250
components; 448 touch prior evaluations. This is stricter than checking selected
image IDs alone.

The resulting panel has zero overlap with prior evaluated IDs, exact source
queries/sentences, JSTS images or full caption components. It also has no repeated
exact query/sentence across new items and no repeated JSTS component. Isolated
JCQA candidate words are not treated as independent query texts; general semantic
or ConceptNet-concept overlap is not excluded.

## Dependence groups

The new panel contains **33 JCoLA bibliography groups, 200 JSTS components and
200 JCQA exact-question groups**. JCoLA has 10 groups in-domain and 23 groups
out-of-domain. No bibliography group crosses those two strata in the full raw
release, prior sample or new sample, and no new group overlaps the opposite
prior stratum.

JCoLA bibliography groups are deliberately allowed to overlap earlier
evaluations: **194 of the 200 new rows share 30 earlier source groups**. Strict
source-group novelty could not supply an in-domain sample: all eligible in-domain
rows belong to previously represented bibliography sources. Therefore new IDs
must not be described as independent linguistic domains. Source grouping is a
coarse dependence proxy, and shared constructions or meanings may remain even
between different groups.

## Reproduction and verification

Use the verified raw cache containing the filenames and hashes in
`DATA_FREEZE.json`. No download or inference occurs in these commands.

To reconstruct **this existing selection**, including from an archive without
Git history, use the dedicated materializer. It verifies the pinned raw files,
reconstructs all selected rows and the full caption graph, and requires exact
reference and final-file hash equality. It never overwrites an existing output.

```bash
python3 -m paper.order_ensemble.materialize \
  --raw-dir /absolute/path/to/external-raw-cache \
  --output /absolute/path/to/new-private-cache/questions.jsonl
```

The following are the original prospective-selection commands. Creating a new
selection requires a separate checkout with no existing order-ensemble freeze
files. Because reachable history may grow, a new selection must not be treated
as a replay of this one; use the materializer above for exact replay.

```bash
python3 paper/order_ensemble/prepare.py availability \
  --raw-dir /absolute/path/to/external-raw-cache \
  --cache-dir /absolute/path/to/new-private-cache

python3 paper/order_ensemble/prepare.py prepare \
  --raw-dir /absolute/path/to/external-raw-cache \
  --cache-dir /absolute/path/to/new-private-cache

python3 paper/order_ensemble/prepare.py verify \
  --cache-dir /absolute/path/to/private-cache
```

`prepare` refuses to overwrite an earlier prospective freeze, selection or private
question file. Reproduction requiring fresh files should use a separate checkout
and external cache while retaining the recorded history inventory. The runner
interface is `prepare.verify_source(path)`, returning the 600 rows after byte,
SHA-256, per-question, identity, gold and quota verification.

Source revisions, URLs, raw hashes and license-file hashes are recorded in the
freeze and inherited [external preparation protocol](../external_expanded/PROTOCOL.json).
JGLUE is attributed to Kentaro Kurihara, Daisuke Kawahara and Tomohide Shibata,
Yahoo Japan Corporation and Kawahara Lab, Waseda University; JCoLA is supplied by
[Oseki Lab](https://github.com/osekilab/JCoLA). Upstream data and derived benchmark
metadata follow **CC-BY-SA-4.0**. The project's MIT code license does not relicense
the datasets.
