# Proposed next experiment: supervised, order-augmented residual head

**Status: unexecuted proposal, 2026-09-22.** This document does not amend the frozen order-ensemble experiment. No new training, model loading, feature extraction, test scoring, or test-data download was performed for this proposal. The method and budget below were chosen from the earlier training implementation and data inventory, without inspecting results from the running 14,400-call order-ensemble study. A separate protocol, data audit, implementation review, and pre-inference freeze are required before execution.

The bounded question is: **can supervised training of a small residual output head improve single-forward Japanese multiple-choice decisions and their order sensitivity, beyond an equally trained output-bias control?** Use one already-local Qwen2.5-1.5B-Instruct checkpoint and one external task, JCommonsenseQA. This is an empirical training study, not a proposed new learning algorithm. Success is not guaranteed; a clean negative result remains reportable. It would not establish transfer to Noul/Score, equivalence to Jev, or journal acceptance.

## What the earlier experiment actually did

The historical [training implementation](../../train_head.py), [head runtime](../../head_jev.py), [experiment record](../../results/head/experiment.json), and [training account](../../HEAD_TUNING.md) agree on the following:

- Backbone: Qwen2.5-1.5B-Instruct, revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, with all backbone and original vocabulary-output weights frozen. This is separate from the released frozen 35B GGUF configuration and the EACL demo.
- Learned output: `base_candidate_logits + W * RMS_normalized(last_hidden_state) + b`. Six A–F output slots and hidden size 1,536 give **9,222 trainable parameters**. A separate six-parameter bias-only model supplied a control. No LoRA or backbone fine-tuning occurred.
- Data: 768 project-generated training examples, plus 256 reversed Choice variants in the same training split, totaling 1,024 views. There were 192 development and 192 calibration examples, a 96-example individually AI-authored test, and an already-examined 48-example regression set. Each of train/dev/calibration contains eight families per answer type; semantic configuration groups are split, but generator families/templates are shared.
- Choice reversal in this older formatter changes the mapping from semantic choices to A–F output positions. It is not the fixed-token whole-line display permutation used by the current robustness study. Noul and Score did not receive that augmentation. The augmented objective weights Choice 50%, Noul 25%, Score 25%, whereas development/test are balanced by type.
- Training: CPU full-batch AdamW on cached frozen features; zero initialization; learning rates `{0.001, 0.003}` and squared-correction penalties `{0.01, 0.1}`; up to 120 updates; development NLL checked every five updates, including identity at update zero. Separate calibration NLL chose temperature from 301 values between 0.1 and 10.
- The recorded residual and bias selections both used learning rate 0.003, penalty 0.01, and update 120. The original script saves weights/temperature before opening the 96-example test. All 30 later implementation/reload checks passed, which verifies implementation behavior rather than generalization.

| Historical 96-example test condition | Correct | NLL | Score expected-stage MAE |
|---|---:|---:|---:|
| Frozen model, T=1 | 73/96 | 1.0784 | 0.4257 |
| Residual head, T=1 | 67/96 | 0.8102 | 0.4871 |
| Bias only, T=1 | 74/96 | 1.0139 | 0.4043 |

Thus lower NLL did not imply better top-label accuracy or Score error. Temperature scaling preserved top labels; its separate probability effects do not establish calibration on new domains. The 39→40/48 residual-head regression result is not fresh generalization evidence.

The [data card](../../DATA_CARD.md) clarifies that historical “handwritten,” “manual,” and “independent reviewer” terminology refers to AI agents, not independent human annotation. Exact input/ID checks and scenario grouping do not exclude paraphrase or template leakage. The 96 examples were a small project-authored item holdout at the time, not a family-disjoint or external test; their published outcomes now make them development/regression material for future method design. No cross-task pooled accuracy should be carried into the next study.

The reusable [training CLI](../../training_cli.py) improves input normalization, optional group/family exclusion, immutable output directories, cache checks, checkpoint reload, and provenance. However, it still uses the old prompt/output-slot scheme and deterministic full-batch optimization. Its own recorded warning is correct: **changing `--seed` alone is not an independent stochastic training replication.** It also initially reads test labels for schema/leakage checks; test features/metrics are delayed until checkpoint freezing. It cannot be used unchanged as the new experiment.

## Actual data and compute available now

The following inventory inspected file contents/counts or file existence, not new model outcomes. Raw external data are under `work/paper-external-expanded/raw` outside this worktree.

| Locally present data | Rows | Appropriate future role |
|---|---:|---|
| `data/head_train.jsonl` | 768 | Historical synthetic training/regression |
| `data/head_dev.jsonl`, `head_calibration.jsonl` | 192 each | Already-used development/calibration |
| `data/head_test_ja.jsonl`, `eval_ja.jsonl` | 96 and 48 | Already-evaluated regression; not new final tests |
| Acceptance v2 | 2,400 evaluation + 120 calibration | Published development-related regression material |
| JCoLA public dev | 865 in-domain + 685 out-of-domain | Prior/current selection exposure; source dependencies |
| JSTS public dev | 1,457 | Prior/current selection exposure; caption-component dependencies |
| JNLI public dev | 2,434 | Prior pilot exposure; shares caption provenance with JSTS |
| JCommonsenseQA public dev | 1,119 | 400 IDs already selected across the earlier and running studies |

For JCommonsenseQA, 719 dev IDs remain outside those two selections; excluding normalized exact question reuse leaves 717 unique questions in this bounded audit. That is not a certified semantic holdout and is **not the preferred final-test source**. JSTS remaining-ID counts would overstate eligibility without another full caption-component audit; unused JCoLA rows commonly share bibliography sources. Current-run selections remain reserved even before all their predictions finish.

No external benchmark train/test files were found in the inspected workspace caches or Hugging Face cache. This is a bounded local inventory, not a claim about every location on the computer. Tiny `examples/training/` files are workflow smoke fixtures, not research data.

The pinned [official JGLUE README](https://raw.githubusercontent.com/yahoojapan/JGLUE/6f071c09316baae89c3d083a90985b4b1cb9968c/README.md) lists JCommonsenseQA train/dev/test sizes of **8,939 / 1,119 / 1,118** and says the test set has been released. The proposed data pin is commit `6f071c09316baae89c3d083a90985b4b1cb9968c`.

**HEAD-only evidence:** on 2026-09-22, HTTPS HEAD requests returned 200 for pinned `datasets/jcommonsenseqa-v1.3/train-v1.3.json` (Content-Length 1,879,961) and `test-v1.3.json` (234,437). No bodies were fetched. HTTP existence and README counts do **not** verify labels, exact record counts, licenses applying to every artifact, or overlap. The README states CC BY-SA 4.0; the exact license files, attribution and redistribution scope still require verification when materializing the new data. Source SHA-256 values are not yet established; HTTP ETags are not substituted for them.

The local machine reports Apple M5 Pro and 68,719,476,736 bytes of unified memory. Complete local small-model weight files are present for Qwen2.5-0.5B, Qwen2.5-1.5B and Qwen3-4B; the first two were fully hash-verified in the prior replication preparation. The proposal uses only 1.5B, avoiding model choice based on current outcomes. Its local checkpoint has hidden size 1,536 and 3,087,467,144 bytes of safetensors weights. The existing clean runtime provides Python 3.10.5, PyTorch 2.12.1 and Transformers 4.57.6. All feature extraction must wait until the current serial study finishes; CPU planning does not authorize concurrent model inference.

## One proposed experiment

**Data allocation, before any fitted-model evaluation.** Acquire and checksum official train and test in a new external cache. A mechanical audit may inspect test IDs, schema, labels' existence/type, and text hashes, but must not display test examples, aggregate answer distributions, or model predictions to guide design. Reserve the entire official test prospectively, then determine an eligible previously unevaluated subset using the following fixed policy:

1. Inventory all reachable project evaluation selections and recorded inputs, explicitly including the running order-ensemble selection. Match both upstream `(dataset, split, ID)` and normalized question text; ID alone is insufficient across source splits.
2. Normalize text with NFKC and whitespace collapse. Check exact questions and question-plus-unordered-option-content signatures; retain groups of duplicates and report their counts. Audit cross-split paraphrase/source limitations separately without claiming the exact-match check proves semantic disjointness.
3. Remove official test items exposed in previous project evaluations from the *primary* test, before training, and retain an exclusion manifest. Remove any train candidates overlapping reserved test or prior evaluation questions before fit/dev selection. Do not discard test mistakes or select test items using labels, model scores, length, or difficulty.
4. Require at least 800 eligible final-test questions and at least 2,560 eligible unique train-question groups. If not met, stop and amend the proposal prospectively; do not silently substitute remaining dev data. The upper bound of 1,118 test examples is provisional, not a measured eligible count.
5. Rank eligible training groups by `SHA256("mini-jev-head-supervised-v1:20260922:" + normalized_group_key)`. Select 2,048 groups for parameter fitting and the next 512 for checkpoint/hyperparameter selection; retain one prospectively selected row per exact-question group. No gold balancing or outcome filtering. Official public dev and its prior/current outcomes are not optimization or model-selection inputs.

Write a data-only manifest with all raw file hashes, reserved/eligible/excluded IDs, row and normalized text hashes, split assignments, group membership, exclusion reasons and software hashes. Hash and timestamp it before fitting, separately from the model protocol freeze. This reserves the final test while allowing an auditable leakage check. Supervised fitting uses labels from the **official training split**, not labels from evaluation selections. Test labels are released to the scoring step only after all selected checkpoints and analysis rules are saved. The resulting test is held out from this project's fitting and method selection, conditional on the audit; it remains public and may have been in foundation-model training. It is not a hidden or independently administered test.

**Model and input.** Pin the already-local Qwen2.5-1.5B-Instruct revision and complete artifact hashes. Use the existing repeated typed Choice prompt and fixed `option_0`…`option_4` semantics. Keep A–E token assignments attached to their original option meanings while permuting complete displayed option lines. There is no output-token reassignment. The candidate/context boundary, no-truncation 2,048-token limit, T=1 and exact canonical-key tie rule are common to every condition. Any overlength or invalid case stops preparation for an explicit amendment; it is not silently truncated, replaced or dropped after scoring.

**Trainable object.** Use the earlier residual form with five output rows: `z = z_frozen + W * RMS(h) + b`. This has **7,685 parameters**; a bias-only correction has five. Keep every original model parameter frozen. This is task- and label-scheme-specific; it is not a universal semantic output head. No consistency penalty, LoRA, architecture search, distillation, or additional objective is introduced in this bounded phase.

| Required condition | Fitting views | Test-time model forwards per decision | Purpose |
|---|---|---:|---|
| Frozen direct readout | None | 1 | Exact identity baseline |
| Bias-only correction | Five forward cyclic rotations | 1 | Tests whether output-slot priors explain gains |
| Residual, original order | Original prompt repeated to match five view slots | 1 | Capacity/optimization-matched augmentation ablation |
| Residual, cyclic training | Five forward cyclic rotations | 1 | Primary trained method |
| Frozen cyclic probability average | None | 5 | Established inference-compute comparator; no learning |

The same 2,048 source questions enter every fitted condition. Each minibatch samples source questions, and the loss averages its five view losses within each question before averaging questions. Original-order repetition supplies matched source-question updates, not five independent observations. Reversal is not included in training views. Supervised cross-entropy plus the existing mean squared-logit-correction penalty is used. Cyclic augmentation is established methodology and does not guarantee permutation invariance.

**Minimal repeated fits.** Use three prespecified shuffled-minibatch seeds: `2026092301`, `2026092302`, `2026092303`, with zero-initialized corrections, 64 source questions per batch, AdamW, gradient clipping at 5, and at most 20 epochs. Shuffle question order anew each epoch with each seed; this creates genuine optimization variation absent from the old full-batch code. Use learning rates `{0.001, 0.003}` and penalties `{0.01, 0.1}`. Include epoch zero. For each fitted condition, choose one common hyperparameter/epoch combination by mean development NLL across all three seeds and all five forward views; resolve exact ties by earlier epoch, then smaller learning rate, then smaller penalty. Preserve all three selected checkpoints and report all seeds. Do not choose the best seed, retry a poor seed, or increase the budget after test evaluation.

There is no temperature fitting in this phase: T=1 is explicit for every condition, NLL is a predictive loss, and candidate probabilities are not advertised as calibrated correctness. A separate calibration study would require its own split and scope.

## Measurements, implementation gates and budget

The primary quality contrast is mean per-seed original-order accuracy of cyclic-trained residual versus frozen direct readout. The required capacity contrast compares it with bias-only; the original-order residual ablation tests the value of augmentation. Report all contrasts regardless of sign, plus NLL, class marginals, exact ties, and correct-to-wrong/wrong-to-correct counts. No pooled task accuracy is involved.

For each final-test question, extract all five forward rotations and all five reversed-orientation rotations. These ten orders are distinct for five alternatives. Report per-order quality and the single-forward baseline-to-reversed-original semantic flip rate and total variation for every trained seed. Reversed-orientation orders were not training augmentations, but the same templates occur across new items; call this an item-held-out orientation stress test, not proof of arbitrary-permutation or new-domain generalization. Frozen five-call averaging provides a cost comparator. Do not present its structural cyclic-start invariance as a discovered gain or compare a stable collapsed predictor favorably without its accuracy and class marginals.

Use paired bootstrap resampling of whole exact-question groups on the final test, with 2,000 fixed-seed replicates and descriptive unadjusted 95% intervals. Within each resampled group, retain all orders, conditions and training-seed outputs. The primary estimate first averages per-item correctness over the three seeds. Its bootstrap interval is conditional on those fixed seeds; report seed-specific scores and their spread separately. Three seeds times N questions is **not 3N independent test examples**, and three seeds do not precisely characterize a training-seed population. A single dataset/model supports a narrow empirical conclusion, not universal superiority.

Implement the new extractor/optimizer in a separate directory; do not mutate frozen experimental files. Reuse audited tokenization/request construction where exact contracts match, but do not claim the legacy CLI already implements the new prompt or stochastic training. Before benchmark extraction, synthetic gates must verify frozen/no-grad execution, the zero-head identity, selected candidate logits against stock last-position logits, padding if used, token boundary and semantic maps, and checkpoint round-trip equality. Use fixed prospective logit tolerance `1e-3 + 1e-5*abs(reference)`, probability tolerance `1e-5`, and exact semantic argmax agreement, recording ties and all failures. A failed gate requires a documented implementation amendment before test use, not tolerance tuning against test outputs.

Feature extraction uses one resident model, batch size one initially, eval/inference mode, no KV cache, MPS float32, and synchronized timing. Cache identities must bind full model/tokenizer/source hashes, actual rendered requests, token IDs, view order, runtime, dtype, projection and normalization. A cached head fit may run on CPU. Test hidden states are not extracted until the complete selected checkpoint set and scoring code are frozen. Compute all conditions from the same frozen features; verify the saved head against bounded live train/dev fixtures before releasing test scoring. Do not treat cache lookup or CPU-head time as end-to-end model latency.

At the upper-bound 1,118 test count, extraction requires **10,240 training + 2,560 development + 11,180 test = 23,980 physical model forwards**, plus prospectively listed synthetic gates/warmups/live checks. Reusing features across conditions, hyperparameters and seeds does not create additional model forwards. Raw float32 hidden vectors and five base logits occupy approximately **148 MB**, excluding metadata and file overhead. The fitted correction and optimizer are tiny relative to the model; local 1.5B execution is feasible in principle on the existing machine. No new wall-clock duration, throughput, peak-memory result or speedup is claimed. Record actual resource use and all failed attempts during execution.

This proposal is ready for a future data-materialization and implementation decision, **not ready for a final-test run now**. Label availability, exact data counts and checksums, licensing/attribution, overlap eligibility, and the new optimizer/extractor remain unverified or unimplemented. A later execution must freeze this design independently of the current order-ensemble outcomes and retain any deviation as an explicit prospective amendment.
