# Bounded claim review: completed native and 0.5B evidence

Reviewed the manuscript, report generator and plot generator against the completed
native and 0.5B `SUMMARY.json` files and their passing 99-/115-check audits. No
model was loaded or called. No inference source, manuscript or measured record
was changed. The pending 1.5B predictions were not inspected; only its attempt
start timestamp was read to check the midpoint diagnostic's chronology.

No numerical mismatch or blocking scientific contradiction was found in the
reviewed native/0.5B manuscript results. These three reporting clarifications are
recommended before publishing generated artifacts:

1. **Standalone quality figure omits the stronger native JSTS single prompt.**
   `plot.py:67–84` plots only canonical-single and cyclic-forward MAE, without the
   qualification already present at manuscript lines 454–463 and
   `build_report.py:91–94`. Native reversed-single MAE is 0.47468, below
   cyclic-forward 0.48568 and cyclic-reverse 0.47846. Label the figure's single
   method “canonical single”, and add that reversed-single result as a marker or
   concise caption. This keeps a detached figure from implying that averaging
   improves on all single presentations. The primary fixed-baseline comparison
   itself is valid and should remain unchanged.

2. **Make the added midpoint reference's timing unambiguous.**
   `JOURNAL_MANUSCRIPT_DRAFT.md:507–517` correctly labels the 2.5 reference post hoc,
   but “fixed for the pending 1.5B analysis” should explicitly distinguish analysis
   from inference. The diagnostic was chosen at 02:41:56.809332 UTC; the 1.5B
   attempt began at 02:37:42.979894 UTC. Suggested clarification: chosen after the
   0.5B results and during the 1.5B run, before its analysis, with the same rule
   retained for all checkpoints. It remains post hoc for this study and does not
   amend the frozen primary estimands. The receipt's existing source hashes all
   matched the current files.

3. **Give accuracy/recall interval differences explicit units.**
   `build_report.py:105–110` prints raw fractional differences such as 0.5550 below
   earlier percentage tables, using an English metric name but no unit. Convert
   accuracy, balanced-accuracy and recall differences and endpoints to percentage
   points, or explicitly label them as fractions. Keep MCC dimensionless and
   JSTS MAE in the original 0–5 score units. This is presentation only; the saved
   numeric estimates are correct.

Verified interpretation points:

- Binary cyclic and dihedral orientation equality is structural; JCoLA is excluded
  from the empirical orientation panel and does not receive a robustness interval.
- Native and 0.5B empirical JCQA/JSTS orientation changes, paired intervals,
  classification metrics, MAE, class counts, score variance and rounded summed
  durations match the audited summaries.
- The 0.5B JCoLA 23.0% → 78.5% accuracy change is identified as constant-true
  collapse, with balanced accuracy 0.5 and undefined MCC. Its reduced JCQA
  sensitivity is reported alongside reduced accuracy and increased class skew.
- The 0.5B midpoint comparison is a descriptive point comparison, not a test of
  significance or a fitted reference; the manuscript does not infer discrimination
  from reduced MAE or score variation alone.
- Counts remain 600 source items, 4,800 physical requests/model, 3,000 derived
  answers/model and 11,200 reused member references/model. The planned 14,400
  requests and 22,000-request robustness-series total do not imply that many
  independent questions. The series uses 1,200 unique source items.
- Report generation requires a passing three-model audit; it should run only
  after verified completion. The current manuscript identifies 1.5B as pending.

This was a bounded scientific-reporting review, not an independent review of all
literature, licensing, earlier matched-study measurements or the eventual 1.5B
results. It is an AI review, not human peer review.

## Final three-checkpoint follow-up, 22 September 2026

The review above records the earlier, two-checkpoint state. All three checkpoints
have now completed and passed the combined 283-check computational audit. All
three reporting suggestions are resolved:

1. The finalized quality figure labels the reference **Canonical single** and
   explicitly gives native reversed-single JSTS MAE 0.475, noting that cyclic
   averaging is not best among all measured display orders. Figure source,
   summary and output hashes match `figures_v1/MANIFEST.json`.
2. Manuscript lines 525–530 and the Japanese report explicitly say the midpoint
   was chosen after the 1.5B inference started, before its analysis. The original
   diagnostic receipt is preserved; its completed comparisons retain the same
   fixed 2.5 reference and report point differences without significance claims.
3. The Japanese report labels accuracy, balanced-accuracy and recall differences
   as fractions, with 0.01 equal to one percentage point. The manuscript's
   accuracy differences use explicitly marked percentage points.

A final independent comparison passed 124 exact numeric, formatted-table, hash
and accounting checks between `report_v1/OVERVIEW.json`, `REPORT.ja.md` and all
three audited summaries. Additional checks verified all six completed midpoint
comparisons, the figure manifests, and the 1.5B derived labels. No material
numeric or interpretation mismatch was found. In particular, all five 1.5B
JCoLA methods retain the same 199 true/one false decisions; its observed MCC is
defined, while 717/2,000 bootstrap differences are undefined and the interval is
therefore omitted. Its primary JSTS hard labels are stage 3 throughout, cyclic
expected-score variance is 0.01044, and cyclic MAE exceeds the post-hoc midpoint
MAE by 0.02061. The abstract and Section 8.4 state these results consistently.

The reviewed manuscript SHA-256 is
`807bd2393b8527ae59c2b62eb118434476ecc95c01d7dceca9486f4c75772ae8`.
This follow-up changed only this review note. No frozen source, manuscript,
measurement, report, figure or model was changed or rerun.
