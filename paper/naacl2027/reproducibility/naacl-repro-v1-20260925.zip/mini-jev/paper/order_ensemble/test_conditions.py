"""Synthetic semantic and group-action tests; no dataset or model calls."""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from native_engine import NativeEngine, options_for
from paper.order_ensemble.conditions import _cyclic_orders, orbit_membership, variants


def fixture(kind, count=None):
    row = {"id": "SYNTHETIC-ID-NEVER-IN-PROMPT", "type": kind,
           "state": "これは合成入力です。対象は二番目の候補です。",
           "instructions": "本文に対応する候補を選んでください。"}
    if kind == "noul":
        row.update(criteria={"false": "該当しない", "true": "該当する"}, label="true")
    elif kind == "score":
        row.update(criteria=[f"順序段階{i}の意味" for i in range(count or 6)], gold_score=3.75)
    else:
        row.update(criteria={f"option_{i}": f"候補{i}の意味" for i in range(count or 5)}, label="option_1")
    return row


def lines(request):
    content = request["messages"][1]["content"]
    half = content[:(len(content)-2)//2]
    assert content == half+"\n\n"+half
    return half.rsplit("\n\n選択肢:\n", 1)[1].split("\n\n", 1)[0].splitlines()


class OrderConditionsTest(unittest.TestCase):
    def test_expected_budget_and_two_candidate_deduplication(self):
        self.assertEqual([len(variants(fixture(kind))) for kind in ("noul", "choice", "score")], [2, 10, 12])
        self.assertEqual(sum(len(variants(fixture(k))) for k in ("noul", "choice", "score"))*200, 4800)
        binary = orbit_membership(fixture("noul"))
        self.assertEqual(binary["forward_conditions"], ["forward_0", "forward_1"])
        self.assertEqual(binary["reverse_conditions"], ["forward_1", "forward_0"])
        self.assertEqual(binary["reverse_single_condition"], "forward_1")
        self.assertTrue(binary["structural_orbit_identity"])
        self.assertEqual(binary["condition_aliases"], {"reverse_0": "forward_1", "reverse_1": "forward_0"})

    def test_orbits_are_disjoint_for_three_or_more_candidates(self):
        for k in (3, 5, 6, 26):
            orbit = orbit_membership(k)
            self.assertFalse(set(orbit["forward_conditions"]) & set(orbit["reverse_conditions"]))
            self.assertFalse(orbit["structural_orbit_identity"])
            self.assertEqual(len(orbit["dihedral_conditions"]), 2*k)
            self.assertEqual(orbit["reverse_single_condition"], "reverse_0")

    def test_baseline_is_byte_identical_to_native_formatter(self):
        for kind in ("noul", "choice", "score"):
            row = fixture(kind); before = deepcopy(row)
            formatter = object.__new__(NativeEngine); formatter.prompt_style = "repeat_typed_score"
            opts = options_for(row)
            candidates, prefix, _ = formatter._candidate_spec(row, opts)
            expected = {"messages": formatter._messages(row, opts), "candidates": candidates, "max_input_tokens": 2048}
            if prefix:
                expected["assistant_prefix"] = prefix
            actual = variants(row)
            self.assertEqual(actual[0]["condition"], "forward_0")
            self.assertEqual(actual[0]["request"], expected)
            self.assertEqual(row, before)

    def test_every_order_preserves_token_key_meaning_and_source(self):
        for kind in ("noul", "choice", "score"):
            row = fixture(kind)
            generated = variants(row)
            base = generated[0]
            by_key = dict(zip(base["candidate_keys"], lines(base["request"])))
            for item in generated:
                request = item["request"]
                self.assertEqual(lines(request), [by_key[key] for key in item["display_order"]])
                self.assertEqual(item["candidate_keys"], base["candidate_keys"])
                self.assertEqual(request["candidates"], base["request"]["candidates"])
                self.assertEqual(request.get("assistant_prefix"), base["request"].get("assistant_prefix"))
                self.assertEqual(request["messages"][1]["content"].count(row["state"]), 2)
                self.assertNotIn(row["id"], request["messages"][1]["content"])

    def test_each_semantic_candidate_visits_each_position_once_per_orbit(self):
        for kind in ("noul", "choice", "score"):
            row = fixture(kind); generated = {x["condition"]: x for x in variants(row)}
            orbit = orbit_membership(row)
            for group in ("forward_conditions", "reverse_conditions"):
                visits = Counter((key, pos) for name in orbit[group]
                                 for pos, key in enumerate(generated[name]["display_order"]))
                self.assertEqual(len(visits), orbit["candidate_count"]**2)
                self.assertEqual(set(visits.values()), {1})

    def test_rotated_start_is_same_orbit_algebraically(self):
        for k in (2, 5, 6):
            canonical = tuple(range(k))
            original = set(_cyclic_orders(canonical))
            for start in _cyclic_orders(canonical):
                self.assertEqual(set(_cyclic_orders(start)), original)
            if k >= 3:
                self.assertNotEqual(set(_cyclic_orders(tuple(reversed(canonical)))), original)

    def test_dihedral_is_not_arbitrary_permutation_invariant(self):
        for k in (5, 6):
            order = tuple(range(k))
            d = set(_cyclic_orders(order)) | set(_cyclic_orders(reversed(order)))
            adjacent_swap = (1, 0)+order[2:]
            other = set(_cyclic_orders(adjacent_swap)) | set(_cyclic_orders(reversed(adjacent_swap)))
            self.assertNotEqual(d, other)

    def test_numeric_score_scale_never_reassigned(self):
        row = fixture("score")
        for item in variants(row):
            self.assertEqual(item["candidate_keys"], [str(i) for i in range(6)])
            self.assertEqual(item["request"]["candidates"], [str(i) for i in range(6)])
            self.assertEqual(item["request"]["assistant_prefix"], '{"answer":')
        self.assertEqual(row["gold_score"], 3.75)

    def test_option_like_source_text_is_unchanged(self):
        row = fixture("choice")
        lookalike = "\n\n選択肢:\n"+"\n".join(lines(variants(row)[0]["request"]))+"\n\nEND"
        row["state"] += lookalike
        for item in variants(row):
            self.assertEqual(item["request"]["messages"][1]["content"].count(row["state"]), 2)

    def test_no_shared_mutable_request_and_members_resolve(self):
        row = fixture("choice"); generated = variants(row)
        first_other = deepcopy(generated[1])
        generated[0]["request"]["candidates"][0] = "MUTATED"
        self.assertEqual(generated[1], first_other)
        names = {x["condition"] for x in generated}
        orbit = orbit_membership(row)
        self.assertTrue(set(orbit["forward_conditions"]+orbit["reverse_conditions"]) <= names)

    def test_invalid_counts_and_questions_fail(self):
        for count in (0, 1, 27, True, 2.5):
            with self.assertRaises(ValueError):
                orbit_membership(count)
        row = fixture("noul"); row["criteria"] = {"yes": "はい", "no": "いいえ"}
        with self.assertRaises(ValueError):
            variants(row)


if __name__ == "__main__":
    unittest.main()
