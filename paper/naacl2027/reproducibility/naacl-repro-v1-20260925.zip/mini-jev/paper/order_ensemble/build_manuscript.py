#!/usr/bin/env python3
"""Build a mathematical review PDF from the working Markdown manuscript.

This is a review layout, not a journal/venue template. Python needs only its
standard library; Tectonic supplies XeLaTeX. No artifact marker is invoked here:
the authoring task's marker is managed once by its caller.

Example:
  python build_manuscript.py --output /external/pdf-qa/working-draft.pdf \
    --tectonic /path/to/tectonic

Two optional PNG/PDF figures may be placed at the end of section 8 with paired
--figure PATH --figure-caption TEXT arguments. Ordinary standalone Markdown
images are also supported. --artifact-base may be a *published* repository blob
URL; otherwise relative links resolve to a clickable repository-artifact index.
Source equations remain real TeX. The generated .tex, compiler log and JSON build
receipt accompany the PDF. Every page remains explicitly marked WORKING DRAFT.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from urllib.parse import quote, urlsplit

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEFAULT_EPOCH = int(datetime(2026, 9, 22, tzinfo=timezone.utc).timestamp())
BAD_MATH = re.compile(r"\\(?:input|include|write|openout|read|catcode|csname|special|directlua|immediate|usepackage|documentclass)\b")
INLINE = re.compile(r"(\\\(.+?\\\)|\$[^$\n]+\$|`[^`]+`|\*\*.+?\*\*|\[[^\]]+\]\([^\s)]+\))")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def plain(value):
    # Explicit TeX symbols avoid missing glyphs and Unicode dash ambiguities.
    substitutions = {"−": "-", "–": "--", "—": "---", "‑": "-", "–": "--",
                     "→": r"\ensuremath{\rightarrow}", "≥": r"\ensuremath{\geq}",
                     "≤": r"\ensuremath{\leq}", "×": r"\ensuremath{\times}",
                     "…": r"\ldots{}", "’": "'", "‘": "`", "“": "``", "”": "''",
                     "\u00a0": "~"}
    escaping = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
                "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
                "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
    return "".join(substitutions.get(c, escaping.get(c, c)) for c in value)


def math_tex(value):
    if BAD_MATH.search(value):
        raise ValueError("Non-mathematical command in a math block")
    return value.replace("−", "-").replace("≥", r"\geq ").replace("≤", r"\leq ")


class Renderer:
    def __init__(self, source, output, artifact_base=None, figures=(), captions=(), after_section=8, source_base=None):
        self.source, self.output = source, output
        self.source_base = source_base or source.parent
        self.artifact_base = artifact_base
        self.artifacts = {}
        self.figure_manifest = []
        self.extra_figures = list(zip(figures, captions))
        self.after_section = after_section
        self.figures_inserted = False
        self.table_count = 0
        self.math_count = 0

    def link(self, label, destination):
        if destination.startswith(("https://", "http://", "mailto:")):
            safe = destination.replace("%", r"\%").replace("#", r"\#").replace("&", r"\&")
            return r"\href{" + safe + "}{" + self.inline(label) + "}"
        if destination.startswith("#"):
            return self.inline(label)
        resolved = (self.source_base / destination).resolve()
        if not resolved.is_relative_to(ROOT):
            raise ValueError("Local manuscript links must stay inside the repository")
        relative = resolved.relative_to(ROOT).as_posix()
        if self.artifact_base:
            return self.link(label, self.artifact_base.rstrip("/") + "/" + quote(relative, safe="/"))
        number = self.artifacts.setdefault(relative, len(self.artifacts)+1)
        return r"\hyperlink{artifact-" + str(number) + "}{" + self.inline(label) + r"\,\textsuperscript{A" + str(number) + "}}"

    def inline(self, value):
        pieces, cursor = [], 0
        for match in INLINE.finditer(value):
            pieces.append(plain(value[cursor:match.start()]))
            token = match.group()
            if token.startswith(r"\("):
                pieces.append(math_tex(token))
            elif token.startswith("$"):
                pieces.append(r"\(" + math_tex(token[1:-1]) + r"\)")
            elif token.startswith("`"):
                pieces.append(r"\texttt{" + plain(token[1:-1]) + "}")
            elif token.startswith("**"):
                pieces.append(r"\textbf{" + self.inline(token[2:-2]) + "}")
            else:
                link = re.fullmatch(r"\[([^\]]+)\]\(([^\s)]+)\)", token)
                pieces.append(self.link(*link.groups()))
            cursor = match.end()
        pieces.append(plain(value[cursor:]))
        return "".join(pieces)

    def table(self, rows):
        n = len(rows[0])
        if not 2 <= n <= 7 or any(len(row) != n for row in rows):
            raise ValueError("Tables must contain 2..7 consistently sized columns")
        self.table_count += 1
        proportions = {2: [.62, .38], 3: [.42, .29, .29], 4: [.39, .19, .19, .23],
                       5: [.25, .17, .20, .18, .20], 6: [.22, .14, .14, .18, .16, .16],
                       7: [.205, .102, .145, .102, .115, .17, .161]}[n]
        # Keep compact scientific tables together; genuinely long tables may
        # break between rows with their column headings repeated.
        columns = "".join(r">{\RaggedRight\arraybackslash}p{\dimexpr " + f"{fraction:.6f}" +
                          r"\linewidth-" + f"{2*(n-1)*3.2*fraction:.4f}" + "pt\\relax}"
                          for fraction in proportions)
        header = " & ".join(r"\textbf{" + self.inline(cell) + "}" for cell in rows[0]) + r" \\"
        body = [" & ".join(self.inline(cell) for cell in row) + r" \\" for row in rows[1:]]
        size = r"\fontsize{8.3}{10.6}\selectfont" if n >= 6 else r"\fontsize{9.1}{11.5}\selectfont"
        if len(rows) <= 12:
            return "\n".join([r"\par\addvspace{8pt}\noindent\begin{minipage}{\linewidth}", size,
                r"\setlength{\tabcolsep}{3.2pt}\renewcommand{\arraystretch}{1.2}",
                r"\begin{tabular}{@{}"+columns+r"@{}}", r"\toprule", header, r"\midrule", *body,
                r"\bottomrule\end{tabular}", r"\end{minipage}\par\addvspace{10pt}"])
        return "\n".join([r"\begingroup", size, r"\setlength{\tabcolsep}{3.2pt}",
            r"\renewcommand{\arraystretch}{1.2}", r"\setlength{\LTpre}{8pt}\setlength{\LTpost}{10pt}",
            r"\begin{longtable}{@{}"+columns+r"@{}}", r"\toprule", header, r"\midrule", r"\endfirsthead",
            r"\toprule", header, r"\midrule", r"\endhead", r"\bottomrule\endfoot", *body,
            r"\end{longtable}", r"\endgroup"])

    def figure(self, path, caption):
        path = Path(path).resolve()
        if path.suffix.lower() not in (".png", ".pdf") or not path.is_file():
            raise ValueError("Figures must be existing PNG or PDF files")
        number = len(self.figure_manifest)+1
        name = f"{self.output.stem}-figure-{number}{path.suffix.lower()}"
        target = self.output.parent/name
        if target != path:
            shutil.copyfile(path, target)
        self.figure_manifest.append({"file": name, "source_sha256": sha(path), "caption": caption})
        return "\n".join([r"\begin{figure}[htbp]", r"\centering",
            r"\includegraphics[width=\linewidth,height=.65\textheight,keepaspectratio]{"+name+"}",
            r"\caption{"+self.inline(caption)+"}", r"\label{fig:review-"+str(number)+"}", r"\end{figure}"])

    def insert_figures(self):
        if self.figures_inserted:
            return []
        self.figures_inserted = True
        rendered = [self.figure(path, caption) for path, caption in self.extra_figures]
        return rendered + ([r"\FloatBarrier"] if rendered else [])

    def render(self, text):
        lines = text.splitlines()
        if not lines or not lines[0].startswith("# "):
            raise ValueError("The Markdown manuscript must begin with one title")
        title = lines[0][2:].strip()
        chunks, index, section, references = [], 1, 0, False
        # The manuscript's author block remains the authority for author metadata.
        metadata = []
        while index < len(lines) and not lines[index].startswith("## "):
            metadata.append(lines[index]); index += 1
        raw_meta = "\n".join(metadata).strip()
        author_match = re.search(r"\*\*([^*]+)\*\*", raw_meta)
        author = author_match.group(1) if author_match else ""
        blocks = re.split(r"\n\s*\n", raw_meta)
        chunks += [r"\begin{center}", r"{\fontsize{19}{23}\selectfont\bfseries "+self.inline(title)+r"\par}", r"\vspace{10pt}"]
        for line in blocks[0].splitlines():
            line = line.strip()
            if "@" in line and not line.startswith("["):
                chunks.append(self.link(line, "mailto:"+line)+r"\\")
            else:
                chunks.append(self.inline(line)+r"\\")
        chunks += [r"\end{center}", r"\vspace{3pt}"]
        for block in blocks[1:]:
            chunks.append(r"\begin{draftnotice}"+self.inline(" ".join(block.split()))+r"\end{draftnotice}")
        while index < len(lines):
            line = lines[index].strip()
            if not line:
                index += 1; continue
            if line.startswith("<!--"):
                raise ValueError("Unresolved HTML comment in manuscript")
            if line.startswith("## ") or line.startswith("### "):
                sub = line.startswith("### ")
                heading = line[4:] if sub else line[3:]
                numbered = re.match(r"^(\d+)(?:\.\d+)?\.?\s+", heading)
                if not sub and numbered:
                    new_section = int(numbered.group(1))
                    if section <= self.after_section < new_section:
                        chunks += self.insert_figures()
                    section = new_section
                if numbered:
                    heading = heading[numbered.end():]
                references = heading == "References"
                command = "subsection" if sub else "section"
                if not numbered:
                    command += "*"
                lookahead = next((value.strip() for value in lines[index+1:] if value.strip()), "")
                needed = "14" if lookahead.startswith("|") else "7"
                chunks += [r"\Needspace{"+needed+r"\baselineskip}", "\\"+command+"{"+self.inline(heading)+"}"]
                index += 1; continue
            if line == r"\[":
                math_lines = []
                index += 1
                while index < len(lines) and lines[index].strip() != r"\]":
                    math_lines.append(lines[index]); index += 1
                if index == len(lines):
                    raise ValueError("Unclosed display equation")
                chunks.append(r"\begin{equation}"+"\n"+math_tex("\n".join(math_lines))+"\n"+r"\end{equation}")
                self.math_count += 1
                index += 1; continue
            if line.startswith("|"):
                rows = []
                while index < len(lines) and lines[index].strip().startswith("|"):
                    row = [cell.strip() for cell in lines[index].strip().strip("|").split("|")]
                    if not all(re.fullmatch(r"[:\- ]+", cell) for cell in row):
                        rows.append(row)
                    index += 1
                chunks.append(self.table(rows)); continue
            image = re.fullmatch(r"!\[([^\]]*)\]\(([^\s)]+)\)", line)
            if image:
                chunks.append(self.figure(self.source_base/image.group(2), image.group(1)))
                index += 1; continue
            if line.startswith("```"):
                code = []
                index += 1
                while index < len(lines) and not lines[index].strip().startswith("```"):
                    code.append(lines[index]); index += 1
                if index == len(lines) or any(r"\end{Verbatim}" in row for row in code):
                    raise ValueError("Invalid fenced code block")
                chunks.append(r"\begin{Verbatim}[fontsize=\small,breaklines=true]"+"\n"+"\n".join(code)+"\n"+r"\end{Verbatim}")
                index += 1; continue
            reference = re.match(r"^(\d+)\.\s+", line) if references else None
            if reference:
                number = reference.group(1)
                chunks.append(r"\noindent\hangindent=1.7em\hangafter=1 ["+number+"] "+self.inline(line[reference.end():])+r"\par\smallskip")
                index += 1; continue
            bullet = re.match(r"^[-*]\s+", line)
            if bullet:
                entries = []
                while index < len(lines) and re.match(r"^[-*]\s+", lines[index].strip()):
                    entries.append(r"\item "+self.inline(re.sub(r"^[-*]\s+", "", lines[index].strip())))
                    index += 1
                chunks += [r"\begin{itemize}[leftmargin=1.4em,itemsep=2pt,topsep=3pt]", *entries, r"\end{itemize}"]
                continue
            paragraph = [line]
            index += 1
            while index < len(lines) and lines[index].strip() and not re.match(r"^(?:#|\||!\[|```|\\\[|[-*]\s)", lines[index].strip()):
                paragraph.append(lines[index].strip()); index += 1
            chunks.append(self.inline(" ".join(paragraph))+r"\par")
        chunks += self.insert_figures()
        if self.artifacts:
            chunks += [r"\clearpage\section*{Linked repository artifacts}",
                r"\small These links identify repository artifacts. Paths are relative to the repository root; no local filesystem paths are embedded.",
                r"\begingroup\fontsize{8}{9.5}\selectfont\setlength{\parskip}{0pt}",
                r"\begin{description}[leftmargin=2.5em,labelwidth=2.2em,itemsep=1pt,parsep=0pt,topsep=4pt]"]
            for path, number in self.artifacts.items():
                chunks.append(r"\item[A"+str(number)+r"] \hypertarget{artifact-"+str(number)+r"}{}\nolinkurl{"+path+"}")
            chunks += [r"\end{description}\endgroup"]
        return title, author, "\n\n".join(chunks)


PREAMBLE = r"""\documentclass[10pt,a4paper]{article}
\usepackage[margin=22mm,top=20mm,bottom=22mm,headheight=15pt,headsep=8mm]{geometry}
\usepackage{fontspec}
\setmainfont[BoldFont=lmroman10-bold.otf,ItalicFont=lmroman10-italic.otf,BoldItalicFont=lmroman10-bolditalic.otf]{lmroman10-regular.otf}
\setsansfont[BoldFont=lmsans10-bold.otf,ItalicFont=lmsans10-oblique.otf]{lmsans10-regular.otf}
\setmonofont[Scale=MatchLowercase]{lmmono10-regular.otf}
\usepackage{amsmath,amssymb,booktabs,longtable,array,ragged2e,graphicx,caption,enumitem,fvextra}
\usepackage{xcolor,fancyhdr,titlesec,needspace,microtype,placeins}
\definecolor{ink}{HTML}{183449}
\definecolor{linkblue}{HTML}{245C7D}
\usepackage[unicode,colorlinks=true,linkcolor=linkblue,urlcolor=linkblue,citecolor=linkblue,bookmarksopen=true]{hyperref}
\usepackage{xurl}
\hypersetup{pdfcreator={Mini Jev review builder / Tectonic},pdfsubject={Working empirical manuscript; not peer reviewed or submitted}}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\scriptsize\sffamily\color{ink}MINI JEV / TYPED DECISION READOUT}
\fancyhead[R]{\scriptsize\sffamily WORKING DRAFT}
\fancyfoot[L]{\scriptsize\sffamily Review layout / not a venue submission template}
\fancyfoot[R]{\scriptsize\sffamily\thepage}
\renewcommand{\headrulewidth}{.35pt}\renewcommand{\footrulewidth}{0pt}
\titleformat{\section}{\large\bfseries\color{ink}}{\thesection}{.65em}{}
\titleformat{\subsection}{\normalsize\bfseries\color{ink}}{\thesubsection}{.65em}{}
\titlespacing*{\section}{0pt}{13pt}{6pt}\titlespacing*{\subsection}{0pt}{10pt}{4pt}
\setlength{\parindent}{0pt}\setlength{\parskip}{5pt plus1pt minus1pt}
\setlength{\emergencystretch}{2em}\linespread{1.055}
\widowpenalty=10000\clubpenalty=10000
\captionsetup{font=small,labelfont=bf,justification=raggedright,singlelinecheck=false}
\newenvironment{draftnotice}{\begingroup\small\color{ink}\setlength{\parskip}{3pt}\hrule\vspace{5pt}}{\par\vspace{5pt}\hrule\endgroup\vspace{7pt}}
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--source", type=Path, default=HERE/"JOURNAL_MANUSCRIPT_DRAFT.md")
    parser.add_argument("--source-base", type=Path, help="Resolve relative links/images here when --source is an external immutable snapshot")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tectonic", default=shutil.which("tectonic") or "tectonic")
    parser.add_argument("--artifact-base", help="Published HTTPS repository blob base URL; otherwise use an internal artifact index")
    parser.add_argument("--figure", type=Path, action="append", default=[])
    parser.add_argument("--figure-caption", action="append", default=[])
    parser.add_argument("--figures-after-section", type=int, default=8)
    parser.add_argument("--source-date-epoch", type=int, default=DEFAULT_EPOCH)
    parser.add_argument("--only-cached", action="store_true", help="For reproducible offline rebuilds after TeX resources are cached")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    if output.suffix.lower() != ".pdf":
        parser.error("--output must name a PDF")
    if len(args.figure) != len(args.figure_caption) or len(args.figure) > 2:
        parser.error("Supply a caption per optional figure, with at most two figures")
    if args.artifact_base and urlsplit(args.artifact_base).scheme != "https":
        parser.error("--artifact-base must be an HTTPS URL")
    if output.exists() and not args.force:
        parser.error("Output already exists; choose a new path or explicitly use --force")
    output.parent.mkdir(parents=True, exist_ok=True)
    renderer = Renderer(source, output, args.artifact_base, args.figure, args.figure_caption, args.figures_after_section,
                        args.source_base.resolve() if args.source_base else None)
    source_bytes = source.read_bytes()
    source_digest = hashlib.sha256(source_bytes).hexdigest()
    content = source_bytes.decode("utf-8")
    title, author, body = renderer.render(content)
    tex = output.with_suffix(".tex")
    tex.write_text(PREAMBLE + "\n" + r"\hypersetup{pdftitle={"+plain(title)+"},pdfauthor={"+plain(author)+"}}\n"+
                   r"\begin{document}"+"\n"+body+"\n"+r"\end{document}"+"\n", encoding="utf-8")
    executable = shutil.which(args.tectonic) or str(Path(args.tectonic).resolve())
    command = [executable, "--untrusted", "--keep-logs", "--keep-intermediates", "--outdir", str(output.parent)]
    if args.only_cached:
        command.append("--only-cached")
    command.append(str(tex))
    env = dict(os.environ, SOURCE_DATE_EPOCH=str(args.source_date_epoch), FORCE_SOURCE_DATE="1", TZ="UTC")
    result = subprocess.run(command, cwd=output.parent, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output.with_suffix(".build.log").write_text(result.stdout, encoding="utf-8")
    if result.returncode or not output.is_file():
        sys.stderr.write(result.stdout)
        raise SystemExit(result.returncode or 1)
    if sha(source) != source_digest:
        raise RuntimeError("Manuscript changed while compiling; preserve this attempt and rebuild from a fixed source")
    log = output.with_suffix(".log").read_text(encoding="utf-8", errors="replace")
    overflow = re.findall(r"Overfull \\[hv]box[^\n]*", log)
    receipt = {"schema_version": 1, "status": "working_review_pdf_not_submission_ready",
        "source_sha256": source_digest, "builder_sha256": sha(__file__), "tex_sha256": sha(tex),
        "pdf_sha256": sha(output), "tectonic_sha256": sha(executable),
        "tectonic_version": subprocess.check_output([executable, "--version"], text=True).strip(),
        "source_date_epoch": args.source_date_epoch, "artifact_base": args.artifact_base,
        "tables": renderer.table_count, "display_equations": renderer.math_count,
        "figures": renderer.figure_manifest, "overfull_boxes": overflow,
        "pending_mentions": len(re.findall(r"\bpending\b", content, re.I)),
        "reproducibility": "Source/build/compiler hashes and fixed SOURCE_DATE_EPOCH; TeX resources must also match. Inspect rendered pages before delivery."}
    output.with_suffix(".build.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "tables": renderer.table_count, "equations": renderer.math_count,
                      "figures": len(renderer.figure_manifest), "overfull_boxes": overflow}, ensure_ascii=False))


if __name__ == "__main__":
    main()
