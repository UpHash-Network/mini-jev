"""Physical display orders for cyclic probability averaging; no inference.

The candidate-token/semantic-key binding never changes. Full averaging over a
cyclic orbit is invariant to its starting rotation by construction, assuming the
same deterministic evaluations. That invariance is not an empirical discovery.
For K>=3 the reversed orientation has a disjoint cyclic orbit; comparing those
two means is a nontrivial orientation sensitivity test. For K=2 both orbits are
the same two physical requests, so reversal invariance is structural as well.

Dihedral averaging is an optional derived diagnostic over both orientation pools.
It is invariant to rotations AND reversal by construction, not to arbitrary
permutations for K>=4. Downstream analysis must average canonical probabilities,
not logits, and retain missing members rather than average an incomplete orbit.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import string
import sys

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from native_engine import NativeEngine, options_for
from paper.journal_robustness.conditions import _replace_option_lines

MAX_INPUT_TOKENS = 2048
AVERAGING_RULE = "uniform_arithmetic_mean_of_canonical_T1_candidate_probabilities"
PRIMARY_METHOD = "cyclic_forward"


def _cyclic_orders(sequence):
    sequence = tuple(sequence)
    return [sequence[i:]+sequence[:i] for i in range(len(sequence))]


def _layout(count):
    if type(count) is not int or not 2 <= count <= 26:
        raise ValueError("require 2 to 26 distinct candidates")
    forward = _cyclic_orders(range(count))
    reverse = _cyclic_orders(reversed(range(count)))
    physical, by_order, aliases = [], {}, {}
    members = {"forward": [], "reverse": []}
    for orientation, orders in (("forward", forward), ("reverse", reverse)):
        for index, order in enumerate(orders):
            requested_name = f"{orientation}_{index}"
            if order in by_order:
                name = by_order[order]
                aliases[requested_name] = name
            else:
                name = requested_name
                by_order[order] = name
                physical.append((name, order))
            members[orientation].append(name)
    expected_unique = count if count == 2 else 2*count
    if len(physical) != expected_unique:
        raise ValueError("unexpected cyclic-orbit intersection")
    return physical, members, aliases


def orbit_membership(row):
    """Map conceptual pools to deduplicated physical condition names.

    A question row is the normal interface. An integer count is accepted for
    prospective budget calculations and algebraic tests, without any source text.
    """
    count = row if type(row) is int else len(options_for(row))
    physical, members, aliases = _layout(count)
    return {
        "candidate_count": count,
        "forward_conditions": members["forward"],
        "reverse_conditions": members["reverse"],
        "dihedral_conditions": [name for name, _ in physical],
        "baseline_condition": members["forward"][0],
        "reverse_single_condition": members["reverse"][0],
        "structural_orbit_identity": set(members["forward"]) == set(members["reverse"]),
        "condition_aliases": aliases,
    }


def variants(row):
    """Return unique calls, with semantic display order and unchanged token keys.

    Each record contains condition, request, candidate_keys, display_order. The
    latter is a semantic-key list, while candidate_keys always follows the native
    candidate-token vector in its original canonical order. Input gold/IDs and
    all other evaluation metadata never enter the request formatter.
    """
    options = options_for(row)
    keys = [key for key, _ in options]
    formatter = object.__new__(NativeEngine)
    formatter.prompt_style = "repeat_typed_score"
    candidates, prefix, value_kind = formatter._candidate_spec(row, options)
    base = {"messages": formatter._messages(row, options), "candidates": candidates,
            "max_input_tokens": MAX_INPUT_TOKENS}
    if prefix:
        base["assistant_prefix"] = prefix
    if value_kind == "number":
        lines = [f"{token}: {meaning}" for token, (_, meaning) in zip(candidates, options)]
    else:
        lines = [f"{token}. {key}: {meaning}" for token, (key, meaning) in zip(candidates, options)]
    physical, _, _ = _layout(len(options))
    result = []
    for condition, order in physical:
        request = deepcopy(base) if condition == "forward_0" else _replace_option_lines(
            base, lines, [lines[i] for i in order])
        result.append({"condition": condition, "request": request,
                       "candidate_keys": list(keys), "display_order": [keys[i] for i in order]})
    return result
