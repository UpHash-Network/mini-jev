"""Synthetic, no-model tests of ensemble arithmetic and measurement accounting."""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("order_ensemble_analysis", Path(__file__).with_name("analyze.py"))
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
MODEL = "qwen3.6-35b-a3b"


def fixture(dataset="JCoLA", item="synthetic-1", start=0, vectors=None, group="group1", split="in_domain_valid"):
    keys = ["false", "true"] if dataset == "JCoLA" else [f"option_{i}" for i in range(5)] if dataset == "JCommonsenseQA" else [str(i) for i in range(6)]
    kind = "noul" if dataset == "JCoLA" else "choice" if dataset == "JCommonsenseQA" else "score"
    common = dict(item_id=item, dataset=dataset, split=split, group=group, type=kind,
                  canonical_key_order=keys, candidate_keys=keys)
    if kind == "score":
        common.update(gold_score=2.7, score_values={str(i): i for i in range(6)})
    else:
        common["gold_label"] = keys[-1]
    names = [f"forward_{i}" for i in range(len(keys))]
    if len(keys) > 2:
        names += [f"reverse_{i}" for i in range(len(keys))]
    schedule, rows, by_name = [], [], {}
    for offset, name in enumerate(names):
        index = start+offset
        orientation, rotation = name.split("_")
        base = keys if orientation == "forward" else list(reversed(keys))
        rotation = int(rotation)
        probabilities = vectors[name] if vectors and name in vectors else {key: 1/len(keys) for key in keys}
        answer = a.typed_answer(probabilities, keys, kind, common.get("score_values"))
        meta = dict(common, request_index=index, condition=name, display_order=base[rotation:]+base[:rotation],
                    candidate_tokens=[chr(65+i) for i in range(len(keys))], request_sha256=hashlib.sha256(name.encode()).hexdigest())
        schedule.append(meta)
        rows.append(dict(meta, model_key=MODEL, backend="llama.cpp", logits=[math.log(probabilities[k]) if probabilities[k] else -1000 for k in keys],
                         probabilities=probabilities, label=answer["label"], typed_value=answer["typed_value"],
                         temperature=1.0, input_tokens=100, output_tokens=0, latency_ms=2.0, model_ms=1.0,
                         candidate_ids=list(range(len(keys))), native_decode_count=1, native_total_decode_count=index+4,
                         state_cleared=True, thinking_enabled=False, error=None))
        by_name[name] = index
    forward = [by_name[f"forward_{i}"] for i in range(len(keys))]
    reverse = list(reversed(forward)) if len(keys) == 2 else [by_name[f"reverse_{i}"] for i in range(len(keys))]
    ensemble = dict(common, forward_request_indices=forward, reverse_request_indices=reverse,
                    baseline_request_index=forward[0], reverse_single_request_index=reverse[0],
                    structural_orbit_identity=len(keys) == 2)
    return rows, schedule, [ensemble]


class EnsembleAnalysisTests(unittest.TestCase):
    def test_average_probabilities_not_logits(self):
        vectors = [{"a": .99, "b": .01}, {"b": .8, "a": .2}, {"a": .2, "b": .8}]
        mean = a.average_probabilities(vectors, ["a", "b"])
        self.assertAlmostEqual(mean["a"], 1.39/3)
        self.assertEqual(a.typed_answer(mean, ["a", "b"], "choice")["label"], "b")
        # Averaging the log-odds instead would select a, a substantively different method.
        self.assertGreater(sum(math.log(v["a"]/v["b"]) for v in vectors), 0)

    def test_tie_order_is_fixed_semantics_not_dictionary_order(self):
        result = a.typed_answer({"a": .5, "z": .5}, ["z", "a"], "choice")
        self.assertEqual(result["label"], "z")
        self.assertEqual(result["tie_keys"], ["z", "a"])

    def test_score_expectation_retains_continuous_gold(self):
        vectors = {f"forward_{i}": {str(k): .75 if k == 2 else .25 if k == 3 else 0 for k in range(6)} for i in range(6)}
        rows, schedule, maps = fixture("JSTS", vectors=vectors)
        result = a.analyze(rows, schedule, maps, MODEL, replicates=20)
        q = next(r for r in result["method_quality"] if r["scope"] == "all" and r["method"] == "cyclic_forward")
        self.assertAlmostEqual(q["expected_score_mae"], .45)
        self.assertAlmostEqual(q["hard_stage_mae"], .7)
        self.assertEqual(q["expected_score_variance_across_items"], 0)
        self.assertNotIn("accuracy", q)

    def test_binary_identity_is_structural_and_calls_are_not_double_counted(self):
        vectors = {"forward_0": {"false": .9, "true": .1}, "forward_1": {"false": .1, "true": .9}}
        rows, schedule, maps = fixture(vectors=vectors)
        result = a.analyze(rows, schedule, maps, MODEL, replicates=20)
        account = result["summary"]["accounting"]
        self.assertEqual(account["valid_physical_requests"], 2)
        self.assertEqual(account["valid_actual_call_count"], 2)
        self.assertEqual(account["valid_derived_answers"], 5)
        self.assertEqual(account["logical_member_references_all_derived_answers"], 8)
        stability = result["summary"]["orientation_stability"][0]
        self.assertFalse(stability["empirical_orientation_stability_applicable"])
        self.assertIsNone(stability["bootstrap"])
        self.assertEqual(stability["single_flip_count"], 1)
        self.assertEqual(stability["cyclic_flip_count"], 0)
        cyclic = [r for r in result["derived_answers"] if r["method"] in ("cyclic_forward", "cyclic_reverse", "dihedral")]
        self.assertTrue(all(r["probabilities"] == {"false": .5, "true": .5} for r in cyclic))

    def test_incomplete_pool_is_not_averaged_with_fewer_calls(self):
        rows, schedule, maps = fixture("JCommonsenseQA")
        rows = [r for r in rows if r["condition"] != "forward_1"]
        result = a.analyze(rows, schedule, maps, MODEL, replicates=20)
        self.assertEqual(result["summary"]["accounting"]["valid_physical_requests"], 9)
        self.assertEqual(result["summary"]["accounting"]["valid_derived_answers"], 3)
        names = {r["method"] for r in result["derived_answers"]}
        self.assertEqual(names, {"baseline", "reverse_single", "cyclic_reverse"})
        primary = next(r for r in result["summary"]["quality_comparisons"] if r["role"] == "primary")
        self.assertEqual(primary["n_complete_pairs"], 0)
        self.assertEqual(primary["n_incomplete_pairs"], 1)

    def test_duplicates_and_inference_errors_retained_without_error_text(self):
        rows, schedule, maps = fixture()
        rows[1]["error"] = "PRIVATE BENCHMARK TEXT"
        result = a.analyze(rows+[copy.deepcopy(rows[0])], schedule, maps, MODEL, replicates=20)
        counts = result["summary"]["accounting"]["request_status_counts"]
        self.assertEqual(counts, {"duplicate_prediction_index": 1, "inference_error": 1})
        self.assertEqual(result["summary"]["accounting"]["valid_derived_answers"], 0)
        self.assertNotIn("PRIVATE BENCHMARK TEXT", json.dumps(result))

    def test_rotation_map_must_match_scheduled_physical_display(self):
        rows, schedule, maps = fixture("JCommonsenseQA")
        maps[0]["forward_request_indices"][1:3] = reversed(maps[0]["forward_request_indices"][1:3])
        result = a.analyze(rows, schedule, maps, MODEL, replicates=20)
        self.assertEqual(result["summary"]["accounting"]["valid_derived_answers"], 0)
        self.assertIn("map_rotation_or_condition_mismatch", str(result["failures"]))

    def test_nonbinary_orbits_cannot_reuse_same_physical_calls(self):
        _, _, maps = fixture("JCommonsenseQA")
        maps[0]["reverse_request_indices"] = list(maps[0]["forward_request_indices"])
        with self.assertRaisesRegex(ValueError, "disjoint"):
            a.ensemble_members(maps[0])

    def test_constant_prediction_quality_is_not_competence(self):
        records = [dict(type="noul", dataset="JCoLA", label="true", gold_label=gold, group=str(i), tie_keys=["true"])
                   for i, gold in enumerate(["true"]*8+["false"]*2)]
        q = a.quality(records)
        self.assertEqual(q["accuracy"], .8)
        self.assertEqual(q["balanced_accuracy"], .5)
        self.assertEqual(q["recall_true"], 1)
        self.assertEqual(q["recall_false"], 0)
        self.assertIsNone(q["mcc"])
        self.assertEqual(q["label_counts"], {"true": 10})
        self.assertEqual(q["gold_label_counts"], {"false": 2, "true": 8})

    def test_one_group_does_not_become_many_independent_items(self):
        records = [dict(group="one", delta=1.0) for _ in range(200)]
        result = a.cluster_intervals(records, lambda r:r["group"], lambda r:{"n":1,"delta_sum":r["delta"]}, a.quality_difference_from_sums, "one-group", replicates=50)
        self.assertEqual(result["group_count"], 1)
        self.assertEqual(result["metrics"]["delta"]["estimate"], 1)
        self.assertFalse(result["metrics"]["delta"]["interval_available"])

    def test_stratum_normalization_preserves_original_mixture(self):
        records = []
        for split, group, count, delta in [("in", "a", 1, 1), ("in", "b", 9, 1), ("out", "c", 4, -1), ("out", "d", 6, -1)]:
            records.extend(dict(split=split,group=group,delta=delta) for _ in range(count))
        call = lambda: a.cluster_intervals(records, lambda r:r["group"], lambda r:{"n":1,"delta_sum":r["delta"]}, a.quality_difference_from_sums, "strata", replicates=100, stratum_of=lambda r:r["split"])
        result = call()
        self.assertEqual(result, call())
        self.assertAlmostEqual(result["metrics"]["delta"]["ci95_lower"], 0)
        self.assertAlmostEqual(result["metrics"]["delta"]["ci95_upper"], 0)
        self.assertEqual(result["original_stratum_item_counts"], {"in":10,"out":10})

    def test_shared_cross_split_source_suppresses_combined_interval(self):
        records = [dict(split=s, group=g, delta=i) for s in ("in", "out") for i,g in enumerate(("shared", s+"-only"))]
        result = a.cluster_intervals(records, lambda r:r["group"], lambda r:{"n":1,"delta_sum":r["delta"]}, a.quality_difference_from_sums, "shared", replicates=100, stratum_of=lambda r:r["split"])
        self.assertEqual(result["shared_groups_across_strata"], ["shared"])
        self.assertTrue(result["combined_interval_omitted_for_shared_source"])
        self.assertFalse(result["metrics"]["delta"]["interval_available"])

    def test_paired_quality_direction_and_undefined_mcc_are_explicit(self):
        first = dict(dataset="JCoLA",type="noul",label="true",gold_label="false",group="g",split="s")
        second = dict(first,label="false")
        sums = a.paired_quality_sufficient((first,second))
        delta = a.quality_difference_from_sums(sums)
        self.assertEqual(delta["accuracy_difference"], 1)
        self.assertIsNone(delta["mcc_difference"])
        r1=dict(type="score",typed_value=1,gold_score=2.7)
        r2=dict(type="score",typed_value=2.5,gold_score=2.7)
        self.assertAlmostEqual(a.quality_difference_from_sums(a.paired_quality_sufficient((r1,r2)))["expected_score_mae_difference"], -1.5)

    def test_native_and_transformers_contracts_remain_distinct(self):
        rows, _, _ = fixture()
        row = rows[0]
        self.assertEqual(a.validate_prediction(row), [])
        wrong = dict(row, native_total_decode_count=1)
        self.assertIn("cumulative_native_count_mismatch", a.validate_prediction(wrong))
        transformed = dict(row, model_key="qwen2.5-0.5b", backend="transformers", forward_calls=1, forward_calls_total=28,
                           use_cache=False,past_key_values_returned=False,model_training=False,grad_enabled=False,
                           parameters_require_grad=False,inference_mode_enabled=True,candidate_boundary_verified=True,batch_size=1,logits_to_keep=1)
        for key in ("native_decode_count","native_total_decode_count","state_cleared","thinking_enabled"):
            del transformed[key]
        self.assertEqual(a.validate_prediction(transformed), [])
        transformed["native_decode_count"] = 1
        self.assertIn("fabricated_native_counter_forbidden", a.validate_prediction(transformed))

    def test_cli_uses_frozen_inputs_and_refuses_output_overwrite(self):
        rows, schedule, maps = fixture()
        with tempfile.TemporaryDirectory() as directory:
            study = Path(directory)/"study"
            study.mkdir()
            for name,value in (("SCHEDULE.json",schedule),("ENSEMBLES.json",maps),("TOKENIZATION.json",{})):
                (study/name).write_text(json.dumps(value))
            freeze = {"source_sha256":{"paper/order_ensemble/analyze.py":hashlib.sha256(Path(a.__file__).read_bytes()).hexdigest()},
                      "schedule_sha256":hashlib.sha256(a.canonical(schedule).encode()).hexdigest(),
                      "ensembles_sha256":hashlib.sha256(a.canonical(maps).encode()).hexdigest(),
                      "tokenization_sha256":hashlib.sha256(a.canonical({}).encode()).hexdigest()}
            (study/"FREEZE.json").write_text(json.dumps(freeze))
            folder=study/"results"/MODEL
            folder.mkdir(parents=True)
            (folder/"predictions.jsonl").write_text("\n".join(a.canonical(r) for r in rows))
            output=Path(directory)/"analysis"
            command=[sys.executable,str(Path(a.__file__)),"--study",str(study),"--model-key",MODEL,"--output",str(output)]
            subprocess.run(command,check=True,capture_output=True,text=True)
            result=json.loads((output/"SUMMARY.json").read_text())
            self.assertEqual(result["accounting"]["valid_actual_call_count"],2)
            self.assertTrue((output/"derived_answers.jsonl").exists())
            repeated=subprocess.run(command,capture_output=True,text=True)
            self.assertNotEqual(repeated.returncode,0)
            self.assertIn("FileExistsError",repeated.stderr)


if __name__ == "__main__":
    unittest.main()
