#!/usr/bin/env python3
"""Freeze a new-item order-ensemble study, then execute fixed models serially.

Preparation hashes artifacts and tokenizes requests, but makes no model calls.
Upstream question text and full input token sequences are never written here.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import fcntl
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from native_engine import MODEL_PIN, options_for, _verify_native
from paper.journal_robustness import run as native_run
from paper.journal_robustness import conditions as old_conditions
from paper.journal_robustness.cross_model import engine as adapter
from paper.order_ensemble import conditions

MODELS = ('qwen3.6-35b-a3b', 'qwen2.5-0.5b', 'qwen2.5-1.5b')
SEED = 2026092202


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')


def verify_questions(path):
    from paper.order_ensemble.prepare import verify_source
    return verify_source(path)


def source_hashes(questions):
    paths = [HERE/name for name in ('PROTOCOL.json', 'SELECTION.json', 'DATA_FREEZE.json', 'DATA_PROVENANCE.json', 'prepare.py', 'materialize.py',
             'run.py', 'conditions.py', 'analyze.py', 'test_conditions.py', 'test_analysis.py', 'test_runner.py')]
    paths += [ROOT/name for name in ('native_engine.py', 'native_model.json',
              'paper/external_expanded/prepare.py', 'paper/external_expanded/PROTOCOL.json',
              'paper/external_expanded/SELECTION.json', 'paper/external_pilot/SELECTION.json',
              'paper/journal_robustness/run.py', 'paper/journal_robustness/conditions.py',
              'paper/journal_robustness/PROTOCOL.json', 'paper/journal_robustness/analyze.py',
              'paper/journal_robustness/cross_model/engine.py')]
    return {**{str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in paths},
            'external_questions': sha(questions.read_bytes())}


def build_schedule(questions):
    rows = sorted(verify_questions(questions), key=lambda r: r['id'])
    rng = random.Random(SEED)
    rng.shuffle(rows)
    schedule, requests, ensembles = [], [], []
    for row in rows:
        physical = conditions.variants(row)
        rng.shuffle(physical)
        index_by_condition = {}
        common = {key: row[key] for key in ('dataset', 'split', 'group', 'type')}
        common['item_id'] = row['id']
        common['canonical_key_order'] = [key for key, _ in options_for(row)]
        common['candidate_keys'] = list(common['canonical_key_order'])
        if row['type'] == 'score':
            common.update(gold_score=row['gold_score'], score_values={key: float(key) for key in common['canonical_key_order']})
        else:
            common['gold_label'] = row['label']
        for variant in physical:
            request = variant['request']
            meta = {**common, 'request_index': len(schedule), 'condition': variant['condition'],
                    'candidate_keys': variant['candidate_keys'], 'candidate_tokens': request['candidates'],
                    'display_order': variant['display_order'],
                    'request_sha256': sha(canonical(request).encode()),
                    'source_question_sha256': sha(canonical(row).encode())}
            index_by_condition[variant['condition']] = meta['request_index']
            schedule.append(meta)
            requests.append(request)
        orbit = conditions.orbit_membership(row)
        ensembles.append({**common,
            'forward_request_indices': [index_by_condition[c] for c in orbit['forward_conditions']],
            'reverse_request_indices': [index_by_condition[c] for c in orbit['reverse_conditions']],
            'baseline_request_index': index_by_condition[orbit['baseline_condition']],
            'reverse_single_request_index': index_by_condition[orbit['reverse_single_condition']],
            'structural_orbit_identity': orbit['structural_orbit_identity']})
    protocol = json.loads((HERE/'PROTOCOL.json').read_text())
    if len(rows) != protocol['n_items'] or len(schedule) != protocol['physical_requests_per_model']:
        raise ValueError('Prospective sample or request count differs from protocol')
    if len({(r['item_id'], r['condition']) for r in schedule}) != len(schedule):
        raise ValueError('Duplicate physical request identity')
    return schedule, requests, ensembles


def preparation_material(args):
    schedule, requests, ensembles = build_schedule(args.questions)
    preparers, prepared, artifacts = {}, {}, {}
    for key in MODELS[1:]:
        verified = adapter.verify_snapshot(key, args.cache_root)
        preparers[key] = adapter.TokenizerPreparer(verified)
        prepared[key] = [preparers[key].prepare(r) for r in requests]
        artifacts[key] = verified.manifest()
    for first, second in zip(prepared[MODELS[1]], prepared[MODELS[2]]):
        for key in ('input_ids', 'candidate_ids', 'request_sha256', 'rendered_sha256', 'tokenized_input_sha256'):
            if first[key] != second[key]:
                raise ValueError('Cross-checkpoint full tokenization mismatch: '+key)
    tokenization = {key: [preparers[key].public_metadata(p) for p in prepared[key]] for key in MODELS[1:]}
    native_manifest = args.native_binary.parent.parent/'BUILD.json'
    manifest, hashes, _, aliases = _verify_native(native_manifest, args.native_binary)
    native = {'model_pin': MODEL_PIN, 'manifest_sha256': sha(native_manifest.read_bytes()),
              'files_sha256': hashes, 'aliases': aliases, 'llama_cpp_commit': manifest['llama_cpp_commit']}
    return schedule, requests, ensembles, preparers, prepared, artifacts, tokenization, native


def prepare(args):
    before = source_hashes(args.questions)
    schedule, _, ensembles, _, _, artifacts, tokenization, native = preparation_material(args)
    implementation = adapter.implementation_manifest()
    if before != source_hashes(args.questions):
        raise ValueError('Study changed during preparation')
    args.study.mkdir(parents=True, exist_ok=False)
    write_new(args.study/'SCHEDULE.json', schedule)
    write_new(args.study/'ENSEMBLES.json', ensembles)
    write_new(args.study/'TOKENIZATION.json', tokenization)
    freeze = {'schema_version': 1, 'created_at': now(), 'stage': 'before_any_new_study_model_forward',
        'source_sha256': before, 'n_items': len(ensembles), 'physical_requests_per_model': len(schedule),
        'model_order': list(MODELS), 'seed': SEED, 'n_model_loads': 0, 'n_model_forwards': 0,
        'schedule_sha256': sha(canonical(schedule).encode()), 'ensembles_sha256': sha(canonical(ensembles).encode()),
        'tokenization_sha256': sha(canonical(tokenization).encode()), 'model_artifacts': artifacts,
        'native_artifacts': native, 'implementation_manifest': implementation,
        'dataset_item_counts': dict(Counter(r['dataset'] for r in ensembles)),
        'cross_tokenization_gate': {'full_input_sequences_equal': True, 'candidate_ids_equal': True,
                                  'distinct_single_token_continuations_checked_in_context': True,
                                  'requests_checked': len(schedule)},
        'synthetic_gate_sha256': sha(canonical(adapter.synthetic_gate_requests()).encode()),
        'warmups_sha256': sha(canonical(native_run.WARMUPS).encode()),
        'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'registration': 'Local timestamped freeze; not independently registered or externally preregistered.',
        'data_scope': 'New evaluation IDs relative to audited prior project artifacts; public development data, not a hidden test or pretraining-contamination guarantee.'}
    write_new(args.study/'FREEZE.json', freeze)
    print(canonical({'prepared_items': len(ensembles), 'requests_per_model': len(schedule),
                     'model_forwards': 0, 'freeze_sha256': sha((args.study/'FREEZE.json').read_bytes())}), flush=True)


def assert_sources(args, freeze):
    if source_hashes(args.questions) != freeze['source_sha256']:
        raise ValueError('Frozen study source changed')
    if adapter.implementation_manifest() != freeze['implementation_manifest']:
        raise ValueError('Installed implementation changed after freeze')


def run_one(args, key, freeze, schedule, requests, preparer=None, prepared=None):
    folder = args.study/'results'/key
    folder.mkdir(parents=True, exist_ok=False)
    started = now()
    write_new(folder/'ATTEMPT.json', {'model_key': key, 'started_at': started,
        'expected_requests': len(schedule), 'status': 'started_not_completed',
        'freeze_sha256': sha((args.study/'FREEZE.json').read_bytes())})
    native = key == MODELS[0]
    engine, completed, failed, fatal, closed = None, 0, 0, None, False
    try:
        assert_sources(args, freeze)
        print(canonical({'model_key': key, 'status': 'verifying_and_loading'}), flush=True)
        if native:
            engine = native_run.ResearchEngine(args.model, args.native_binary, log_file=args.log,
                        prompt_style='repeat_typed_score', temperature=1.0, threads=6)
            runtime = {'backend': 'llama.cpp', 'fingerprint': engine.runtime_fingerprint,
                       'fingerprint_data': engine.fingerprint_data, 'native_ready': engine.info}
        else:
            engine = adapter.TransformersResearchEngine(preparer, device='mps')
            runtime = engine.runtime_metadata
        write_new(folder/'RUNTIME.json', runtime)
        assert_sources(args, freeze)
        if not native:
            gate = adapter.validate_forward_parity(engine)
            write_new(folder/'PARITY_GATE.json', gate)
            if not gate['passed'] or gate['fixture_count'] != 12 or gate['forward_calls'] != 24:
                raise RuntimeError('Synthetic implementation parity gate failed')
        with (folder/'warmup.jsonl').open('x', encoding='utf-8') as stream:
            for i, q in enumerate(native_run.WARMUPS):
                if native:
                    answer = engine.decide(q)
                else:
                    request = old_conditions._request(q, options_for(q))
                    p = preparer.prepare(request)
                    answer = engine.evaluate_request(p, [k for k, _ in options_for(q)], q['type'])
                stream.write(canonical({'index': i, 'synthetic_question': q, 'answer': answer})+'\n')
                stream.flush()
        if (engine.total_decode_count if native else engine.forward_calls) != (3 if native else 27):
            raise RuntimeError('Unexpected actual excluded-call count')
        assert_sources(args, freeze)
        began = time.perf_counter()
        with (folder/'predictions.jsonl').open('x', encoding='utf-8') as stream:
            for i, (meta, request) in enumerate(zip(schedule, requests)):
                row = dict(meta, model_key=key, backend='llama.cpp' if native else 'transformers')
                if not native:
                    row.update(preparer.public_metadata(prepared[i]))
                try:
                    if sha(canonical(request).encode()) != meta['request_sha256']:
                        raise ValueError('Request changed in memory')
                    answer = engine.evaluate_request(request if native else prepared[i], meta['candidate_keys'], meta['type'])
                    row.update(answer)
                except Exception as error:
                    row['error'] = type(error).__name__
                    failed += 1
                stream.write(canonical(row)+'\n')
                stream.flush()
                completed += 1
                if row.get('error'):
                    raise RuntimeError('Measured request failed; retaining partial attempt without retry')
                if completed % 100 == 0 or completed == len(schedule):
                    print(canonical({'model_key': key, 'completed': completed, 'total': len(schedule),
                                     'errors': failed, 'elapsed_s': round(time.perf_counter()-began, 1)}), flush=True)
                    assert_sources(args, freeze)
    except BaseException as error:
        fatal = type(error).__name__
        raise
    finally:
        calls = (engine.total_decode_count if native else engine.forward_calls) if engine is not None else 0
        if engine is not None:
            engine.close()
        closed = engine is None or (not engine.ready if native else engine.closed)
        hashes = {p.name: sha(p.read_bytes()) for p in folder.glob('*.json*') if p.is_file()}
        write_new(folder/'COMPLETION.json', {'model_key': key, 'started_at': started, 'finished_at': now(),
            'status': 'completed' if completed == len(schedule) and not fatal else 'incomplete',
            'expected_requests': len(schedule), 'recorded_requests': completed, 'failed_requests': failed,
            'fatal_error_type': fatal, 'actual_calls_including_gate_and_warmup': None if native and fatal else calls,
            'last_observed_cumulative_call_count': calls,
            'call_counter_scope': ('Last verified helper decode count; an unacknowledged failed native invocation may not be observable.'
                if native else 'Actual stock-model invocation attempts, incremented immediately before each model forward.'),
            'call_kind': 'native_decode' if native else 'transformers_forward',
            'expected_excluded_calls': 3 if native else 27, 'model_closed_before_receipt': closed,
            'file_sha256': hashes, 'source_unchanged': source_hashes(args.questions) == freeze['source_sha256'],
            'failure_policy': 'No retry, replacement, overwrite, selection by outcome, or implicit resume.'})


def run(args):
    freeze = json.loads((args.study/'FREEZE.json').read_text())
    assert_sources(args, freeze)
    with (args.study/'RUN.lock').open('a+') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        schedule, requests, ensembles, preparers, prepared, artifacts, tokenization, native = preparation_material(args)
        for filename, value, key in [('SCHEDULE.json', schedule, 'schedule_sha256'),
                ('ENSEMBLES.json', ensembles, 'ensembles_sha256'), ('TOKENIZATION.json', tokenization, 'tokenization_sha256')]:
            if value != json.loads((args.study/filename).read_text()) or sha(canonical(value).encode()) != freeze[key]:
                raise ValueError('Reconstructed frozen artifact differs: '+filename)
        if artifacts != freeze['model_artifacts'] or native != freeze['native_artifacts']:
            raise ValueError('Runtime artifacts differ from freeze')
        keys = (args.model_key,) if args.model_key else MODELS
        for key in keys:
            for previous in MODELS[:MODELS.index(key)]:
                receipt = json.loads((args.study/'results'/previous/'COMPLETION.json').read_text())
                if receipt['status'] != 'completed' or receipt['model_closed_before_receipt'] is not True:
                    raise ValueError('Earlier model must complete and close before later model')
            run_one(args, key, freeze, schedule, requests, preparers.get(key), prepared.get(key))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'run'))
    parser.add_argument('--questions', type=Path, required=True)
    parser.add_argument('--study', type=Path, required=True)
    parser.add_argument('--native-binary', type=Path, required=True)
    parser.add_argument('--model', type=Path)
    parser.add_argument('--log', type=Path)
    parser.add_argument('--cache-root', type=Path, default=adapter.DEFAULT_CACHE_ROOT)
    parser.add_argument('--model-key', choices=MODELS)
    args = parser.parse_args()
    if args.action == 'run' and not (args.model and args.log):
        parser.error('run requires --model and --log')
    if args.log and args.log.resolve().is_relative_to(ROOT):
        parser.error('Native log must stay outside the repository')
    (prepare if args.action == 'prepare' else run)(args)


if __name__ == '__main__':
    main()
