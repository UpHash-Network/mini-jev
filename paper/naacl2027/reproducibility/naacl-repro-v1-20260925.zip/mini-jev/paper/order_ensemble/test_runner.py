"""Model-free integration tests for physical versus logical call accounting."""
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from paper.order_ensemble import run
from paper.journal_robustness.conditions import SOURCE_PROMPTS


def fixture(dataset, index):
    row = {'id': dataset+str(index), 'dataset': dataset, 'split': 'synthetic',
           'group': 'group'+str(index), 'state': 'Synthetic non-benchmark test state.',
           **SOURCE_PROMPTS[dataset]}
    if dataset == 'JCommonsenseQA':
        row['criteria'] = {'option_'+str(i): 'synthetic '+str(i) for i in range(5)}
    if dataset == 'JSTS':
        row['gold_score'] = 2.4
    else:
        row['label'] = 'true' if dataset == 'JCoLA' else 'option_1'
    return row


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.rows = [fixture(d, i) for i, d in enumerate(('JCoLA', 'JCommonsenseQA', 'JSTS'))]
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        (self.folder/'PROTOCOL.json').write_text(json.dumps({'n_items': 3, 'physical_requests_per_model': 24}))

    def build(self, rows=None):
        with patch.object(run, 'HERE', self.folder), patch.object(run, 'verify_questions', return_value=rows or self.rows):
            return run.build_schedule(self.folder/'private.jsonl')

    def test_orbit_membership_and_unique_cost(self):
        schedule, requests, ensembles = self.build()
        self.assertEqual(len(schedule), 24)
        self.assertEqual(len(requests), 24)
        for item in ensembles:
            forward, reverse = item['forward_request_indices'], item['reverse_request_indices']
            n = len(item['canonical_key_order'])
            self.assertEqual(len(forward), n)
            self.assertEqual(len(reverse), n)
            self.assertEqual(len(set(forward+reverse)), n if n == 2 else 2*n)
            self.assertEqual(item['structural_orbit_identity'], n == 2)
            self.assertEqual(forward[0], item['baseline_request_index'])
            self.assertEqual(reverse[0], item['reverse_single_request_index'])
            for i in set(forward+reverse):
                self.assertEqual(schedule[i]['item_id'], item['item_id'])
                self.assertEqual(schedule[i]['candidate_keys'], item['canonical_key_order'])

    def test_schedule_ignores_input_row_order(self):
        self.assertEqual(self.build(), self.build(list(reversed(self.rows))))

    def test_gold_changes_do_not_change_model_requests(self):
        changed = [dict(row) for row in self.rows]
        changed[0]['label'] = 'false'
        changed[1]['label'] = 'option_4'
        changed[2]['gold_score'] = 4.9
        a, requests_a, _ = self.build()
        b, requests_b, _ = self.build(changed)
        self.assertEqual(requests_a, requests_b)
        self.assertEqual([r['request_sha256'] for r in a], [r['request_sha256'] for r in b])

    def test_prospective_budget_mismatch_fails_closed(self):
        (self.folder/'PROTOCOL.json').write_text(json.dumps({'n_items': 3, 'physical_requests_per_model': 25}))
        with self.assertRaisesRegex(ValueError, 'Prospective'):
            self.build()

    def test_failed_native_acknowledgement_is_not_a_known_total(self):
        class FailedEngine:
            runtime_fingerprint = 'synthetic'
            fingerprint_data = {}
            info = {}
            total_decode_count = 0
            ready = True

            def __init__(self, *args, **kwargs):
                pass

            def decide(self, question):
                self.total_decode_count += 1
                return {'synthetic': True}

            def evaluate_request(self, *args):
                raise TimeoutError('synthetic missing acknowledgement')

            def close(self):
                self.ready = False

        study = self.folder/'failure-study'
        study.mkdir()
        (study/'FREEZE.json').write_text('{}')
        request = {'synthetic': True}
        meta = {'request_index': 0, 'candidate_keys': ['false', 'true'], 'type': 'noul',
                'request_sha256': run.sha(run.canonical(request).encode())}
        args = SimpleNamespace(study=study, model=None, native_binary=None, log=None, questions=None)
        with patch.object(run, 'assert_sources'), patch.object(run, 'source_hashes', return_value={}), \
             patch.object(run.native_run, 'ResearchEngine', FailedEngine):
            with self.assertRaises(RuntimeError):
                run.run_one(args, run.MODELS[0], {'source_sha256': {}}, [meta], [request])
        folder = study/'results'/run.MODELS[0]
        receipt = json.loads((folder/'COMPLETION.json').read_text())
        self.assertEqual(receipt['status'], 'incomplete')
        self.assertIsNone(receipt['actual_calls_including_gate_and_warmup'])
        self.assertEqual(receipt['last_observed_cumulative_call_count'], 3)
        self.assertEqual(receipt['failed_requests'], 1)
        self.assertTrue(receipt['model_closed_before_receipt'])
        attempted = [json.loads(line) for line in (folder/'predictions.jsonl').read_text().splitlines()]
        self.assertEqual(len(attempted), 1)
        self.assertEqual(attempted[0]['error'], 'TimeoutError')


if __name__ == '__main__':
    unittest.main()
