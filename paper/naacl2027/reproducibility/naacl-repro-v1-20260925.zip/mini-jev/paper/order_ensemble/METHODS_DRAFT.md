# Cyclic display-order probability averaging: methods draft

This section describes the prospective journal-extension design and verified data
preparation. It makes no claim about inference completion or treatment outcomes.
The earlier 600-item robustness panel motivated the design and is treated as
development evidence. The present selection, perturbations, averaging rule,
estimands and analysis code are fixed before inference on the new panel. The
records constitute local prospective freezes, not independent public
preregistration.

## Evaluation panel and overlap audit

The evaluation contains 600 newly selected project-evaluation IDs from pinned
public-development releases: 100 in-domain and 100 out-of-domain JCoLA examples,
200 JCommonsenseQA questions and 200 JSTS sentence pairs. JCoLA supplies binary
acceptability judgments; JCommonsenseQA has five alternatives; JSTS retains its
original continuous reference score on the 0–5 scale. The source releases and
attribution are documented in the [data preparation record](README-data.md) and
the [upstream preparation protocol](../external_expanded/PROTOCOL.json).

Before selecting IDs, an inventory examined 46 reachable Git-history or current
tracked artifact versions, identifying 900 previously evaluated upstream IDs:
200 each from JCoLA, JCommonsenseQA and JSTS, plus 300 from JNLI. The inventory
does not establish exhaustive knowledge of untracked work outside the audited
repository. Eligible rows exclude prior IDs and exact source query/sentence texts.
Their order is fixed by SHA-256 of a prespecified salt followed by dataset, split
and original ID. A single rank scan fills the four source quotas, skipping exact
query/sentence duplication within the new panel. Gold labels, predictions,
length, difficulty and semantic judgments do not enter eligibility or ranking.

JSTS receives an additional exclusion based on the complete cached development
graph, comprising all 1,457 JSTS and 2,434 JNLI rows. Edges connect rows sharing
an exact sentence or caption image ID. All components touching a prior JSTS or
JNLI evaluation are excluded, including transitive connections through otherwise
unused rows. The graph contains 2,250 components, of which 448 touch prior
evaluations. Selection takes at most one row per remaining component.

The [selection audit](DATA_PROVENANCE.json) confirms zero prior-ID overlap, zero
prior exact query/sentence overlap, and zero prior JSTS image or full-component
overlap. Exact query/sentence and JSTS-component repeats across selected items
are also zero. Four ranked candidates were skipped for within-panel exact-text reuse
before the quotas filled. These exclusions concern complete source
queries/sentences and measured caption relations; they do not exclude shared
answer words, concepts, paraphrases or other semantic dependencies.

JCoLA bibliography-source overlap is explicitly retained: 194 of its 200 new
items share 30 sources represented in earlier evaluations. All eligible
in-domain rows came from previously represented sources, so strict source novelty
could not supply the planned in-domain sample. The new panel contains 33 JCoLA
groups—10 in-domain and 23 out-of-domain—with no group spanning those strata.
It contains 200 JSTS components and 200 exact-question groups for JCommonsenseQA.
Thus, new project-evaluation IDs do not imply independent linguistic domains,
hidden-test access restrictions or absence of model-training contamination.

## Fixed candidate bindings and probability averaging

For each item, let the canonical semantic options be indexed by
\(y\in\{0,\ldots,K-1\}\). Each output token remains attached to its original
semantic key and definition throughout the experiment. A display transformation
moves the complete option lines; it neither rebinds output tokens to different
meanings nor changes source content. Both copies of the repeated user prompt are
transformed consistently. The candidate-token vector and, for JSTS, the numeric
0–5 stage meanings remain fixed.

For an order \(\pi\), the model's allowed-token logits are normalized at
temperature 1 to obtain \(p_y(x;\pi)\). The primary method averages probabilities
over all \(K\) cyclic rotations \(R_r\) of the canonical order:

\[
\bar p_y^{F}(x)=\frac{1}{K}\sum_{r=0}^{K-1}p_y(x;R_r\pi).
\]

This is an arithmetic probability mean, not a softmax of averaged logits. The
categorical answer is its argmax, breaking exact ties in the fixed canonical
semantic-key order. Binary output also reports \(\bar p_{\mathrm{true}}^{F}\).
JSTS reports the expected score \(\sum_{k=0}^{5}k\bar p_k^{F}\), evaluated against
unrounded continuous gold scores. All scheduled members must be valid; an
incomplete pool is marked unavailable instead of averaging fewer calls. No
ensemble weights, temperature, confidence threshold or prompt variant are fitted.

A reverse-orientation pool averages all rotations of the reversed canonical
order, yielding \(\bar p^{R}\). For five or six distinct options, the forward and
reverse pools contain disjoint physical orders, so equality of their means is
not guaranteed. For two options, both pools contain the same two requests in
opposite enumeration order. Their equality is structural and is not counted as
empirical evidence of successful robustness. Likewise, averaging a complete
cyclic pool is invariant to its starting rotation by construction.

A secondary dihedral diagnostic averages the unique union of both pools. Its
rotation/reversal invariance follows from set identity, not experimental
discovery; arbitrary-permutation invariance is not claimed for \(K\ge4\).
Probability averaging and option-order sensitivity are established research
themes. The distinct feature evaluated here is their application to typed
readout with fixed token-to-meaning bindings; the design does not establish a
new general debiasing algorithm or removal of option-token priors. The
[positioning note](RELATED_WORK.md) distinguishes this perturbation from methods
that reassign option-token meanings.

## Execution and computational cost

Three pinned checkpoints are evaluated serially: Qwen3.6-35B-A3B Q4_K_M through
the verified native llama.cpp runtime, followed by Qwen2.5-0.5B-Instruct and
Qwen2.5-1.5B-Instruct through Transformers. The native configuration uses Metal,
a 2,048-token context limit, six CPU threads and three excluded synthetic
warmups. The smaller checkpoints use MPS, float32, eager attention, batch size
one, frozen parameters, evaluation/inference mode and no KV cache. A stock
final-position forward supplies candidate logits without generating answer
tokens. Actual native decode counters and Transformers forward counters retain
their separate meanings.

Preflight verification hashes the relevant code, implementations and pinned
artifacts, reconstructs request hashes, and checks all 4,800 full input token
sequences and candidate IDs for equality across the two smaller tokenizers.
Allowed candidates must be distinct single-token continuations after the actual
assistant prefix; no truncation or token substitution is permitted. Each
Transformers model must pass 12 fixed synthetic comparisons of final-position
and full-position stock logits: logit atol=1e-3, rtol=1e-5; probability atol=1e-5;
and exact argmax agreement. Those 24 forwards plus three synthetic warmups are
excluded from its benchmark measurements.

| Task | Options \(K\) | Single answer | One cyclic answer | Both orientation pools / dihedral union |
|---|---:|---:|---:|---:|
| JCoLA | 2 | 1 call | 2 calls | 2 unique calls |
| JCommonsenseQA | 5 | 1 call | 5 calls | 10 unique calls |
| JSTS | 6 | 1 call | 6 calls | 12 unique calls |

The canonical and reversed single baselines reuse their respective pool members.
The planned measurement budget is 4,800 unique requests per model, 14,400 across
three models, on the same 600 items. Logical ensemble-member references are
reported separately from physical calls. There is no new identical-prompt repeat
control or equal-call repetition baseline in this study; earlier repeat findings
remain historical evidence. Summed observed call durations describe computational
work and are not a separately benchmarked optimized ensemble-serving latency.

Item blocks and physical orders are randomized with a fixed seed. Failures and
partial attempts are retained without replacements, retries, stopping based on
predictive performance or implicit resume. Existing result directories cannot be overwritten.
Benchmark text and full input sequences stay outside public artifacts; published
records contain metadata, hashes, candidate logits/probabilities and derived
answers under the applicable source-data licensing.

## Estimands, pairing and uncertainty

The primary quality comparison is cyclic-forward averaging minus the canonical
single baseline, on the same complete items. JCoLA reports accuracy, MCC,
balanced accuracy, both class recalls and predicted/gold class marginals;
undefined MCC remains undefined. JCommonsenseQA reports accuracy, class marginals
and correct/incorrect transitions. JSTS reports expected-score MAE against its
continuous reference, with hard-stage MAE and across-item expected-score variance
as descriptive measures. Positive accuracy/MCC differences and negative MAE
differences favor averaging. Reverse-pool and dihedral quality comparisons are
secondary. Classification and regression are not combined into overall accuracy.

For JCommonsenseQA, the primary stability estimand is the cyclic-forward versus
cyclic-reverse semantic flip rate minus the canonical versus reversed-single flip
rate. For JSTS, it is the mean absolute difference between the two cyclic
expected scores minus the corresponding single-prompt absolute difference.
Negative changes indicate less observed orientation sensitivity. JCoLA's
orientation equality is structural, so it receives no empirical robustness
interval. Total variation, full distributions and exact ties accompany the
primary measures. A stable constant prediction can lack class discrimination,
requiring joint interpretation of stability, performance and marginals.

Paired uncertainty uses 2,000 whole-group bootstrap replicates with fixed seed
2026092203 and two-sided 95% percentile intervals. All compared methods stay
paired within each item. JCoLA bibliography groups are sampled independently
within the two source splits; each sampled stratum's sufficient statistics are
rescaled to its original item count, preserving the 100/100 mixture despite
unequal group sizes. JSTS uses full caption components and JCommonsenseQA uses
exact-question groups. If a JCoLA source were shared across splits, the combined
interval would be omitted while retaining combined point estimates and separate
split intervals; the audited selection has no such shared source. Intervals are
also unavailable with fewer than two groups per stratum or any undefined
replicate estimate. Actual group counts and unavailable replicates are reported.

These intervals are descriptive and unadjusted for multiple comparisons; they
support no significance dichotomy or universal-superiority claim. The ten
in-domain JCoLA source groups, extensive source overlap with development evidence
and remaining semantic dependence limit generalization. Improvements relative to
average member losses or distances can follow convexity; the primary comparison
here instead uses fixed single baselines. Checkpoints differ in family/version,
architecture, quantization and backend, precluding causal model-size or fair
cross-backend latency conclusions. Candidate-normalized probabilities are not
calibrated correctness estimates, and this study neither trains an output head
nor establishes deployment reliability.

Design evidence: [protocol](PROTOCOL.json), [pre-selection freeze](DATA_FREEZE.json),
[selected IDs and hashes](SELECTION.json), and
[data provenance](DATA_PROVENANCE.json).
