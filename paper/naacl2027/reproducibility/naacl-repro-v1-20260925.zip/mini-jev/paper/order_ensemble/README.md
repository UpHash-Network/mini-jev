# Cyclic display-order averaging on a new evaluation selection

This study follows the completed `paper/journal_robustness` study. The original
600 items are development evidence; the new selection excludes previously
evaluated IDs and exact input texts within the audited project artifacts. JSTS
also excludes full sentence/image components touching previous JSTS/JNLI items.
These remain public-development data. They are not a hidden test and do not
establish absence of pretraining contamination. JCoLA shares bibliographic
sources with earlier evaluations; consult the selection receipt for exact scope.

The fixed method averages the candidate probability vectors from all cyclic
display rotations while keeping token/semantic bindings fixed. It needs K model
calls. Comparing the two orientations is an empirical sensitivity test for
K=5/6. For K=2 the same two requests form both pools, so zero reversal difference
is a structural identity, not experimental evidence of robustness. The optional
dihedral diagnostic averages the unique union of the two pools; its invariance
to rotations and reversal is also structural. Neither method guarantees
invariance to every permutation for K>=4.

No output-head training or calibration occurs. Probability averaging and
option-order sensitivity are established research themes; this study makes no
new-algorithm claim. Assess quality, class collapse and call cost with stability.

`PROTOCOL.json`, `SELECTION.json`, `SCHEDULE.json`, `ENSEMBLES.json`, runtime
artifacts, and analysis code are locally frozen before any new-study model
forward. The timestamp is a local record, not independent preregistration.
Requests are run as shuffled item blocks with randomized physical orders inside
each block. The three models use the same physical schedule and run serially.
Synthetic implementation checks and warmups are retained but excluded from the
14,400 measured requests. No attempt is retried or silently replaced.

## Reviewer navigation and completion status

As of **2026-09-22**, all three runs and analyses are complete: **14,400 measured
calls on 600 additional evaluation items, with zero inference failures**. Every
model has a completion receipt, and the combined independent computational audit
passes **283/283 checks**. The consolidated report and figures are available
below. The English manuscript is a working research draft, not a submitted or
accepted paper; its review PDF is exported separately with source/build hashes.
Repeated calls are not additional independent evaluation questions.

| Review question | Artifact |
| --- | --- |
| What was fixed before inference? | [PROTOCOL.json](PROTOCOL.json), [study freeze](study_v1/FREEZE.json), [physical schedule](study_v1/SCHEDULE.json), [ensemble membership](study_v1/ENSEMBLES.json) |
| Which items, labels and dependence groups were selected? | [Data description](README-data.md), [data freeze](DATA_FREEZE.json), [selection](SELECTION.json), [provenance](DATA_PROVENANCE.json) |
| What was actually measured? | [Results](study_v1/results/): each model's `predictions.jsonl`, runtime/gate/warmup records and `COMPLETION.json` |
| What are the per-model metrics and paired intervals? | [Analysis](study_v1/analysis/): each model's `SUMMARY.json`, `REPORT.md`, CSV tables and `derived_answers.jsonl` |
| Were the records and calculations checked separately? | [Combined 283-check audit](study_v1/AUDIT.json), plus earlier [native audit](study_v1/AUDIT.native.json) and [0.5B audit](study_v1/AUDIT.0.5b.json) |
| Where are the consolidated results? | [Japanese report](report_v1/REPORT.ja.md), [numeric overview](report_v1/OVERVIEW.json), [figures](figures_v1/), and their [hash manifest](figures_v1/MANIFEST.json) |
| What is the paper's current scope? | [Working manuscript](JOURNAL_MANUSCRIPT_DRAFT.md), integrating matched readout, prior sensitivity, and new-item averaging evidence |
| What is prior work, and what is only proposed? | [Related work](RELATED_WORK.md); [next training design](NEXT_TRAINING_DESIGN.md) is an **unexecuted proposal** |
| Which extra diagnostic was added after observing results? | [Original fixed-midpoint receipt](POSTHOC_MIDPOINT_DIAGNOSTIC.json), [all-model comparisons](POSTHOC_MIDPOINT_COMPLETED.json), and [replay script](posthoc_midpoint.py), explicitly **post-hoc** |

The separate audit was implemented after the study source freeze by another AI
agent. It is a numerical and integrity check, not independent human peer review.
It verifies selected runtime implementation files, not the complete operating
system or every transitive framework dependency.

## Reanalyze the recorded predictions without models

Run commands from the repository root. This is the simplest reproduction path:
the frozen analyzer uses only the Python standard library and the recorded
metadata/predictions. It does not need model weights, tokenizers or raw source
text, and makes no inference calls. Retain the original `study_v1` files; choose
a new output directory for every analysis.

```bash
JEV_REANALYSIS=/absolute/path/outside-repository/reanalysis-01

for JEV_MODEL_KEY in qwen3.6-35b-a3b qwen2.5-0.5b qwen2.5-1.5b; do
  python3 -m paper.order_ensemble.analyze \
    --study paper/order_ensemble/study_v1 \
    --model-key "$JEV_MODEL_KEY" \
    --output "$JEV_REANALYSIS/$JEV_MODEL_KEY"
done
```

Until the last run completes, omit its key for a completed-model-only replay.
The analyzer can describe incomplete records, but that does not establish a
successful full replication. It checks its own frozen source hash and the
schedule, ensemble and tokenization metadata hashes. It writes `SUMMARY.json`,
`REPORT.md`, `derived_answers.jsonl`, quality and orientation CSV tables, paired
bootstrap intervals, failures and request/answer accounting. Reanalysis of the
same observations is not new experimental evidence.

Missing orbit members never yield a partial-orbit average. Native decode counts
and Transformers forward counts have different meanings and remain separate.
The descriptive intervals use paired dependence groups, including JCoLA
source-group resampling within each domain and fixed 100/100 domain weighting;
they are not IID-item significance tests.

## Reconstruct the exact source questions

Raw text and full input token sequences stay outside this repository. If the
pinned upstream cache is not already available, the older materializer can
download its missing public source files and verify their bytes/hashes. This
step needs network access; it makes no model calls. It also reconstructs the
**older** study's questions in that separate cache.

```bash
JEV_EXPANDED_CACHE=/absolute/path/outside-repository/expanded-cache

python3 paper/external_expanded/materialize.py \
  --cache-dir "$JEV_EXPANDED_CACHE"
```

Then reconstruct this study's **new 600-item selection** from the verified raw
files. This second command is offline and does not require Git history. Its
output must not already exist.

```bash
JEV_RAW_DIR="$JEV_EXPANDED_CACHE/raw"
JEV_PRIVATE_QUESTIONS=/absolute/path/outside-repository/order-cache/questions.jsonl

python3 -m paper.order_ensemble.materialize \
  --raw-dir "$JEV_RAW_DIR" \
  --output "$JEV_PRIVATE_QUESTIONS"
```

Expected output: 443,390 bytes, SHA-256
`0f2f0bc991ee8d32244b304c334929e95570584d0c2d30ef89aabad32f3cb6ff`.
The materializer verifies the pinned raw hashes, reconstructed records, caption
component graph, selection references and final file hash. See
[README-data.md](README-data.md) for source filenames and licenses.

Do not run the prospective `prepare.py prepare` to replay this selection: it
creates a new selection and refuses existing freeze files. A new selection
needs a separate prospective study; reachable history can change its exclusion
inventory. The materializer above is the exact-reconstruction path.

## Run the full integrity audit

The full auditor makes no model forward calls, but has stricter requirements
than numerical reanalysis. It reconstructs requests from raw sources, loads the
small-model tokenizers, hashes their complete local checkpoint files, and
checks the frozen runtime implementation inventory. It needs the matching
pinned environment and local checkpoint snapshots. A different machine or
Python installation may fail this historical-environment check even if the
stdlib reanalysis succeeds. The auditor uses the adapter's default Hugging Face
cache at `~/.cache/huggingface/hub`; it has no `--cache-root` option.

```bash
JEV_PYTHON=/absolute/path/to/pinned-runtime/bin/python3

"$JEV_PYTHON" -m paper.order_ensemble.audit \
  --study paper/order_ensemble/study_v1 \
  --questions "$JEV_PRIVATE_QUESTIONS" \
  --raw-dir "$JEV_RAW_DIR" \
  --analysis "$JEV_REANALYSIS" \
  --output "$JEV_REANALYSIS/AUDIT.json"
```

For one completed model, add `--model-key qwen2.5-0.5b` (or another exact key)
and use a fresh audit filename. The combined audit requires all three complete
panels. Supply `--raw-dir` explicitly instead of relying on the original local
cache layout. Original native warmup records lack some per-request state flags;
the audit discloses that limitation. Measured native requests retain those flags.

## Make a genuinely new inference run

This reruns the **same published selection**, so it is a replication or
regression check, not a fresh holdout. Do not prepare or run into the shipped
`study_v1` directory. Use a new directory and preserve all partial attempts.
The frozen runner has no automatic retry or resume.

The recorded implementation is local: Apple Metal for the native quantized
35B model, and MPS float32 for the two Transformers checkpoints. Follow the
[native build instructions](../../NATIVE_BUILD.md), [native model pin](../../native_model.json)
and [small-model adapter documentation](../journal_robustness/cross_model/README.md).
[requirements.txt](../../requirements.txt) records Python package versions;
installing those versions alone does not guarantee the frozen file hashes or
cross-platform numerical equivalence. Model weights and compiled binaries are
not included. The native binary must have its verified package `BUILD.json`
two directories above it. A Git checkout is required by the new-run preparer.

```bash
JEV_REPLICATION=/absolute/path/outside-repository/order-replication-01
JEV_NATIVE_BINARY=/absolute/path/to/verified-native/bin/llama-decision-helper
JEV_NATIVE_MODEL=/absolute/path/to/pinned/model.gguf
JEV_NATIVE_LOG=/absolute/path/outside-repository/order-replication-01-native.log
JEV_HF_CACHE=/absolute/path/to/huggingface/hub

python3 -m unittest \
  paper.order_ensemble.test_conditions \
  paper.order_ensemble.test_runner \
  paper.order_ensemble.test_analysis

"$JEV_PYTHON" -m paper.order_ensemble.run prepare \
  --questions "$JEV_PRIVATE_QUESTIONS" \
  --study "$JEV_REPLICATION" \
  --native-binary "$JEV_NATIVE_BINARY" \
  --cache-root "$JEV_HF_CACHE"

"$JEV_PYTHON" -m paper.order_ensemble.run run \
  --questions "$JEV_PRIVATE_QUESTIONS" \
  --study "$JEV_REPLICATION" \
  --native-binary "$JEV_NATIVE_BINARY" \
  --model "$JEV_NATIVE_MODEL" \
  --log "$JEV_NATIVE_LOG" \
  --cache-root "$JEV_HF_CACHE"
```

Preparation makes no model forwards. It validates all 4,800 full input sequences
and actual-context candidate continuations for both small checkpoints, hashes
the models and selected implementation files, and verifies the native package.
Inference verifies them again, hashes the native model before startup, and runs
35B, 0.5B and 1.5B serially with one model resident at a time. Three native
warmups and, per small model, 24 parity-gate forwards plus three warmups are
retained and excluded from measured request counts. `--model-key` can select a
stage, but earlier stages must already have valid completion/close receipts;
it is not a resume mechanism.

After completion, repeat the analyzer commands with `--study "$JEV_REPLICATION"`
and another fresh analysis destination. Repeat the full audit only in an
environment satisfying its local artifact requirements. Failed or incomplete
attempts must be reported, not silently replaced with successful runs.

## Build the consolidated review artifacts

These commands are for the original `study_v1` **after** all three analyses and
the passing combined `study_v1/AUDIT.json` are available. The report/plot tools
read `study_v1/analysis/` and the study parent's recorded post-hoc diagnostic;
they do not use the external reanalysis directory from the earlier example.
The report builder requires the combined audit. Run plotting only after that
audit as well. Choose a new output root; existing output directories are refused.

```bash
JEV_REVIEW_OUTPUT=/absolute/path/outside-repository/order-review-01
JEV_PLOT_PYTHON=/absolute/path/to/python-with-matplotlib

python3 -m paper.order_ensemble.build_report \
  --study paper/order_ensemble/study_v1 \
  --output "$JEV_REVIEW_OUTPUT/report"

"$JEV_PLOT_PYTHON" -m paper.order_ensemble.plot \
  --study paper/order_ensemble/study_v1 \
  --output "$JEV_REVIEW_OUTPUT/figures"

python3 -m paper.order_ensemble.build_manuscript \
  --output "$JEV_REVIEW_OUTPUT/Mini_Jev_Journal_Working_Draft.pdf" \
  --tectonic /absolute/path/to/tectonic \
  --only-cached \
  --figure "$JEV_REVIEW_OUTPUT/figures/orientation_sensitivity.pdf" \
  --figure-caption "Single-prompt and cyclic-pool orientation sensitivity; binary equality is structural." \
  --figure "$JEV_REVIEW_OUTPUT/figures/quality_and_cost.pdf" \
  --figure-caption "Task quality and physical call cost; midpoint comparison is post-hoc."
```

The report produces `OVERVIEW.json` and `REPORT.ja.md`. Figures are exported as
PNG, SVG and PDF with a hash/version manifest. Planned repository destinations
are `report_v1/` and `figures_v1/`. The manuscript builder uses
`JOURNAL_MANUSCRIPT_DRAFT.md` and produces PDF, TeX, logs and a build receipt; it
does not fill pending results automatically. Tectonic's `--only-cached` needs
previously cached TeX resources; an initial build without it may download TeX
resources. Inspect the rendered PDF after any manuscript or figure change.
This is a **working review draft**, not a venue submission template.

The fixed JSTS midpoint diagnostic can be replayed without inference using
`python3 -m paper.order_ensemble.posthoc_midpoint`. It reads the original
`study_v1` paths, prints a receipt by default, and never overwrites the original
post-hoc receipt. This diagnostic must remain distinct from the prospective
primary outcomes.

Code is MIT. Dataset-derived metadata and outputs follow the source dataset
CC BY-SA 4.0 terms; see [README-data.md](README-data.md) for attribution and
provenance. Raw source text is excluded from the repository and review package.
