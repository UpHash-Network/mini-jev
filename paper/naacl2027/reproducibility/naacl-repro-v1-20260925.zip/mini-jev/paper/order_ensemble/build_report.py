#!/usr/bin/env python3
"""Assemble numeric tables from audited study outputs; no model calls."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

MODELS = ('qwen3.6-35b-a3b', 'qwen2.5-0.5b', 'qwen2.5-1.5b')
DISPLAY = {'qwen3.6-35b-a3b': 'Qwen3.6 35B-A3B Q4', 'qwen2.5-0.5b': 'Qwen2.5 0.5B', 'qwen2.5-1.5b': 'Qwen2.5 1.5B'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    audit_path = args.study/'AUDIT.json'
    audit = json.loads(audit_path.read_text())
    if audit.get('passed') is not True or audit.get('models_checked') != list(MODELS):
        raise ValueError('Require a passing independent audit covering all three models')
    summaries, hashes, rows, intervals, marginal = {}, {}, [], [], []
    for key in MODELS:
        path = args.study/'analysis'/key/'SUMMARY.json'
        raw = path.read_bytes()
        s = json.loads(raw)
        a = s['accounting']
        if a['valid_physical_requests'] != 4800 or a['failure_code_counts']:
            raise ValueError('Incomplete or failed results require explicit reporting before aggregation')
        summaries[key] = s
        hashes[key] = hashlib.sha256(raw).hexdigest()
        q = {(r['dataset'], r['method']): r for r in s['method_quality'] if r['scope'] == 'all'}
        stability = {r['dataset']: r for r in s['orientation_stability'] if r['scope'] == 'all'}
        result = {'model_key': key, 'display_name': DISPLAY[key]}
        for dataset, name, metric in [('JCoLA', 'jcola_accuracy', 'accuracy'),
                ('JCoLA', 'jcola_mcc', 'mcc'), ('JCoLA', 'jcola_balanced_accuracy', 'balanced_accuracy'),
                ('JCommonsenseQA', 'jcqa_accuracy', 'accuracy'), ('JSTS', 'jsts_mae', 'expected_score_mae')]:
            result[name] = {'baseline': q[dataset, 'baseline'][metric], 'cyclic_forward': q[dataset, 'cyclic_forward'][metric]}
        for dataset, name, field in [('JCommonsenseQA', 'jcqa_orientation_flips', 'label_flip_mean'),
                                      ('JSTS', 'jsts_orientation_score_change', 'absolute_expected_score_difference_mean')]:
            r = stability[dataset]
            result[name] = {'single': r['single_'+field], 'cyclic': r['cyclic_'+field],
                           'paired_change': r['bootstrap']['metrics'][r['primary_estimand']]}
        rows.append(result)
        for r in s['quality_comparisons']:
            if r['scope'] == 'all' and r['role'] == 'primary':
                for metric, values in r['bootstrap']['metrics'].items():
                    intervals.append({'model_key': key, 'dataset': r['dataset'], 'metric': metric, **values,
                                      'group_count': r['bootstrap']['group_count']})
        for dataset in ('JCoLA', 'JCommonsenseQA'):
            for method in ('baseline', 'cyclic_forward'):
                r = q[dataset, method]
                marginal.append({'model_key': key, 'dataset': dataset, 'method': method,
                    'predicted': r['label_counts'], 'gold': r['gold_label_counts'],
                    'constant_prediction': len(r['label_counts']) == 1,
                    'mcc': r.get('mcc'), 'balanced_accuracy': r.get('balanced_accuracy')})
    report = {'created_at': datetime.now(timezone.utc).isoformat(), 'new_source_items': 600,
              'measured_requests': 14400, 'models': rows, 'primary_quality_intervals': intervals,
              'classification_marginals': marginal, 'summary_sha256': hashes,
              'all_inference_failures': 0, 'independent_ai_audit_checks': audit['n_checks'],
              'audit_sha256': hashlib.sha256(audit_path.read_bytes()).hexdigest(), 'prior_robustness_series_requests': 7600,
              'series_measured_requests': 22000, 'series_unique_source_items': 1200,
              'scope': 'The earlier900-ID exclusion union also includes300 JNLI items outside this robustness series.'}
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output/'OVERVIEW.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n')

    def value(v, percent=False):
        return '未定義' if v is None else f'{v*100:.1f}%' if percent else f'{v:.4f}'

    def arrow(r, key, percent=False):
        return value(r[key]['baseline'], percent)+' → '+value(r[key]['cyclic_forward'], percent)

    lines = ['# Mini Jev：未使用評価項目での追加実験', '',
        '**新たな600問・3モデル・14,400回の推論が完了しました。推論失敗は0件です。**', '',
        '前回の600問を開発上の参考とし、それらと重複しない600問で、候補の表示順を循環させて確率を平均する方法を評価しました。条件・選定・集計コードは推論前にローカルで固定しました。独立した公開事前登録ではありません。', '',
        'これは学習済み重みを更新しない推論方法の検証です。1回の直接読み出しに対し、平均化には文法2回・常識問題5回・文章類似度6回の呼び出しが必要です。', '',
        '## 逆順にしたときの変化', '',
        '小さい値ほど変化が少ない指標です。二値の文法判定は同じ2回を共有するため、逆順でも一致することが数学的に決まります。下表の実証対象には含めません。', '',
        '| モデル | 常識問題：回答変更率（単発 → 平均化） | 文章類似度：期待値の平均変化（単発 → 平均化） |',
        '|---|---:|---:|']
    for r in rows:
        a, b = r['jcqa_orientation_flips'], r['jsts_orientation_score_change']
        lines.append(f"| {r['display_name']} | {value(a['single'],True)} → {value(a['cyclic'],True)} | {value(b['single'])} → {value(b['cyclic'])} |")
    lines += ['', '## 正解性能', '',
        '同じ200問ずつでの単発 → 前向き循環平均です。正答率・balanced accuracy・MCCは大きいほど良く、類似度MAEは小さいほど良い指標です。', '',
        '| モデル | 文法正答率 | 文法balanced accuracy | 文法MCC | 常識問題正答率 | 類似度MAE |',
        '|---|---:|---:|---:|---:|---:|']
    for r in rows:
        lines.append('| '+r['display_name']+' | '+' | '.join(arrow(r,key,p) for key,p in [
            ('jcola_accuracy',True),('jcola_balanced_accuracy',True),('jcola_mcc',False),('jcqa_accuracy',True),('jsts_mae',False)])+' |')
    native_reverse_mae = next(r['expected_score_mae'] for r in summaries[MODELS[0]]['method_quality']
                             if r['dataset'] == 'JSTS' and r['scope'] == 'all' and r['method'] == 'reverse_single')
    if native_reverse_mae < rows[0]['jsts_mae']['cyclic_forward']:
        lines += ['', f"35Bの逆順単発では類似度MAEが{native_reverse_mae:.4f}で、循環平均より小さくなりました。上表は事前に固定した基準との比較であり、平均化が全条件中で最良という意味ではありません。逆向き平均・両方向平均も含む全条件は英文原稿と集計ファイルに収録しています。"]
    constants = [r for r in marginal if r['dataset'] == 'JCoLA' and r['constant_prediction']]
    if constants:
        lines += ['', '文法判定が一定の回答になった条件：', '']
        for r in constants:
            lines.append(f"- {DISPLAY[r['model_key']]} / {r['method']}: {r['predicted']}。MCCは未定義であり、安定性を識別能力の証拠にはできません。")
    lines += ['', '文法判定の回答内訳（各200問、正解はtrue 157問・false 43問）：', '',
              '| モデル | 条件 | true回答数 | false回答数 |', '|---|---|---:|---:|']
    for r in marginal:
        if r['dataset'] == 'JCoLA':
            lines.append(f"| {DISPLAY[r['model_key']]} | {r['method']} | {r['predicted'].get('true', 0)} | {r['predicted'].get('false', 0)} |")
    lines += ['', '1.5Bも文法判定は199/200問でtrueを返しました。79%の正答率だけでは、両クラスを見分ける能力を評価できません。', '',
              '類似度の平均化後の出力分布も確認しています。下表の最頻段階は最大確率の段階であり、期待値そのものとは異なります。', '',
              '| モデル | 最頻段階と件数 | 問題間の期待値の分散 |', '|---|---|---:|']
    for key in MODELS:
        score = next(r for r in summaries[key]['method_quality'] if r['dataset'] == 'JSTS' and r['scope'] == 'all' and r['method'] == 'cyclic_forward')
        label, count = max(score['label_counts'].items(), key=lambda p: p[1])
        lines.append(f"| {DISPLAY[key]} | 段階{label}: {count}/200 | {score['expected_score_variance_across_items']:.5f} |")
    midpoint_path = args.study.parent/'POSTHOC_MIDPOINT_DIAGNOSTIC.json'
    midpoint = json.loads(midpoint_path.read_text())
    lines += ['', '### 結果確認後に追加した固定値との比較', '',
        f"0.5Bの出力がほぼ一定になったことを受け、文章類似度を全問2.5とする追加診断を行いました。この固定値のMAEは{midpoint['mae']:.4f}で、0.5Bの平均化後{rows[1]['jsts_mae']['cyclic_forward']:.4f}より小さい点推定でした。2.5は尺度の中点であり、正解データから最適化した値ではありません。ただし、この比較自体は事前計画に含まれず、結果確認後に追加したものです。",
        '', f"1.5Bの平均化後のMAEも{rows[2]['jsts_mae']['cyclic_forward']:.4f}で、固定値より大きくなりました。この基準は1.5Bの推論開始後・結果集計前に固定しています。差の統計的有意性を示す比較ではありません。", '',
        '平均化による誤差の減少だけで、有用な識別能力が得られたとは結論づけられません。']
    lines += ['', '## 推定の幅と計算量', '',
        '差は「平均化 − 単発」。正答率・MCCの差は正、MAEの差は負が改善方向です。正答率・balanced accuracy・再現率の差は割合（0.01 = 1パーセントポイント）で表しています。下記は2,000回のグループ単位bootstrapによる記述的95%区間で、多重比較の補正はしていません。有意差の判定には使っていません。', '',
        '| モデル | 課題 | 指標の差 | 推定値 | 記述的95%区間 |', '|---|---|---|---:|---:|']
    for r in intervals:
        interval = '['+value(r['ci95_lower'])+', '+value(r['ci95_upper'])+']' if r['interval_available'] else '区間なし'
        lines.append(f"| {DISPLAY[r['model_key']]} | {r['dataset']} | {r['metric']} | {value(r['estimate'])} | {interval} |")
    lines += ['', 'MCCの「区間なし」は、再標本化した反復で指標が未定義となったためです。1.5Bは2,000反復中717反復、0.5Bは全反復で未定義となり、事前ルールに従って区間を省略しました。未定義をゼロとして扱ってはいません。']
    lines += ['', '順序を反転したときの感度についても、対応する差の区間を示します。負の差は感度の低下です。回答変更率の差は割合（0.01 = 1ポイント）で表しています。', '',
        '| モデル | 感度指標の差 | 推定値 | 記述的95%区間 |', '|---|---|---:|---:|']
    for row in rows:
        for key, label in [('jcqa_orientation_flips', '常識問題の回答変更率'),
                           ('jsts_orientation_score_change', '類似度期待値の平均変化')]:
            estimate = row[key]['paired_change']
            interval = '['+value(estimate['ci95_lower'])+', '+value(estimate['ci95_upper'])+']' if estimate['interval_available'] else '算出対象外'
            lines.append(f"| {row['display_name']} | {label} | {value(estimate['estimate'])} | {interval} |")
    lines += ['', '14,400回は600問の条件違いを含む呼び出し数です。14,400問の独立した質問ではありません。前回の頑健性実験と合わせると、1,200項目に対する22,000回の測定です。モデル間には系列・精度・実行基盤の違いがあり、モデルサイズの因果効果や公平な速度差は示せません。', '',
        '## データと解釈の範囲', '',
        '- 過去の評価900件とのID・同一入力文の重複はゼロです。文章類似度は文・元画像の関連グループも分離しました。',
        '- 文法200問のうち194問は以前の評価と文献出典が共通です。新たな独立言語領域を評価したという意味ではありません。',
        '- 公開developmentデータなので、モデルの事前学習への混入は不明です。隠されたテストセットではありません。',
        '- 候補内で正規化した確率であり、正解確率としての校正は検証していません。',
        '- 順序への感度や順序平均化には先行研究があります。新しい一般的な学習アルゴリズムとしては主張しません。', '',
        '先行研究との対応は [Zheng et al.](https://arxiv.org/html/2309.03882v4#S3.SS1) と [Pezeshkpour and Hruschka](https://aclanthology.org/2024.findings-naacl.130/) を確認しています。本実験では出力記号と意味の対応を固定して行の表示順を変えており、記号への意味の割当てを変える手法を再現したものではありません。', '',
        '## 証拠ファイル', '',
        '- [推論前の固定記録](../study_v1/FREEZE.json)',
        '- [35Bの全条件集計](../study_v1/analysis/qwen3.6-35b-a3b/SUMMARY.json)・[0.5Bの全条件集計](../study_v1/analysis/qwen2.5-0.5b/SUMMARY.json)・[1.5Bの全条件集計](../study_v1/analysis/qwen2.5-1.5b/SUMMARY.json)',
        '- [数値一覧](OVERVIEW.json)',
        '- [別のAIエージェントによる数値・整合性検算](../study_v1/AUDIT.json)（人による学術査読ではありません）',
        '- [英文原稿](../JOURNAL_MANUSCRIPT_DRAFT.md)・[英文の方法節](../METHODS_DRAFT.md)', '',
        '本資料は論文拡張の実験記録です。論文投稿・査読採択が完了したという意味ではありません。', '']
    (args.output/'REPORT.ja.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({'new_items':600,'measured_requests':14400,'output':str(args.output)}))


if __name__ == '__main__':
    main()
