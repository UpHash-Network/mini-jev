"""Reproduce the explicitly post-hoc, fixed 2.5 JSTS reference without inference.

Run from the repository root, for example:
  python paper/order_ensemble/posthoc_midpoint.py
  python paper/order_ensemble/posthoc_midpoint.py \
    --model-key qwen3.6-35b-a3b --model-key qwen2.5-0.5b \
    --model-key qwen2.5-1.5b --output <fresh-completed-receipt.json>

The original diagnostic snapshot is read-only. Output files use exclusive
creation. No constant is fitted, alternative searched, or model imported.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-key", action="append", default=None)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    repo = base.parents[1]
    original_path = base / "POSTHOC_MIDPOINT_DIAGNOSTIC.json"
    selection_path = base / "SELECTION.json"
    ensemble_path = base / "study_v1" / "ENSEMBLES.json"
    original = json.loads(original_path.read_text())
    for path in (selection_path, ensemble_path):
        recorded = original["source_sha256"][str(path.relative_to(repo))]
        if sha256(path) != recorded:
            raise ValueError(f"Original diagnostic input hash mismatch: {path}")
    if original["prespecified"] is not False:
        raise ValueError("The original diagnostic must be labeled post-hoc")
    rule = original["constant_rule"]
    if (rule["lower_scale_endpoint"], rule["upper_scale_endpoint"],
            rule["prediction"], rule["fitted_from_test_gold"],
            rule["alternatives_searched"]) != (0, 5, 2.5, False, False):
        raise ValueError("The original fixed midpoint rule changed")
    selection = json.loads(selection_path.read_text())
    if selection["count"] != 600 or len(selection["items"]) != 600:
        raise ValueError("Expected the original 600-item selection")
    rows = sorted((row for row in selection["items"] if row["dataset"] == "JSTS"),
                  key=lambda row: row["id"])
    ensembles = {row["item_id"]: row for row in json.loads(ensemble_path.read_text())
                 if row["dataset"] == "JSTS"}
    if len(rows) != 200 or set(ensembles) != {row["id"] for row in rows}:
        raise ValueError("JSTS item accounting mismatch")
    for row in rows:
        gold = row["gold_score"]
        if not math.isfinite(gold) or not 0 <= gold <= 5:
            raise ValueError("Invalid continuous gold score")
        if gold != ensembles[row["id"]]["gold_score"]:
            raise ValueError("Selection and ensemble gold disagree")
    item_gold = [{"item_id": row["id"], "gold_score": row["gold_score"]}
                 for row in rows]
    gold_hash = hashlib.sha256(json.dumps(item_gold, sort_keys=True,
                                         separators=(",", ":")).encode()).hexdigest()
    if gold_hash != original["sorted_item_gold_sha256"]:
        raise ValueError("Original sorted item/gold digest mismatch")
    # No fitting: 2.5 is the arithmetic midpoint of the already fixed 0–5 scale.
    prediction = (0 + 5) / 2
    error_sum = math.fsum(abs(prediction - row["gold_score"]) for row in rows)
    mae = error_sum / len(rows)
    if not math.isclose(mae, original["mae"], rel_tol=0, abs_tol=1e-12):
        raise ValueError("Original diagnostic MAE does not reproduce")
    keys = args.model_key or ["qwen3.6-35b-a3b", "qwen2.5-0.5b"]
    allowed = {"qwen3.6-35b-a3b", "qwen2.5-0.5b", "qwen2.5-1.5b"}
    if len(set(keys)) != len(keys) or not set(keys) <= allowed:
        raise ValueError("Expected distinct pinned checkpoint keys")
    inputs = [selection_path, ensemble_path, original_path, Path(__file__).resolve()]
    comparisons = []
    for key in keys:
        path = base / "study_v1" / "analysis" / key / "SUMMARY.json"
        summary = json.loads(path.read_text())
        if summary["accounting"]["valid_physical_requests"] != 4800:
            raise ValueError(f"Model analysis is incomplete: {key}")
        inputs.append(path)
        for method in ("baseline", "cyclic_forward"):
            row = next(row for row in summary["method_quality"]
                       if row["dataset"] == "JSTS" and row["scope"] == "all"
                       and row["method"] == method)
            if row["n"] != 200 or row["n_unavailable_items"] != 0:
                raise ValueError(f"JSTS method has incomplete coverage: {key}/{method}")
            comparisons.append({
                "model_key": key, "method": method, "n": row["n"],
                "expected_score_mae": row["expected_score_mae"],
                "mae_minus_fixed_midpoint_mae": row["expected_score_mae"] - mae,
                "expected_score_variance_across_items": row["expected_score_variance_across_items"],
            })
    result = {
        "schema_version": 1,
        "diagnostic": "Reproduction/comparisons of POST-HOC fixed JSTS midpoint reference",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "original_chosen_at_utc": original["chosen_at_utc"],
        "original_diagnostic_sha256": sha256(original_path),
        "original_choice_motive": original["selection_motive"],
        "prespecified": False,
        "fixed_prediction": prediction,
        "formula": "sum(abs(2.5 - gold_score) for each of the 200 fixed JSTS items) / 200",
        "n": len(rows), "mae": mae, "absolute_error_sum": error_sum,
        "sorted_item_gold_sha256": gold_hash,
        "comparisons": comparisons,
        "model_loads": 0, "model_forwards": 0,
        "interpretation": original["interpretation"],
        "source_sha256": {str(path.relative_to(repo)): sha256(path) for path in inputs},
    }
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        with args.output.open("x") as handle:
            handle.write(encoded)
        print(json.dumps({"output": str(args.output), "n": len(rows),
                          "midpoint_mae": mae, "model_forwards": 0}))
    else:
        print(encoded, end="")


if __name__ == "__main__":
    main()
