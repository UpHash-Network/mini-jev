# Typed Decision Readout under Candidate Presentation Changes: Matched Baselines and Cyclic Probability Averaging

**Yuki Oshio**  
**UPHASH Inc.**  
oshio@uphash.net

**Working empirical manuscript, 22 September 2026.** All three experimental
stages below are complete and computationally audited. The order-ensemble audit
passed 283 checks across all three checkpoints. This working manuscript remains
neither submission-ready nor accepted; computational checks by AI agents are not
independent human peer review.

## Abstract

A language model can return a categorical decision, binary candidate probability,
or expected ordinal score by reading restricted next-token logits. We examine
the resulting quality, presentation sensitivity and computational cost in Mini
Jev. A matched 4,050-request study found identical logits and labels in all 1,350
direct-readout/one-token pairs. The median paired latency difference was 0.090 ms
(conditional 95% interval −0.748 to 0.845 ms), providing no demonstrated material
advantage over matched one-token selection. A 7,600-request sensitivity study
reused 600 public-development items across three checkpoints: exact repeats were
identical, but some presentation changes altered answers, and stability could
coexist with constant majority-class output. Motivated by these observations,
we prospectively froze cyclic probability averaging and evaluated 600 additional
project-evaluation IDs with 14,400 requests. On JCommonsenseQA, cyclic-orientation
flip rates were lower than single-prompt reversal rates for all three
checkpoints, while accuracy changes were mixed. On the native 35B checkpoint,
JSTS expected-score MAE decreased from 0.52405 to 0.48568 (paired change −0.03837;
descriptive 95% interval −0.06942 to −0.00834). Both smaller checkpoints produced
nearly constant scores and failed to beat an explicitly post-hoc fixed-midpoint
reference. Cyclic answers cost 2, 5 or 6 model evaluations; binary orientation
equality is structural rather than empirical evidence. Across 26,050 measured
requests on shared item panels, the results support evaluating quality,
stability, marginals and cost jointly. They establish neither a new general
averaging algorithm nor calibrated correctness or uniform quality improvement.

## 1. Introduction

Many applications require a bounded decision rather than a paragraph: select
one option, assign a binary judgment, or estimate a score on an ordinal scale.
Mini Jev exposes these operations by restricting attention to predefined output
tokens from a frozen language model. Its interface was inspired by TypeSafe
Jev [1], but the implementation is independent; it does not reproduce that
system's architecture, training, calibration, or reported performance.

Three questions need to be kept separate. First, does reading logits directly
change the answer or computation relative to a genuinely matched one-token
decoder? Second, are the resulting decisions stable when presentation changes
while their meanings remain fixed? Third, can a predefined averaging rule
improve quality or reduce sensitivity at an explicitly measured computation
cost? A valid serialized output answers none of these questions by itself.

We organize the evidence into three stages. The first compares direct readout
with native masked one-token selection and grammar-constrained JSON. The second
measures presentation sensitivity on the same external items, including a
repeat control and two additional checkpoints. The third prospectively froze
a cyclic display-averaging method and selected additional evaluation IDs using
literal and caption-component exclusion rules. These stages provide an
implementation and empirical case study, rather than a claim that restricted
logit readout or probability averaging is a new general learning algorithm.

## 2. Relation to existing work

Mapping task labels to vocabulary tokens is established in verbalizer-based
classification [2]. Next-token yes/no probabilities are also used in neural
reranking [3]. Grammar-constrained generation addresses the related problem of
producing valid structured outputs [4], although validity does not guarantee
semantic correctness. Mini Jev combines these familiar ideas in a typed local
interface and makes the distinction between a probability over candidates and
a probability of correctness explicit. Temperature scaling [5] and contextual
calibration [6] are relevant alternatives, but the robustness and ensemble
experiments here fit no temperature, contextual prior, or calibration model.

Option-order sensitivity and its mitigation also precede this study.
Pezeshkpour and Hruschka [7] investigate changes induced by multiple-choice
option order. Zheng et al. [8, Section 3.1, Equation 1] describe a cyclic
permutation-averaging baseline requiring K rather than K! evaluations. In their
formulation, option IDs retain their displayed order while contents move,
changing the mapping between an ID and a meaning. Our transformation instead
moves complete option lines while retaining every output-token/key/meaning
binding. Consequently, this experiment applies an established averaging idea to
a different perturbation; it is not a faithful replication of their permutation
baseline or their separate PriDe method. It neither estimates an option-ID prior
nor demonstrates removal of such a prior.

The empirical question is whether this fixed-binding application offers a useful
quality–stability trade-off, including binary judgments and continuous
expectations over an ordinal scale. Demonstrating that a complete average is
invariant to enumerating its same members in another order would not resolve
that question.

## 3. Typed readout and probability definitions

Let \(z_y(x;\pi)\) be the logit of the allowed token attached to semantic
candidate \(y\), given input \(x\), candidate display order \(\pi\), and the
fixed assistant prefix. For \(K\) candidates and temperature \(T>0\),

\[
p_y(x;\pi,T)=\frac{\exp(z_y(x;\pi)/T)}
 {\sum_{j=0}^{K-1}\exp(z_j(x;\pi)/T)}.
\]

This distribution is conditional on the supplied candidate set. It does not
measure the probability that the set is appropriate or that the selected answer
is correct. The categorical operation returns its argmax. The binary operation,
called Noul in the interface, additionally reports \(p_{\mathrm{true}}\).
For equally spaced score stages \(s_y\), Score reports
\(\hat s=\sum_y s_y p_y\), separately from its hard argmax stage. JSTS uses
stages 0 through 5 and retains continuous gold scores. Positive temperature
preserves an untied argmax while changing binary probabilities and expected
scores. All primary robustness and ensemble calculations use \(T=1\).

An optional concentration statistic,
\(1-H(p)/\log K\), describes candidate entropy. Neither it nor the maximum
candidate probability is a calibrated correctness estimate. Concentration and
maximum probability are different statistics and are not used interchangeably.

The evaluated prompts repeat the user instruction twice, with both copies
transformed consistently. The runtime checks that allowed answers are distinct
single-token continuations in their actual context. It rejects overlength
requests rather than truncating them. State is cleared between native requests;
the Transformers experiments use no KV cache. The current readout still
computes the full vocabulary projection before gathering candidate logits.
Therefore, the study does not evaluate a selected-row output-projection
optimization or a newly trained output head.

A correctly matched greedy one-token selection uses the same prefix, logits,
candidate IDs, processing and tie rule. Reading that first decision need not
require another model forward. Any latency claim must therefore be established
by measurement rather than inferred from a zero generated-token count.

## 4. Evidence stages and accounting

| Stage | Item panel | Measured requests | Status |
|---|---|---:|---|
| Matched readout | 150 local items and 600 public-development items | 4,050 measured | Completed; audit passed |
| Presentation sensitivity | The same 600 external items | 4,000 native + 1,800 per smaller checkpoint = 7,600 measured | Completed; both audits passed |
| Cyclic averaging | 600 additional project-evaluation IDs | 4,800 per checkpoint = 14,400 | Completed; combined 283-check audit passed |

Repeated conditions and model evaluations are measurements on shared items,
not additional independent questions. The external panel in the second stage
is the first stage's panel, and it serves as development evidence for the third.
Public-development provenance and unknown training exposure apply throughout.
The stages contain 26,050 measured requests in total, not 26,050 independent
questions. The protocols were locally frozen before their respective inference
runs, not independently publicly preregistered.

## 5. Completed matched-readout study

### 5.1 Design and checks

The matched experiment used a pinned Qwen3.6-35B-A3B Q4_K_M checkpoint on one
Apple M5 Pro 64 GB machine, using Metal/Accelerate in one session. Each of 150
previously published local regression items was measured five times in each of
three modes. Another 600 public-development items—200 each from JCoLA [9],
JCommonsenseQA, and JSTS [10]—were measured once per mode. All 4,050 scheduled
requests completed without HTTP failures or invalid records; 21 synthetic
warmup requests were excluded. Direct and native masked greedy one-token modes
shared complete prompt tokens and candidate IDs. JSON mode actually generated a
grammar-constrained object using a serialization-specific prompt.

All 1,350 direct/one-token pairs had exactly identical saved candidate logits
and selected labels. No maximum-logit ties occurred. The audit checked actual
native sampling and counters; the one-token answer was not synthesized by
copying a direct-readout result. Direct and one-token tie rules differ in this
implementation, so the absence of ties is relevant to the observed agreement.

### 5.2 Latency and task quality

The primary timing statistic is the median, over the 150 local items, of the
within-item difference between five-repeat mean HTTP latencies. It is not a
difference of marginal medians. Timing includes client serialization through
persistent loopback HTTP response parsing, including native audit transfer and
parsing; it excludes the later trace-file write. A 10,000-replicate whole-family/
tag bootstrap preserves pairing and repetitions across 55 observed groups.

| Comparator minus direct | Median paired difference, ms | Conditional 95% interval, ms |
|---|---:|---:|
| Native one-token | +0.090 | [−0.748, +0.845] |
| Constrained JSON | +160.296 | [+138.119, +177.059] |

The study did not demonstrate a material latency advantage over matched
one-token selection. The JSON difference includes prompt/prefill and
multi-token serialization work; it does not isolate the cost of sampling.
Intervals are conditional on the observed groups, software, machine and session,
and do not describe between-session or hardware-population variability.

| External outcome, 200 items per task | Direct | One-token | Constrained JSON |
|---|---:|---:|---:|
| JCoLA accuracy (%) | 86.0 | 86.0 | 82.0 |
| JCoLA MCC | 0.5708 | 0.5708 | 0.5160 |
| JCommonsenseQA accuracy (%) | 95.0 | 95.0 | 95.5 |
| JSTS expected-score MAE | 0.5065 | 0.5065 | Unavailable |
| JSTS hard-stage MAE | 0.5480 | 0.5480 | 0.5650 |

The one-token audit provides its probability vector without an additional model
call. JSON supplies no comparable vector, so its expected-score MAE is
unavailable. All JSTS errors use original continuous gold scores; no rounded-gold
classification task or pooled accuracy is constructed. On JCoLA, an always-true
rule obtains 79% accuracy and undefined MCC, illustrating why accuracy alone is
insufficient. Detailed evidence is in the matched [report](../matched_study/REPORT.md),
[metrics](../matched_study/SUMMARY.json), and
[independent audit](../matched_study/INDEPENDENT_AUDIT.json).

## 6. Completed candidate-presentation study

### 6.1 Design and repeat control

The native checkpoint executed 4,000 requests covering baseline, an exact repeat,
display reversal, and applicable secondary transformations on the same 600
external items. Display transformations preserve candidate meanings and output
token assignments; label substitution and rewording test different changes and
are not all pure formatting manipulations. Pinned Qwen2.5-0.5B-Instruct and
Qwen2.5-1.5B-Instruct then each evaluated the frozen baseline/repeat/reversal
subset, totaling 1,800 requests per checkpoint. Smaller-checkpoint tokenizers
produced identical input sequences and candidate IDs across that schedule.

The smaller models used Transformers, MPS, float32, eager attention and no KV
cache. Each passed twelve synthetic full-position/final-position parity checks
(24 forwards) followed by three warmups, all excluded from benchmark totals.
Logit tolerances were atol=1e−3 and rtol=1e−5, probability atol=1e−5, with exact
argmax agreement. The native panel excluded three warmups. Actual Transformer
forward counters and native decode counters retain their distinct meanings.

All 7,600 requests completed without inference errors. Each checkpoint's 600
exact-input repeat pairs had identical raw logits and probabilities: 1,800
identical pairs overall. No benchmark request had a top-logit tie. Presentation
changes therefore exceeded the repeat variation observed in these runs and were
not tie-breaking artifacts; this does not establish universal determinism.

### 6.2 Sensitivity is distinct from aggregate quality

The following table retains every native-panel condition. Entries contain 200
items where applicable. Flip rates and expected-score changes compare against
the corresponding baseline; dashes denote a reference or inapplicable condition.

| Condition | JCoLA flips (%) | JCoLA accuracy (%) / MCC | JCQA flips (%) | JCQA accuracy (%) | JSTS mean absolute expected-score change | JSTS expected-score MAE |
|---|---:|---:|---:|---:|---:|---:|
| Baseline | — | 86.0 / 0.5708 | — | 95.0 | — | 0.5065 |
| Exact repeat | 0.0 | 86.0 / 0.5708 | 0.0 | 95.0 | 0.0000 | 0.5065 |
| Display reversal | 5.5 | 82.5 / 0.5055 | 5.5 | 96.0 | 0.1817 | 0.4844 |
| Display rotation | — | — | 8.5 | 90.0 | 0.2983 | 0.5391 |
| Output-label reversal | 3.0 | 87.0 / 0.5892 | 7.0 | 91.0 | — | — |
| Displayed-key substitution | 4.5 | 84.5 / 0.5626 | 3.5 | 95.5 | — | — |
| Instruction rewording | 5.0 | 86.0 / 0.5708 | 1.0 | 95.0 | 0.1209 | 0.5231 |
| Definition rewording | 3.5 | 87.5 / 0.6138 | — | — | 0.1287 | 0.5105 |

Reversal changed 11/200 classifications on each categorical task, while JCoLA
accuracy decreased and JCQA accuracy increased. JSTS MAE improved despite changed
individual scores. Instruction rewording changed ten JCoLA judgments without
changing accuracy or MCC: five correct-to-incorrect transitions offset five
incorrect-to-correct transitions. Aggregate quality thus concealed individual
decision changes.

Across native manipulations, 19 flipped pairs involving 18 distinct JCQA items
had baseline maximum candidate probability at least 0.9: three reversal, ten
rotation, five label-reversal and one key-substitution pairs. One rotation changed
a correct answer with maximum probability 0.99936 to an incorrect answer with
0.91103. These observations concern candidate-normalized probabilities, not a
validated correctness confidence or a calibration experiment.

### 6.3 Stable degenerate predictions

| Checkpoint | JCoLA reversal flips (%) | JCQA reversal flips (%) | JCQA accuracy, baseline → reversal (%) | JSTS mean absolute score change | JSTS MAE, baseline → reversal |
|---|---:|---:|---:|---:|---:|
| Qwen2.5-0.5B | 99.5 | 66.5 | 37.5 → 38.5 | 1.43094 | 1.3996 → 1.2293 |
| Qwen2.5-1.5B | 0.0 | 21.5 | 80.5 → 76.0 | 0.10173 | 1.2096 → 1.1910 |

The 1.5B checkpoint predicted true on all 200 JCoLA items under baseline, repeat,
and reversal. Its zero flip rate accompanied the 79% majority-label accuracy and
undefined MCC. The 0.5B baseline predicted false 199 times; reversal predicted
true throughout. Accuracy increased from 21.5% to 79%, while 99.5% of predictions
flipped and reversal MCC became undefined. Neither stability nor majority-driven
accuracy establishes discrimination. Joint reporting of performance, marginals,
and stability is therefore necessary.

These are descriptive fixed-panel results without confidence intervals or
significance tests. Native [metrics](../journal_robustness/study_v1/analysis/SUMMARY.json)
and [audit](../journal_robustness/study_v1/AUDIT.json) passed 93 checks;
cross-checkpoint [metrics](../journal_robustness/cross_model/study_v1/analysis/SUMMARY.json)
and [audit](../journal_robustness/cross_model/study_v1/AUDIT.json) passed 163 checks.
An [audit-only correction](../journal_robustness/cross_model/study_v1/AUDIT_CORRECTION.json)
preserves the initial report and documents a counter-field naming error in the
auditor. Frozen inference records were unchanged and were not rerun.

## 7. Prospectively frozen cyclic-averaging experiment

### 7.1 New project-evaluation IDs and remaining dependence

The new panel contains 100 in-domain and 100 out-of-domain JCoLA items, 200 JCQA
questions and 200 JSTS pairs from the same pinned public-development sources.
An inventory of 46 reachable historical or current tracked artifact versions
identified 900 previously evaluated upstream IDs, including the earlier JNLI
pilot. Prior IDs and exact source query/sentence matches are excluded. A frozen
salted SHA-256 ranking, independent of gold labels, model predictions, length or
difficulty, fills the four quotas while excluding within-panel literal reuse.

For JSTS, an additional graph includes all 1,457 JSTS and 2,434 JNLI development
rows, connecting exact sentences or caption image IDs. All 448 of its 2,250
components touching earlier evaluations are excluded, including transitive
connections through unused rows. At most one row per remaining component is
selected. The audit finds zero prior-ID, exact query/sentence, JSTS image, or
full-component overlap and no corresponding within-panel repeats. These rules
do not exclude paraphrases, shared concepts or all semantic dependence, and the
historical inventory cannot establish the absence of untracked external work.

Bibliographic dependence remains substantial: 194/200 new JCoLA items share 30
sources represented in earlier evaluations. All eligible in-domain items came
from previously represented sources. The new panel has 10 in-domain and 23
out-of-domain bibliography groups, with no group crossing those splits; JCQA
and JSTS have 200 question groups and 200 components, respectively. New IDs
therefore do not mean new linguistic domains, hidden-test access, or absence of
pretraining contamination. The [data provenance](DATA_PROVENANCE.json) records
these exclusions and remaining overlap.

### 7.2 Probability means and orientation tests

Let \(R_r\pi\) be rotation \(r\) of canonical display order \(\pi\).
The primary answer uses the arithmetic probability mean

\[
\bar p_y^{F}(x)=K^{-1}\sum_{r=0}^{K-1}p_y(x;R_r\pi,1).
\]

The reverse pool \(\bar p^R\) averages rotations of the reversed canonical
order. Each complete option line moves with its semantic key and output token;
candidate vectors and meanings remain unchanged. The final argmax breaks exact
ties using a fixed canonical semantic-key order. Binary outputs and continuous
score expectations are derived from the mean distribution. No probabilities
are averaged across incomplete pools, and no weights, temperatures, thresholds
or variants are chosen from new outcomes.

For five or six distinct candidates the two cyclic pools contain disjoint
physical orders, so their agreement is empirical. For two candidates they reuse
the same two calls, making equal orientation means structural. Changing the
starting rotation of a complete pool is likewise invariant by construction.
A secondary dihedral diagnostic averages the unique union of both pools; its
rotation/reversal invariance follows from set identity. It is not evidence of
arbitrary-permutation invariance for K≥4 or a novel invariance mechanism.

### 7.3 Execution and cost

The same three pinned checkpoints were evaluated serially. Each single answer
requires one evaluation; a cyclic answer requires 2, 5 or 6 evaluations. Evaluating
both orientations reuses two calls for JCoLA and requires 10 for JCQA or 12 for
JSTS. Single baselines reuse members of these pools. This gives 4,800 unique
requests per model, or 14,400 measurements on the same 600 items.
These costs are additional computation, not additional independent data.

The pre-inference [freeze](study_v1/FREEZE.json) records zero new-study model
loads/forwards at creation and hashes code, model artifacts, implementations,
schedule, ensemble map and tokenization metadata. All 4,800 input token sequences
and context-sensitive candidate IDs match between the two smaller tokenizers.
Runtime settings and the synthetic parity tolerances follow Section 6.1. Three
native warmups and 27 forwards per smaller checkpoint are excluded. Failures are
retained without replacements or automatic retries; a failed orbit remains
unavailable. Existing result directories cannot be overwritten.

There is no new identical-prompt repeat control or equal-call repeated-baseline
comparison. Earlier repeat findings remain historical evidence. Summed measured
member durations quantify computation, not optimized ensemble-serving latency.

### 7.4 Prespecified estimands and uncertainty

Primary quality compares cyclic-forward with canonical-single predictions on the
same complete items. JCoLA reports accuracy, MCC, balanced accuracy, both recalls
and gold/predicted class counts. JCQA reports accuracy, class marginals and paired
transitions. JSTS reports expected-score MAE against continuous gold, with
hard-stage MAE and prediction variance as secondary descriptions. Undefined MCC
is retained as unavailable. Positive accuracy/MCC changes and negative MAE
changes favor averaging; reverse-pool and dihedral quality are secondary.

The primary empirical stability comparison on JCQA is the cyclic-orientation
flip rate minus the single baseline/reversal flip rate. On JSTS it is the mean
absolute cyclic-orientation expected-score difference minus its single-prompt
counterpart. Negative values indicate less observed sensitivity. JCoLA receives
no empirical orientation interval because its pools are identical by definition.
Total variation, normalized Jensen–Shannon divergence, full candidate
distributions, exact ties, every physical order's quality and incomplete-pool
counts accompany these estimates.

Uncertainty uses 2,000 paired whole-group bootstrap replicates, seed 2026092203,
and two-sided 95% percentile intervals. JCoLA bibliography groups are sampled
within each split; rescaling each sampled stratum to its original item count
preserves the 100/100 mixture despite unequal group sizes. JSTS uses full
components and JCQA exact-question groups. All methods remain paired by item.
Combined JCoLA intervals would be omitted if sources crossed strata; none do in
this selection. Intervals are unavailable with fewer than two groups per stratum
or undefined replicate estimates. The ten in-domain groups warrant particular
caution. Intervals are descriptive and unadjusted for multiple comparisons; no
significance dichotomy or universal-superiority claim is made.

## 8. Completed order-ensemble results

All 14,400 scheduled requests completed without inference errors, invalid records
or missing requests. All 9,000 derived answers were available; 33,600 logical
member references reused those 14,400 physical requests. No exact tie occurred
in any of the five derived methods for any checkpoint. The combined
[independent computational audit](study_v1/AUDIT.json) passed 283 checks,
including coverage, semantic mapping, probability means, metrics and bootstrap
reconstruction, without additional model inference. The auditor was a separate
AI agent, not an independent human reviewer.

### 8.1 Native accounting and primary quality

The native checkpoint completed all 4,800 scheduled requests, with zero inference
errors, invalid records or missing requests. All 3,000 derived answers—five
methods on each of 600 items—were available. Their 11,200 logical member references
reuse 4,800 unique physical requests; they are not 11,200 separate evaluations.
The measured requests generated zero answer tokens and made 4,800 native decode
calls, plus three excluded warmups. No exact tie occurred in any of the five
derived answer methods. An independent [native audit](study_v1/AUDIT.native.json)
passed all 99 checks, including reconstruction of the 2,000 bootstrap replicates.

The table reports the prespecified cyclic-forward minus single-baseline quality
comparison. Each row has 200 complete paired items. Intervals are the descriptive
paired group-bootstrap intervals specified in Section 7.4; percentage-point
units are explicit for accuracy.

| Outcome | Single baseline | Cyclic forward | Paired change | Descriptive 95% interval |
|---|---:|---:|---:|---:|
| JCoLA accuracy (%) | 86.5 | 86.5 | 0.0 pp | [−1.415, +1.095] pp |
| JCoLA MCC | 0.59028 | 0.59672 | +0.00644 | [−0.03221, +0.03876] |
| JCQA accuracy (%) | 98.5 | 98.0 | −0.5 pp | [−2.0, +1.0] pp |
| JSTS expected-score MAE | 0.52405 | 0.48568 | −0.03837 | [−0.06942, −0.00834] |

JCoLA balanced accuracy changed from 0.78736 to 0.79581. True-class recall
changed from 0.92357 to 0.91720 and false-class recall from 0.65116 to 0.67442.
Predicted false/true counts changed from 40/160 to 42/158, against gold counts
43/157, so these outputs were not constant. Accuracy remained unchanged despite
changed classifications. On JCQA, averaging yielded one fewer correct answer
than the fixed single baseline. On JSTS, expected-score MAE decreased by 0.03837
on the original 0–5 scale; hard-stage MAE changed from 0.589 to 0.586. The
across-item expected-score variance changed from 2.63663 to 2.47285, a descriptive
change rather than a correctness measure. These comparisons are within the new
panel; the earlier panel's different baseline accuracy is not a treatment effect.

### 8.2 Orientation sensitivity and cost

| Prespecified stability outcome | Single baseline/reversal | Forward/reverse cyclic pools | Paired change | Descriptive 95% interval |
|---|---:|---:|---:|---:|
| JCQA semantic flip rate (%) | 4.5 (9/200) | 1.5 (3/200) | −3.0 pp | [−6.0, 0.0] pp |
| JSTS mean absolute expected-score difference | 0.15404 | 0.06589 | −0.08815 | [−0.10777, −0.07045] |

Observed JCQA orientation flips decreased while its primary accuracy decreased
slightly; stability and quality therefore did not move together in this task.
JSTS had lower orientation sensitivity and lower MAE against the fixed baseline.
Mean total variation changed from 0.07646 to 0.05981 on JCQA and from 0.11611 to
0.06004 on JSTS. JCoLA single predictions differed in 9/200 cases, but the two
cyclic orientations were identical because they reuse the same two requests.
That equality is structural and receives no empirical robustness interval.

Single-baseline versus cyclic-forward mean summed member durations were
0.280 versus 0.560 seconds for JCoLA, 0.268 versus 1.341 seconds for JCQA, and
0.391 versus 2.333 seconds for JSTS. The physical call costs were 1→2, 1→5 and
1→6 respectively. These are observed sums of serial member durations, not a
benchmark of an optimized ensemble endpoint or a claim of faster inference.

Secondary methods are retained rather than selected to replace the primary
comparison:

| Method | JCoLA accuracy (%) / MCC | JCQA accuracy (%) | JSTS expected-score MAE |
|---|---:|---:|---:|
| Canonical single | 86.5 / 0.59028 | 98.5 | 0.52405 |
| Reversed single | 85.0 / 0.56324 | 95.5 | 0.47468 |
| Cyclic forward | 86.5 / 0.59672 | 98.0 | 0.48568 |
| Cyclic reverse | 86.5 / 0.59672 | 97.5 | 0.47846 |
| Dihedral diagnostic | 86.5 / 0.59672 | 98.5 | 0.48163 |

The reversed single JSTS prompt had lower MAE than either cyclic orientation;
averaging was not uniformly better than all individual presentations. Conversely,
choosing that reversed prompt because of these outcomes would create a new
selection procedure, not the prespecified method evaluated here. Full split-wise
metrics, distributions, marginals, ties and secondary intervals are retained in
the [native analysis](study_v1/analysis/qwen3.6-35b-a3b/SUMMARY.json).

### 8.3 The 0.5B replication: reduced sensitivity with limited discrimination

Qwen2.5-0.5B-Instruct also completed all 4,800 scheduled requests without inference
errors, invalid records or missing requests. All 3,000 derived answers were
available and had no exact ties. Its 4,827 actual model forwards comprise 4,800
measurements and 27 excluded synthetic gate/warmup forwards; generated answer
tokens were zero. The independent [0.5B audit](study_v1/AUDIT.0.5b.json) passed
115 checks, including bootstrap reconstruction, without additional inference.

| Primary quality outcome | Single baseline | Cyclic forward | Paired change | Descriptive 95% interval |
|---|---:|---:|---:|---:|
| JCoLA accuracy (%) | 23.0 | 78.5 | +55.5 pp | [+44.858, +67.911] pp |
| JCoLA MCC | 0.00585 | Undefined | Undefined | Unavailable |
| JCQA accuracy (%) | 39.5 | 36.0 | −3.5 pp | [−8.5, +1.5] pp |
| JSTS expected-score MAE | 1.46532 | 1.25714 | −0.20818 | [−0.31694, −0.10040] |

The large JCoLA accuracy increase is a majority-class collapse, not evidence of
improved grammatical discrimination. Baseline false/true predictions were 195/5;
cyclic averaging predicted true for all 200 items, matching the 157/200 gold
majority. Balanced accuracy changed from 0.50111 to 0.50000, with true/false recalls
becoming 1/0. Both the MCC change and all 2,000 bootstrap replicate changes were
undefined; the analysis retains that unavailability rather than assigning zero.
Reversed-single, reverse-cyclic and dihedral outputs were also all true.

| Primary stability outcome | Single baseline/reversal | Forward/reverse cyclic pools | Paired change | Descriptive 95% interval |
|---|---:|---:|---:|---:|
| JCQA semantic flip rate (%) | 65.5 (131/200) | 30.5 (61/200) | −35.0 pp | [−43.5, −26.5] pp |
| JSTS mean absolute expected-score difference | 1.43537 | 0.07510 | −1.36027 | [−1.37815, −1.34193] |

Reduced orientation sensitivity again did not imply better classification.
JCQA's cyclic accuracy decreased, and output option_3 became more frequent:
142/200 baseline versus 155/200 cyclic predictions, against 42/200 gold labels.
The JSTS expected-score MAE decreased, but predictions varied little across items:
expected-score variance was 0.00151 at baseline and 0.00457 after averaging.
Baseline hard labels were stage 4 throughout; cyclic-forward labels were stage 4
for 199/200 items, and its hard-stage MAE increased from 1.851 to 1.865. A lower
continuous MAE and orientation difference therefore do not establish fine-grained
semantic discrimination. JCoLA's zero cyclic orientation difference remains
structural, despite 195/200 single-prompt flips.

After observing the 0.5B variance and MAE results, we added an explicitly
**post-hoc descriptive reference**: predict the fixed scale midpoint 2.5 for
every JSTS item. This value follows from the scale endpoints, was not fitted from
gold scores, and was not included in the frozen protocol. It yields MAE 1.25100
on the 200 new items, slightly below the 0.5B cyclic MAE of 1.25714. Thus the
observed improvement over that model's single baseline does not beat this
trivial constant. The native cyclic MAE is 0.48568. The
[diagnostic receipt](POSTHOC_MIDPOINT_DIAGNOSTIC.json) records its choice after
observing the 0.5B results, timestamp, source hashes and zero additional model
calls. The choice at 02:41:56 UTC followed the start of 1.5B inference at
02:37:42 UTC and preceded its analysis; it was not fixed before that checkpoint's
inference. It supplies no significance test and does not replace the primary
comparison. The same 2.5 reference was retained for the completed 1.5B analysis.
The separate [completed-comparisons receipt](POSTHOC_MIDPOINT_COMPLETED.json)
preserves the original diagnostic timestamp and hash; the original snapshot was
not overwritten.

| Secondary method accounting | JCoLA accuracy (%) / MCC | JCQA accuracy (%) | JSTS expected-score MAE |
|---|---:|---:|---:|
| Canonical single | 23.0 / 0.00585 | 39.5 | 1.46532 |
| Reversed single | 78.5 / Undefined | 37.5 | 1.31411 |
| Cyclic forward | 78.5 / Undefined | 36.0 | 1.25714 |
| Cyclic reverse | 78.5 / Undefined | 35.0 | 1.26054 |
| Dihedral diagnostic | 78.5 / Undefined | 34.5 | 1.25832 |

Single-baseline versus cyclic-forward mean summed durations were 0.075 versus
0.150 seconds for JCoLA, 0.071 versus 0.357 seconds for JCQA and 0.123 versus
0.742 seconds for JSTS, with the same 1→2/5/6 call costs. These within-model sums
do not support a latency ranking against the differently configured native
checkpoint. Full outcomes and intervals are in the
[0.5B analysis](study_v1/analysis/qwen2.5-0.5b/SUMMARY.json).

### 8.4 The 1.5B replication: task-dependent changes

Qwen2.5-1.5B-Instruct completed all 4,800 requests and 3,000 derived answers,
with no inference errors, invalid records, missing requests or derived-answer
ties. Its 4,827 actual forwards include 27 excluded synthetic gate/warmup calls;
answer-token generation remained zero. Its complete results are covered by the
combined 283-check audit.

| Primary quality outcome | Single baseline | Cyclic forward | Paired change | Descriptive 95% interval |
|---|---:|---:|---:|---:|
| JCoLA accuracy (%) | 79.0 | 79.0 | 0.0 pp | [0.0, 0.0] pp |
| JCoLA MCC | 0.13545 | 0.13545 | 0.00000 | Unavailable |
| JCQA accuracy (%) | 80.0 | 83.5 | +3.5 pp | [−1.0, +8.0] pp |
| JSTS expected-score MAE | 1.27583 | 1.27161 | −0.00422 | [−0.01544, +0.00663] |

JCoLA outputs were nearly constant: the same 199 true and one false prediction
occurred under every method. True recall was 100%, false recall 2.326%, and
balanced accuracy 51.163%. Its accuracy difference is exactly zero on these
identical paired decisions. MCC is defined on the observed panel but becomes
undefined in 717 of 2,000 bootstrap replicates, so its difference interval is
unavailable under the fixed analysis rule. Neither the zero flip rate nor the
79% accuracy establishes useful acceptability discrimination.

JCQA cyclic-forward accuracy was seven answers higher than the canonical single
baseline. Counts over option_0 through option_4 changed from (26, 39, 48, 56, 31)
to (29, 43, 44, 43, 41), against gold counts (32, 45, 41, 42, 40). In contrast,
JSTS hard predictions remained stage 3 on all 200 items, with hard-stage MAE
1.293 under both primary methods. Expected-score variance changed from 0.00341
to 0.01044. Its cyclic expected-score MAE exceeded the fixed midpoint reference
1.25100 by 0.02061. Both smaller checkpoints therefore failed to beat that
post-hoc constant despite lower MAE point estimates than their own baselines.

| Primary stability outcome | Single baseline/reversal | Forward/reverse cyclic pools | Paired change | Descriptive 95% interval |
|---|---:|---:|---:|---:|
| JCQA semantic flip rate (%) | 26.0 (52/200) | 12.5 (25/200) | −13.5 pp | [−20.013, −7.0] pp |
| JSTS mean absolute expected-score difference | 0.10073 | 0.05916 | −0.04157 | [−0.04993, −0.03306] |

The nonbinary orientation measures decreased, while JCoLA orientation equality
remained structural. JCQA mean total variation changed from 0.26852 to 0.14638,
and JSTS from 0.11618 to 0.04509. Lower orientation sensitivity again coexisted
with limited score variation across items.

| Secondary method accounting | JCoLA accuracy (%) / MCC | JCQA accuracy (%) | JSTS expected-score MAE |
|---|---:|---:|---:|
| Canonical single | 79.0 / 0.13545 | 80.0 | 1.27583 |
| Reversed single | 79.0 / 0.13545 | 72.0 | 1.26633 |
| Cyclic forward | 79.0 / 0.13545 | 83.5 | 1.27161 |
| Cyclic reverse | 79.0 / 0.13545 | 79.0 | 1.25727 |
| Dihedral diagnostic | 79.0 / 0.13545 | 82.0 | 1.26441 |

Single-baseline versus cyclic-forward mean summed durations were 0.228 versus
0.457 seconds for JCoLA, 0.219 versus 1.096 seconds for JCQA and 0.377 versus
2.255 seconds for JSTS, again costing 1→2/5/6 model evaluations. The
[1.5B analysis](study_v1/analysis/qwen2.5-1.5b/SUMMARY.json) retains all split-wise
results, prediction distributions, secondary intervals and unavailable estimates.

## 9. Discussion and limitations

The completed experiments establish an observed equivalence between direct
candidate readout and matched native one-token selection, alongside sensitivity
to some candidate presentations. They support treating answer validity, task
quality, individual stability and candidate concentration as distinct properties.
They do not establish that direct readout uniquely causes these sensitivities:
display changes alter positions and contextual conditioning simultaneously.

The prospectively frozen averaging experiment evaluated a particular fixed rule
at additional call cost. Its nonbinary orientation point estimates decreased
across all three checkpoints, while JCQA accuracy decreased on the native and
0.5B models and increased on the 1.5B model. On native JSTS, the prespecified
cyclic method improved MAE against the canonical single baseline, but the
reversed single prompt had still lower MAE. The smaller checkpoints' lower
orientation differences coexisted with nearly constant scores, and their cyclic
MAE did not beat a post-hoc fixed midpoint. These findings support a joint
quality–stability assessment, not a claim of uniformly better decisions.

Any reduction in loss relative to the average member loss, or distance
relative to averaged member distances, may follow convexity or a triangle
inequality. Its primary comparison instead uses fixed single baselines, for
which improvement is not guaranteed. Structural invariance alone is insufficient:
a constant incorrect or majority-class predictor can also be invariant.

Several limits constrain all stages. Data are small subsets of public
development releases; model-training exposure is unknown. Repeated measurements
and shared panels do not increase the independent item count. The original JSTS
panel included six rows sharing text/images with an earlier JNLI pilot, including
three identical ordered pairs; the new selection specifically removes measured
literal/component reuse but retains other dependencies. JCoLA source overlap
and few in-domain groups limit extrapolation even in the new panel. Fixed
rewordings lack independent human equivalence validation.

The checkpoints differ in family/version, architecture, quantization and runtime.
Their differences cannot identify a causal model-size effect or support a fair
cross-backend latency ranking. The matched systems comparison is restricted to
one machine/session and includes instrumentation overhead. The new ensemble
study lacks an equal-call alternative and is not a replication of prior
content-rebinding baselines. These are priorities for subsequent experiments,
not results supplied by the present runs. No claim of calibrated correctness,
new output-head learning, deployment reliability or comparison with proprietary
Jev is made. A systematic literature review and a venue-specific submission
check remain necessary before journal submission.

## 10. Reproducibility, data and AI assistance

Frozen schedules, artifact hashes, semantic mappings, candidate logits,
probabilities, counters and completion receipts support the reported analyses.
Source benchmark text and model weights are not bundled in the public output.
Generic software is MIT-licensed; dataset-derived artifacts retain the applicable
CC BY-SA 4.0 terms and upstream attribution. Local freezes document temporal
ordering within the project, not independent public preregistration.

The original matched evidence is in [the matched study](../matched_study/REPORT.md).
The completed robustness evidence is in [the empirical results draft](../journal_robustness/JOURNAL_RESULTS_DRAFT.md)
and its linked raw records and audits. New-study design evidence comprises the
[protocol](PROTOCOL.json), [data freeze](DATA_FREEZE.json),
[selected IDs](SELECTION.json), [provenance](DATA_PROVENANCE.json),
[execution freeze](study_v1/FREEZE.json), and [expanded methods](METHODS_DRAFT.md).
Verified native ensemble evidence is in the [analysis](study_v1/analysis/qwen3.6-35b-a3b/SUMMARY.json)
and [99-check audit](study_v1/AUDIT.native.json); verified 0.5B evidence is in its
[analysis](study_v1/analysis/qwen2.5-0.5b/SUMMARY.json) and
[115-check audit](study_v1/AUDIT.0.5b.json). The completed
[1.5B analysis](study_v1/analysis/qwen2.5-1.5b/SUMMARY.json) and
[combined 283-check audit](study_v1/AUDIT.json) cover all three checkpoints. The separate
[post-hoc midpoint diagnostic](POSTHOC_MIDPOINT_DIAGNOSTIC.json) records its
later choice explicitly; it is not part of the prespecified protocol. Its
[completed comparisons](POSTHOC_MIDPOINT_COMPLETED.json) preserve the original
snapshot's hash and choice time. The standalone [reproduction script](posthoc_midpoint.py)
recomputes the fixed reference and comparisons without model inference.

AI coding agents accessed through OpenAI Codex assisted with implementation,
question authoring in earlier local evaluations, software checks, experiment
execution, analysis, literature organization and manuscript drafting under the
author's direction. Independent computational audits were performed by separate
AI agents; they are not independent human peer review. Earlier AI-authored local
questions were not human-expert validated. The human author is responsible for
checking all claims, references, data use and the final submitted manuscript.

## References

1. Almeida, D. (15 September 2026). [Introducing System One Models & Jev](https://typesafe.ai/blog/introducing-system-one-models-and-jev). TypeSafe. Interface inspiration only.
2. Schick, T., and Schütze, H. (2021). [Exploiting Cloze-Questions for Few-Shot Text Classification and Natural Language Inference](https://aclanthology.org/2021.eacl-main.20/). EACL.
3. Zhang, Y., et al. (2025). [Qwen3 Embedding: Advancing Text Embedding and Reranking Through Foundation Models](https://arxiv.org/abs/2506.05176). arXiv:2506.05176. See also the [official Qwen3-Reranker inference example](https://huggingface.co/Qwen/Qwen3-Reranker-8B).
4. Geng, S., Josifoski, M., Peyrard, M., and West, R. (2023). [Grammar-Constrained Decoding for Structured NLP Tasks without Finetuning](https://aclanthology.org/2023.emnlp-main.674/). EMNLP.
5. Guo, C., Pleiss, G., Sun, Y., and Weinberger, K. Q. (2017). [On Calibration of Modern Neural Networks](https://proceedings.mlr.press/v70/guo17a.html). ICML.
6. Zhao, Z., Wallace, E., Feng, S., Klein, D., and Singh, S. (2021). [Calibrate Before Use: Improving Few-shot Performance of Language Models](https://proceedings.mlr.press/v139/zhao21c.html). ICML.
7. Pezeshkpour, P., and Hruschka, E. (2024). [Large Language Models Sensitivity to The Order of Options in Multiple-Choice Questions](https://aclanthology.org/2024.findings-naacl.130/). Findings of NAACL.
8. Zheng, C., Zhou, H., Meng, F., Zhou, J., and Huang, M. (2024). [Large Language Models Are Not Robust Multiple Choice Selectors](https://proceedings.iclr.cc/paper_files/paper/2024/hash/54dd9e0cff6d9214e20d97eb2a3bae49-Abstract-Conference.html). ICLR. See [version 4, Section 3.1, Equation 1](https://arxiv.org/html/2309.03882v4#S3.SS1) for cyclic permutation averaging.
9. Someya, T., Sugimoto, Y., and Oseki, Y. (2024). [JCoLA: Japanese Corpus of Linguistic Acceptability](https://aclanthology.org/2024.lrec-main.828/). LREC-COLING. The study pins [the source repository](https://github.com/osekilab/JCoLA/tree/736d9eef3af04bb17e4cf59adf01325973234ff9).
10. Kurihara, K., Kawahara, D., and Shibata, T. (2022). [JGLUE: Japanese General Language Understanding Evaluation](https://aclanthology.org/2022.lrec-1.317/). LREC. The study pins [the source repository](https://github.com/yahoojapan/JGLUE/tree/6f071c09316baae89c3d083a90985b4b1cb9968c).
