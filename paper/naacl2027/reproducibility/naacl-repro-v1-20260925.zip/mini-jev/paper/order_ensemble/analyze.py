#!/usr/bin/env python3
"""Frozen equal-weight cyclic-probability ensemble analysis; no inference.

Physical request accounting is separate from derived answers. K=2 orbit identity
and the full dihedral set's invariance are structural facts, not measured gains.
Cluster intervals are descriptive and unadjusted, not significance decisions.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics

BOOTSTRAP_REPLICATES = 2000
BOOTSTRAP_SEED = 2026092203
TOL = 1e-6
METHODS = ("baseline", "reverse_single", "cyclic_forward", "cyclic_reverse", "dihedral")
MODELS = {"qwen3.6-35b-a3b": "llama.cpp", "qwen2.5-0.5b": "transformers", "qwen2.5-1.5b": "transformers"}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def percentile(values, q):
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered)-1)*q
    lo, hi = math.floor(position), math.ceil(position)
    return ordered[lo] + (position-lo)*(ordered[hi]-ordered[lo])


def divergences(p, q):
    if set(p) != set(q):
        raise ValueError("canonical_candidate_set_mismatch")
    tv = math.fsum(abs(p[key]-q[key]) for key in p)/2
    js = 0.0
    for key in p:
        mean = (p[key]+q[key])/2
        for value in (p[key], q[key]):
            if value:
                js += .5*value*math.log(value/mean)
    return tv, max(0.0, min(1.0, js/math.log(2)))


def typed_answer(probabilities, keys, kind, score_values=None):
    """Tie order is the prospectively fixed semantic order, never map insertion order."""
    if len(keys) < 2 or len(set(keys)) != len(keys) or set(probabilities) != set(keys):
        raise ValueError("invalid_canonical_candidate_keys")
    if any(not finite(v) or not 0 <= v <= 1 for v in probabilities.values()) or not math.isclose(math.fsum(probabilities.values()), 1, abs_tol=TOL):
        raise ValueError("invalid_probability_distribution")
    index = max(range(len(keys)), key=lambda i: probabilities[keys[i]])
    label = keys[index]
    peak = probabilities[label]
    if kind == "choice":
        value = label
    elif kind == "noul" and set(keys) == {"false", "true"}:
        value = probabilities["true"]
    elif kind == "score" and isinstance(score_values, dict) and set(score_values) == set(keys):
        if any(not finite(v) for v in score_values.values()):
            raise ValueError("invalid_score_scale")
        value = math.fsum(score_values[key]*probabilities[key] for key in keys)
    else:
        raise ValueError("invalid_typed_semantics")
    return {"probabilities": {key: probabilities[key] for key in keys}, "label": label,
            "typed_value": value, "tie_keys": [key for key in keys if probabilities[key] == peak],
            "max_candidate_probability": peak}


def average_probabilities(vectors, keys):
    if not vectors:
        raise ValueError("empty_ensemble")
    for vector in vectors:
        if set(vector) != set(keys) or any(not finite(v) or not 0 <= v <= 1 for v in vector.values()) or not math.isclose(math.fsum(vector.values()), 1, abs_tol=TOL):
            raise ValueError("invalid_member_distribution")
    return {key: math.fsum(vector[key] for vector in vectors)/len(vectors) for key in keys}


def mcc(confusion):
    tp, tn, fp, fn = (confusion.get(key, 0) for key in ("tp", "tn", "fp", "fn"))
    denominator = math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    return (tp*tn-fp*fn)/denominator if denominator else None


def confusion_category(label, gold):
    return "tp" if label == gold == "true" else "tn" if label == gold == "false" else "fp" if label == "true" else "fn"


def quality(records):
    if not records:
        return {"n": 0, "accuracy": None, "mcc": None, "expected_score_mae": None,
                "label_counts": {}, "gold_label_counts": {}, "exact_tie_answers": 0}
    kind = records[0]["type"]
    result = {"n": len(records), "label_counts": dict(sorted(Counter(r["label"] for r in records).items())),
              "exact_tie_answers": sum(len(r["tie_keys"]) > 1 for r in records),
              "group_count": len({r["group"] for r in records})}
    if kind == "score":
        result["expected_score_mae"] = statistics.mean(abs(r["typed_value"]-r["gold_score"]) for r in records)
        result["hard_stage_mae"] = statistics.mean(abs(r["score_values"][r["label"]]-r["gold_score"]) for r in records)
        result["expected_score_variance_across_items"] = statistics.pvariance(r["typed_value"] for r in records)
    else:
        result["accuracy"] = sum(r["label"] == r["gold_label"] for r in records)/len(records)
        result["gold_label_counts"] = dict(sorted(Counter(r["gold_label"] for r in records).items()))
        if records[0]["dataset"] == "JCoLA":
            counts = Counter(confusion_category(r["label"], r["gold_label"]) for r in records)
            result.update({key: counts[key] for key in ("tp", "tn", "fp", "fn")})
            result["mcc"] = mcc(counts)
            result["mcc_undefined"] = result["mcc"] is None
            positive_n, negative_n = counts["tp"]+counts["fn"], counts["tn"]+counts["fp"]
            result["recall_true"] = counts["tp"]/positive_n if positive_n else None
            result["recall_false"] = counts["tn"]/negative_n if negative_n else None
            result["balanced_accuracy"] = (result["recall_true"]+result["recall_false"])/2 if positive_n and negative_n else None
    return result


def paired_quality_sufficient(pair):
    a, b = pair
    value = {"n": 1.0}
    if a["type"] == "score":
        value["expected_score_mae_difference_sum"] = abs(b["typed_value"]-b["gold_score"])-abs(a["typed_value"]-a["gold_score"])
    else:
        value["accuracy_difference_sum"] = float(b["label"] == b["gold_label"])-float(a["label"] == a["gold_label"])
        if a["dataset"] == "JCoLA":
            for prefix, row in (("a_", a), ("b_", b)):
                for key in ("tp", "tn", "fp", "fn"):
                    value[prefix+key] = float(confusion_category(row["label"], row["gold_label"]) == key)
    return value


def quality_difference_from_sums(sums):
    if not sums.get("n"):
        return {}
    result = {key[:-4]: value/sums["n"] for key, value in sums.items() if key.endswith("_sum")}
    if "a_tp" in sums:
        first = mcc({key: sums["a_"+key] for key in ("tp", "tn", "fp", "fn")})
        second = mcc({key: sums["b_"+key] for key in ("tp", "tn", "fp", "fn")})
        result["mcc_difference"] = None if first is None or second is None else second-first
        recalls = {}
        for prefix in ("a_", "b_"):
            for name, numerator, denominator_keys in (("recall_true", "tp", ("tp", "fn")), ("recall_false", "tn", ("tn", "fp"))):
                denom = math.fsum(sums[prefix+k] for k in denominator_keys)
                recalls[prefix+name] = sums[prefix+numerator]/denom if denom else None
        for name in ("recall_true", "recall_false"):
            result[name+"_difference"] = None if recalls["a_"+name] is None or recalls["b_"+name] is None else recalls["b_"+name]-recalls["a_"+name]
        result["balanced_accuracy_difference"] = None if any(result[k+"_difference"] is None for k in ("recall_true", "recall_false")) else (result["recall_true_difference"]+result["recall_false_difference"])/2
    return result


def cluster_intervals(records, group_of, sufficient, estimates, scope, replicates=BOOTSTRAP_REPLICATES, stratum_of=None):
    """Resample whole source groups; undefined replicates are counted, never hidden.

    For stratified JCoLA, sample source groups independently within each split,
    then rescale each stratum's sufficient statistics to its original item count.
    Any bibliographic source shared across strata is disclosed as a limitation.
    An interval is omitted if any replicate is undefined or fewer than 2 groups.
    """
    groups = defaultdict(lambda: defaultdict(float))
    for record in records:
        group = groups[(stratum_of(record) if stratum_of else "all", group_of(record))]
        for key, value in sufficient(record).items():
            group[key] += value
    names = sorted(groups)
    by_stratum = {stratum: [name for name in names if name[0] == stratum] for stratum in sorted({name[0] for name in names})}
    stratum_counts = {stratum: math.fsum(groups[name]["n"] for name in members) for stratum, members in by_stratum.items()}
    shared = sorted(name for name, count in Counter(name[1] for name in names).items() if count > 1)
    totals = defaultdict(float)
    for group in groups.values():
        for key, value in group.items():
            totals[key] += value
    point = estimates(totals)
    seed = BOOTSTRAP_SEED + int(hashlib.sha256(scope.encode()).hexdigest()[:16], 16)
    samples = {key: [] for key in point}
    enough_groups = bool(names) and all(len(members) >= 2 for members in by_stratum.values()) and not (stratum_of and shared)
    if enough_groups:
        rng = random.Random(seed)
        for _ in range(replicates):
            sums = defaultdict(float)
            for stratum, members in by_stratum.items():
                subtotal = defaultdict(float)
                for _ in members:
                    for key, value in groups[members[rng.randrange(len(members))]].items():
                        subtotal[key] += value
                scale = stratum_counts[stratum]/subtotal["n"] if stratum_of else 1
                for key, value in subtotal.items():
                    sums[key] += value*scale
            current = estimates(sums)
            for key in samples:
                samples[key].append(current.get(key))
    result = {"group_count": len({name[1] for name in names}), "stratum_group_counts": {key: len(value) for key, value in by_stratum.items()},
              "original_stratum_item_counts": stratum_counts, "shared_groups_across_strata": shared,
              "stratum_normalization": "Sample whole source groups within each stratum; rescale each sampled stratum to its original item count." if stratum_of else "No stratum normalization.",
              "replicates_requested": replicates,
              "resampling_unit": "complete source group within the reported dataset/split scope",
              "small_group_warning": any(len(members) < 20 for members in by_stratum.values()),
              "cross_stratum_dependency_warning": bool(shared), "seed": seed, "metrics": {}}
    result["combined_interval_omitted_for_shared_source"] = bool(stratum_of and shared)
    for key, value in point.items():
        valid = [v for v in samples[key] if finite(v)]
        usable = finite(value) and enough_groups and len(valid) == replicates
        result["metrics"][key] = {"estimate": value,
                                  "ci95_lower": percentile(valid, .025) if usable else None,
                                  "ci95_upper": percentile(valid, .975) if usable else None,
                                  "defined_replicates": len(valid),
                                  "undefined_replicates": len(samples[key])-len(valid),
                                  "interval_available": usable}
    return result


def validate_prediction(row):
    errors = []
    if type(row.get("request_index")) is not int or row["request_index"] < 0:
        return ["invalid_request_index"]
    if any(key in row for key in ("state", "messages", "prompt", "input_ids", "instructions", "criteria", "question", "text", "sentence", "sentence1", "sentence2")):
        errors.append("private_input_fields_forbidden")
    keys, logits, probs = row.get("candidate_keys"), row.get("logits"), row.get("probabilities")
    if not isinstance(keys, list) or any(not isinstance(k, str) for k in keys) or len(keys) < 2 or len(set(keys)) != len(keys):
        return errors+["invalid_candidate_keys"]
    if not isinstance(logits, list) or len(logits) != len(keys) or any(not finite(v) for v in logits):
        return errors+["invalid_logits"]
    if not isinstance(probs, dict):
        return errors+["missing_probabilities"]
    try:
        derived = typed_answer(probs, keys, row.get("type"), row.get("score_values"))
    except (ValueError, TypeError):
        return errors+["invalid_probability_or_semantic_contract"]
    peak = max(logits)
    weights = [math.exp(value-peak) for value in logits]
    total = math.fsum(weights)
    if any(abs(probs[key]-weight/total) > TOL for key, weight in zip(keys, weights)):
        errors.append("probabilities_not_t1_softmax")
    if row.get("label") != keys[max(range(len(keys)), key=logits.__getitem__)] or row.get("label") != derived["label"]:
        errors.append("label_not_vector_argmax")
    if row.get("type") == "choice":
        if row.get("typed_value") != derived["typed_value"]:
            errors.append("incorrect_choice_value")
    elif not finite(row.get("typed_value")) or abs(row["typed_value"]-derived["typed_value"]) > TOL:
        errors.append("incorrect_numeric_value")
    if row.get("dataset") == "JSTS":
        if row.get("score_values") != {str(i): i for i in range(6)} or not finite(row.get("gold_score")) or not 0 <= row["gold_score"] <= 5:
            errors.append("invalid_continuous_jsts_scale")
    elif row.get("gold_label") not in keys:
        errors.append("invalid_gold_label")
    if type(row.get("input_tokens")) is not int or not 1 <= row["input_tokens"] <= 2048:
        errors.append("invalid_input_tokens")
    if type(row.get("output_tokens")) is not int or row["output_tokens"] != 0:
        errors.append("output_tokens_must_be_zero")
    if not finite(row.get("latency_ms")) or row["latency_ms"] < 0:
        errors.append("invalid_latency_ms")
    if row.get("temperature") != 1:
        errors.append("temperature_must_be_one")
    if row.get("model_key") not in MODELS or MODELS.get(row.get("model_key")) != row.get("backend"):
        errors.append("model_backend_mismatch")
    ids = row.get("candidate_ids")
    if not isinstance(ids, list) or len(ids) != len(keys) or any(type(i) is not int or i < 0 for i in ids) or len(set(ids)) != len(ids):
        errors.append("invalid_candidate_ids")
    if not finite(row.get("model_ms")) or row["model_ms"] < 0 or (finite(row.get("latency_ms")) and row["model_ms"] > row["latency_ms"]+TOL):
        errors.append("invalid_model_ms")
    if row.get("canonical_key_order") != keys:
        errors.append("candidate_vector_must_preserve_canonical_key_order")
    if row.get("backend") == "transformers":
        if type(row.get("forward_calls")) is not int or row["forward_calls"] != 1:
            errors.append("forward_calls_must_be_one")
        for field, expected in (("use_cache", False), ("past_key_values_returned", False),
                                ("model_training", False), ("grad_enabled", False),
                                ("parameters_require_grad", False), ("inference_mode_enabled", True),
                                ("candidate_boundary_verified", True)):
            if row.get(field) is not expected:
                errors.append("invalid_"+field)
        if row.get("batch_size") != 1 or row.get("logits_to_keep") != 1:
            errors.append("invalid_forward_shape_contract")
        if "native_decode_count" in row:
            errors.append("fabricated_native_counter_forbidden")
        if row.get("forward_calls_total") != row.get("request_index", -100)+28:
            errors.append("cumulative_forward_count_mismatch")
    elif row.get("backend") in ("native", "llama.cpp", "llama_cpp"):
        if type(row.get("native_decode_count")) is not int or row["native_decode_count"] != 1:
            errors.append("native_decode_count_must_be_one")
        if row.get("state_cleared") is not True or row.get("thinking_enabled") is not False:
            errors.append("invalid_native_state_contract")
        if "forward_calls" in row:
            errors.append("fabricated_transformers_counter_forbidden")
        if row.get("native_total_decode_count") != row.get("request_index", -100)+4:
            errors.append("cumulative_native_count_mismatch")
    else:
        errors.append("unsupported_backend")
    return errors


def ensemble_members(meta):
    keys = meta["canonical_key_order"]
    forward, reverse = meta["forward_request_indices"], meta["reverse_request_indices"]
    if len(keys) < 2 or len(keys) != len(set(keys)) or len(forward) != len(keys) or len(reverse) != len(keys):
        raise ValueError("invalid_orbit_size")
    if any(type(index) is not int or index < 0 for index in forward+reverse) or len(set(forward)) != len(keys) or len(set(reverse)) != len(keys):
        raise ValueError("invalid_or_duplicate_orbit_members")
    structural = len(keys) == 2
    if meta.get("structural_orbit_identity") is not structural:
        raise ValueError("structural_identity_flag_mismatch")
    if structural and set(forward) != set(reverse):
        raise ValueError("binary_orbits_must_share_both_requests")
    if not structural and set(forward) & set(reverse):
        raise ValueError("nonbinary_cyclic_orbits_must_be_disjoint")
    if meta["baseline_request_index"] != forward[0] or meta["reverse_single_request_index"] != reverse[0]:
        raise ValueError("single_baselines_must_be_rotation_zero")
    return {"baseline": [meta["baseline_request_index"]], "reverse_single": [meta["reverse_single_request_index"]],
            "cyclic_forward": forward, "cyclic_reverse": reverse,
            "dihedral": list(dict.fromkeys(forward+reverse))}


def derive_answer(meta, method, members, lookup):
    rows = [lookup[index] for index in members]
    for row in rows:
        if any(row.get(key) != meta.get(key) for key in ("model_key", "item_id", "dataset", "split", "group", "type", "gold_label", "gold_score", "score_values")):
            raise ValueError("ensemble_member_metadata_mismatch")
        if set(row["candidate_keys"]) != set(meta["canonical_key_order"]):
            raise ValueError("ensemble_candidate_set_mismatch")
    answer = typed_answer(average_probabilities([r["probabilities"] for r in rows], meta["canonical_key_order"]),
                          meta["canonical_key_order"], meta["type"], meta.get("score_values"))
    return {**{key: meta[key] for key in ("model_key", "item_id", "dataset", "split", "group", "type", "canonical_key_order", "gold_label", "gold_score", "score_values") if key in meta},
            **answer, "method": method, "physical_member_indices": list(members),
            "physical_forwards_per_answer": len(members),
            "input_tokens_sum": sum(r["input_tokens"] for r in rows),
            "observed_forward_latency_sum_ms": math.fsum(r["latency_ms"] for r in rows),
            "structural_orbit_identity": meta["structural_orbit_identity"],
            "derivation": "equal_weight_arithmetic_mean_of_canonical_candidate_probabilities" if len(members) > 1 else "reused_single_forward_probability_vector"}


def stability_record(base, reverse, forward_ensemble, reverse_ensemble):
    single_tv, single_js = divergences(base["probabilities"], reverse["probabilities"])
    ensemble_tv, ensemble_js = divergences(forward_ensemble["probabilities"], reverse_ensemble["probabilities"])
    result = {"model_key": base["model_key"], "item_id": base["item_id"], "dataset": base["dataset"],
              "split": base["split"], "group": base["group"],
              "structural_orbit_identity": forward_ensemble["structural_orbit_identity"],
              "empirical_orientation_stability_applicable": not forward_ensemble["structural_orbit_identity"],
              "single_label_flip": base["label"] != reverse["label"],
              "cyclic_label_flip": forward_ensemble["label"] != reverse_ensemble["label"],
              "single_total_variation": single_tv, "cyclic_total_variation": ensemble_tv,
              "single_normalized_jensen_shannon": single_js, "cyclic_normalized_jensen_shannon": ensemble_js,
              "any_single_tie": len(base["tie_keys"]) > 1 or len(reverse["tie_keys"]) > 1,
              "any_ensemble_tie": len(forward_ensemble["tie_keys"]) > 1 or len(reverse_ensemble["tie_keys"]) > 1}
    result["label_flip_difference"] = float(result["cyclic_label_flip"])-float(result["single_label_flip"])
    result["total_variation_difference"] = ensemble_tv-single_tv
    if base["type"] == "score":
        result["single_absolute_expected_score_difference"] = abs(base["typed_value"]-reverse["typed_value"])
        result["cyclic_absolute_expected_score_difference"] = abs(forward_ensemble["typed_value"]-reverse_ensemble["typed_value"])
        result["absolute_expected_score_difference_change"] = result["cyclic_absolute_expected_score_difference"]-result["single_absolute_expected_score_difference"]
    return result


def scopes(rows):
    for dataset in sorted({row["dataset"] for row in rows}):
        yield dataset, "all", "", [row for row in rows if row["dataset"] == dataset]
        if dataset == "JCoLA":
            for split in sorted({row["split"] for row in rows if row["dataset"] == dataset}):
                yield dataset, "split", split, [row for row in rows if row["dataset"] == dataset and row["split"] == split]


def map_integrity(meta, planned):
    members = ensemble_members(meta)
    keys = meta["canonical_key_order"]
    for orientation, indices in (("forward", meta["forward_request_indices"]), ("reverse", meta["reverse_request_indices"])):
        base_order = keys if orientation == "forward" else list(reversed(keys))
        for rotation, index in enumerate(indices):
            row = planned.get(index)
            if row is None:
                raise ValueError("ensemble_member_not_scheduled")
            for field in ("item_id", "dataset", "split", "group", "type", "canonical_key_order", "gold_label", "gold_score", "score_values"):
                if row.get(field) != meta.get(field):
                    raise ValueError("map_schedule_metadata_mismatch")
            expected_order = base_order[rotation:]+base_order[:rotation]
            expected_name = f"{orientation}_{rotation}" if len(keys) > 2 or orientation == "forward" else f"forward_{1-rotation}"
            if row["condition"] != expected_name or row["display_order"] != expected_order:
                raise ValueError("map_rotation_or_condition_mismatch")
    return members


def analyze(predictions, schedule, ensembles, model_key, replicates=BOOTSTRAP_REPLICATES):
    if model_key not in MODELS:
        raise ValueError("unsupported_model_key")
    failures, request_status, answer_status, derived = [], [], [], []
    def fail(row, code, detail=""):
        failures.append({"request_index": row.get("request_index"), "item_id": row.get("item_id"),
                         "dataset": row.get("dataset"), "condition": row.get("condition"),
                         "method": row.get("method"), "code": code, "detail": detail})
    observed = defaultdict(list)
    for row in predictions:
        if type(row.get("request_index")) is int:
            observed[row["request_index"]].append(row)
        else:
            fail(row, "invalid_request_index")
    scheduled_counts = Counter(row["request_index"] for row in schedule)
    logical_counts = Counter((r.get("item_id"), r.get("condition")) for r in predictions)
    valid = {}
    planned = {row["request_index"]: row for row in schedule}
    for meta in schedule:
        index = meta["request_index"]
        records = observed.get(index, [])
        status, details = "valid", ""
        if scheduled_counts[index] > 1:
            status = "duplicate_schedule_index"
        elif not records:
            status = "missing_prediction"
        elif len(records) != 1:
            status = "duplicate_prediction_index"
        else:
            row = records[0]
            if logical_counts[(row.get("item_id"), row.get("condition"))] != 1:
                status = "duplicate_item_condition"
            elif row.get("model_key") != model_key or row.get("backend") != MODELS[model_key]:
                status = "model_backend_mismatch"
            elif any(row.get(key) != value for key, value in meta.items()):
                status = "schedule_metadata_mismatch"
            elif row.get("error") is not None:
                status = "inference_error"
            else:
                errors = validate_prediction(row)
                if errors:
                    status, details = "invalid_measurement", ";".join(errors)
        request_status.append({"request_index": index, "item_id": meta["item_id"], "dataset": meta["dataset"], "condition": meta["condition"], "status": status})
        if status == "valid":
            valid[index] = records[0]
        else:
            fail(meta, status, details)
    for row in predictions:
        if row.get("request_index") not in planned:
            fail(row, "unscheduled_prediction")
    map_counts = Counter((meta["dataset"], meta["item_id"]) for meta in ensembles)
    physical_map_owner = defaultdict(set)
    map_cache = {}
    for meta in ensembles:
        key = (meta["dataset"], meta["item_id"])
        try:
            if map_counts[key] != 1:
                raise ValueError("duplicate_ensemble_item")
            members = map_integrity(meta, planned)
            map_cache[key] = members
            for index in members["dihedral"]:
                physical_map_owner[index].add(key)
        except (ValueError, KeyError, TypeError) as error:
            fail(meta, "invalid_ensemble_map", str(error))
    unmapped = set(planned)-set(physical_map_owner)
    for index in sorted(unmapped):
        fail(planned[index], "scheduled_request_missing_from_ensemble_map")
    for index, owners in physical_map_owner.items():
        if len(owners) != 1:
            fail(planned[index], "physical_request_has_multiple_item_owners")
            for owner in owners:
                map_cache.pop(owner, None)
    for raw_meta in ensembles:
        meta = {**raw_meta, "model_key": model_key}
        key = (meta["dataset"], meta["item_id"])
        members = map_cache.get(key)
        for method in METHODS:
            status = "valid"
            indices = members[method] if members else []
            absent = [index for index in indices if index not in valid]
            if members is None:
                status = "invalid_ensemble_map"
            elif absent:
                status = "incomplete_member_pool"
            else:
                try:
                    derived.append(derive_answer(meta, method, indices, valid))
                except ValueError as error:
                    status = "invalid_derived_answer"
                    fail({**meta, "method": method}, status, str(error))
            answer_status.append({"item_id": meta["item_id"], "dataset": meta["dataset"], "method": method,
                                  "status": status, "required_member_count": len(indices), "unavailable_member_indices": absent})
    lookup = {(row["dataset"], row["item_id"], row["method"]): row for row in derived}
    method_quality, physical_order_quality, quality_comparisons, differences, stability = [], [], [], [], []
    for dataset, scope, split, expected in scopes(ensembles):
        prefix = {"model_key": model_key, "dataset": dataset, "scope": scope, "split": split, "n_scheduled_items": len(expected)}
        for method in METHODS:
            rows = [lookup[(dataset, meta["item_id"], method)] for meta in expected if (dataset, meta["item_id"], method) in lookup]
            costs = [r["physical_forwards_per_answer"] for r in rows]
            method_quality.append({**prefix, "method": method, **quality(rows), "n_unavailable_items": len(expected)-len(rows),
                                   "physical_forwards_per_answer": sorted(set(costs)),
                                   "total_member_references": sum(costs),
                                   "observed_forward_latency_sum_ms": math.fsum(r["observed_forward_latency_sum_ms"] for r in rows)})
        relevant = [r for r in valid.values() if r["dataset"] == dataset and (scope == "all" or r["split"] == split)]
        for condition in sorted({r["condition"] for r in schedule if r["dataset"] == dataset and (scope == "all" or r["split"] == split)}):
            rows = [{**r, **typed_answer(r["probabilities"], r["canonical_key_order"], r["type"], r.get("score_values"))} for r in relevant if r["condition"] == condition]
            physical_order_quality.append({**prefix, "condition": condition, **quality(rows), "n_unavailable_items": len(expected)-len(rows)})
        for method, reference, role in (("cyclic_forward", "baseline", "primary"), ("cyclic_reverse", "reverse_single", "secondary"), ("dihedral", "baseline", "structural_diagnostic")):
            pairs = [(lookup[(dataset, m["item_id"], reference)], lookup[(dataset, m["item_id"], method)]) for m in expected
                     if (dataset, m["item_id"], reference) in lookup and (dataset, m["item_id"], method) in lookup]
            bootstrap = cluster_intervals(pairs, lambda p: p[0]["group"], paired_quality_sufficient, quality_difference_from_sums,
                                          f"{model_key}/{dataset}/{scope}/{split}/{method}-{reference}", replicates,
                                          (lambda p: p[0]["split"]) if dataset == "JCoLA" else None)
            quality_comparisons.append({**prefix, "method": method, "reference": reference, "role": role,
                                        "n_complete_pairs": len(pairs), "n_incomplete_pairs": len(expected)-len(pairs),
                                        "reference_quality_same_items": quality([a for a, _ in pairs]),
                                        "method_quality_same_items": quality([b for _, b in pairs]), "bootstrap": bootstrap})
            if scope == "all":
                for first, second in pairs:
                    tv, js = divergences(first["probabilities"], second["probabilities"])
                    record = {"model_key": model_key, "dataset": dataset, "item_id": first["item_id"], "split": first["split"], "group": first["group"],
                              "method": method, "reference": reference, "label_changed": first["label"] != second["label"],
                              "reference_label": first["label"], "method_label": second["label"], "total_variation": tv, "normalized_jensen_shannon": js}
                    if first["type"] == "score":
                        record["expected_score_absolute_change"] = abs(second["typed_value"]-first["typed_value"])
                        record["expected_score_error_change"] = abs(second["typed_value"]-first["gold_score"])-abs(first["typed_value"]-first["gold_score"])
                    else:
                        a, b = first["label"] == first["gold_label"], second["label"] == second["gold_label"]
                        record.update(accuracy_difference=int(b)-int(a), correct_to_incorrect=a and not b, incorrect_to_correct=b and not a)
                    differences.append(record)
        if scope == "all":
            for meta in expected:
                names = ("baseline", "reverse_single", "cyclic_forward", "cyclic_reverse")
                if all((dataset, meta["item_id"], name) in lookup for name in names):
                    stability.append(stability_record(*(lookup[(dataset, meta["item_id"], name)] for name in names)))
    stability_summaries = []
    for dataset, scope, split, expected in scopes(ensembles):
        records = [r for r in stability if r["dataset"] == dataset and (scope == "all" or r["split"] == split)]
        structural = all(m["structural_orbit_identity"] for m in expected)
        result = {"model_key": model_key, "dataset": dataset, "scope": scope, "split": split,
                  "n_eligible_items": len(expected), "n_complete_items": len(records), "n_incomplete_items": len(expected)-len(records),
                  "empirical_orientation_stability_applicable": not structural,
                  "structural_orbit_identity": structural,
                  "single_flip_count": sum(r["single_label_flip"] for r in records),
                  "cyclic_flip_count": sum(r["cyclic_label_flip"] for r in records),
                  "any_single_tie_count": sum(r["any_single_tie"] for r in records),
                  "any_ensemble_tie_count": sum(r["any_ensemble_tie"] for r in records)}
        for name in ("single_label_flip", "cyclic_label_flip", "single_total_variation", "cyclic_total_variation", "single_absolute_expected_score_difference", "cyclic_absolute_expected_score_difference"):
            if records and name in records[0]:
                result[name+"_mean"] = statistics.mean(float(r[name]) for r in records)
        if structural:
            result["bootstrap"] = None
            result["interpretation"] = "Identical physical pools; orientation equality is structural, not an empirical robustness result. Quality remains evaluated."
        else:
            primary = "absolute_expected_score_difference_change" if dataset == "JSTS" else "label_flip_difference"
            result["primary_estimand"] = primary
            result["bootstrap"] = cluster_intervals(records, lambda r: r["group"], lambda r: {"n": 1.0, primary+"_sum": r[primary], "total_variation_difference_sum": r["total_variation_difference"]},
                                                     quality_difference_from_sums, f"{model_key}/{dataset}/{scope}/{split}/orientation_stability", replicates)
        stability_summaries.append(result)
    accounting = {"model_key": model_key, "scheduled_physical_requests": len(schedule), "observed_prediction_rows": len(predictions),
                  "valid_physical_requests": len(valid), "unavailable_physical_requests": len(schedule)-len(valid),
                  "unique_source_items": len(map_counts), "planned_derived_answers": len(ensembles)*len(METHODS),
                  "valid_derived_answers": len(derived), "request_status_counts": dict(Counter(r["status"] for r in request_status)),
                  "derived_answer_status_counts": dict(Counter(r["status"] for r in answer_status)),
                  "failure_code_counts": dict(Counter(r["code"] for r in failures)),
                  "unique_physical_requests_in_all_pools": len(physical_map_owner),
                  "logical_member_references_all_derived_answers": sum(r["physical_forwards_per_answer"] for r in derived),
                  "valid_physical_input_tokens": sum(r["input_tokens"] for r in valid.values()),
                  "valid_physical_output_tokens": sum(r["output_tokens"] for r in valid.values()),
                  "actual_call_kind": "native_decode" if MODELS[model_key] == "llama.cpp" else "transformers_forward",
                  "valid_actual_call_count": sum(r["native_decode_count"] if MODELS[model_key] == "llama.cpp" else r["forward_calls"] for r in valid.values())}
    summary = {"schema_version": 1, "accounting": accounting, "method_quality": method_quality,
               "quality_comparisons": quality_comparisons, "orientation_stability": stability_summaries,
               "definitions": {"averaging": "Uniform arithmetic mean of semantic candidate probabilities; never softmax of average logits.",
                   "complete_pool_requirement": "Every prospectively scheduled member must be valid; no smaller-pool fallback.",
                   "tie_rule": "First maximum in frozen canonical_key_order; exact ties retained.",
                   "quality_difference": "Method minus reference: positive accuracy/MCC is better; negative MAE is better. Same complete items on both sides.",
                   "stability_difference": "Cyclic orientation difference minus single-prompt orientation difference; negative is less sensitivity. Binary shared-pool identity excluded from empirical claims.",
                   "dihedral": "Average unique union. Rotation/reversal invariance is structural; not arbitrary-permutation invariance for K>=4.",
                   "bootstrap": "2000 whole-group percentile replicates, fixed seed2026092203; descriptive95% intervals unadjusted for multiple comparisons, not significance decisions. At least2 groups per stratum and all replicate estimates must be defined.",
                   "jcola_strata": "Independently resample sources within each split and rescale stratum totals to original item counts. If sources cross splits, omit the combined interval; split intervals remain available subject to cluster-count limits.",
                   "cost": "Member references per answer and unique physical requests are distinct. Summed observed call times are not a separately benchmarked optimized ensemble latency.",
                   "inequalities": "Some benefits against averages of member losses/distances follow convexity. Primary comparisons here use fixed single baselines, not average member losses.",
                   "limits": "No fitted calibration or outcome-based method selection; no pooled task accuracy. New evaluation IDs do not establish absence of pretraining contamination. Coarse groups do not eliminate all dependence."}}
    return {"summary": summary, "derived_answers": derived, "method_quality": method_quality,
            "physical_order_quality": physical_order_quality, "paired_quality_differences": differences,
            "orientation_item_differences": stability, "failures": failures,
            "request_accounting": request_status, "answer_accounting": answer_status}


def read_records(path):
    text = Path(path).read_text(encoding="utf-8")
    rows = json.loads(text) if text.lstrip().startswith("[") else [json.loads(line) for line in text.splitlines() if line.strip()]
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Expected JSON array or JSONL records")
    return rows


def write_csv(path, rows):
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=keys or ["no_records"])
        writer.writeheader()
        writer.writerows({key: canonical(value) if isinstance(value, (dict, list)) else value for key, value in row.items()} for row in rows)


def report_text(summary):
    count = summary["accounting"]
    lines = ["# Fixed cyclic probability averaging: descriptive results", "",
             f"Model: {count['model_key']}. {count['valid_physical_requests']} / {count['scheduled_physical_requests']} physical requests are valid, "
             f"covering {count['unique_source_items']} source items. {count['valid_derived_answers']} / {count['planned_derived_answers']} derived answers are available.", "",
             "The primary method averages all K semantic candidate probability vectors with equal weights. "
             "All K members must be valid; incomplete pools are unavailable. Single baselines reuse measured pool members. "
             "This uses K physical forwards per answer, not one. Dihedral averaging uses the unique union of both pools.", "",
             "| Dataset | Method | Valid / planned items | Accuracy | MCC | Balanced accuracy | Expected-score MAE | Physical forwards per answer |",
             "|---|---|---:|---:|---:|---:|---:|---:|"]
    def number(value):
        return "—" if value is None else f"{value:.6f}"
    for row in summary["method_quality"]:
        if row["scope"] == "all":
            lines.append(f"| {row['dataset']} | {row['method']} | {row['n']} / {row['n_scheduled_items']} | "
                         + " | ".join(number(row.get(key)) for key in ("accuracy", "mcc", "balanced_accuracy", "expected_score_mae"))
                         + " | " + ", ".join(str(n) for n in row["physical_forwards_per_answer"]) + " |")
    lines += ["", "Paired quality changes compare each method with its fixed single reference on exactly the same complete items. "
              "Positive accuracy/MCC differences and negative MAE differences favor the ensemble. "
              "Prediction/gold class counts, both JCoLA recalls, ties and JSTS score variance accompany the scalar metrics.", "",
              "| Dataset | Complete / eligible orientation comparisons | Empirical comparison applicable | Primary change: cyclic minus single | Descriptive group interval |",
              "|---|---:|---|---:|---:|"]
    for row in summary["orientation_stability"]:
        if row["scope"] != "all":
            continue
        if row["empirical_orientation_stability_applicable"] and row["bootstrap"]:
            metric = row["bootstrap"]["metrics"].get(row["primary_estimand"], {})
            estimate = number(metric.get("estimate"))
            interval = f"[{number(metric.get('ci95_lower'))}, {number(metric.get('ci95_upper'))}]" if metric.get("interval_available") else "Unavailable"
        else:
            estimate, interval = "Structural identity", "Not an empirical interval"
        lines.append(f"| {row['dataset']} | {row['n_complete_items']} / {row['n_eligible_items']} | "
                     f"{row['empirical_orientation_stability_applicable']} | {estimate} | {interval} |")
    lines += ["", "The classification primary stability outcome is the change in JCQA semantic flip rate. "
              "For JSTS it is the change in absolute expected-score difference between orientations. Negative values mean less observed sensitivity. "
              "For binary JCoLA, both pools reuse the same two requests, so orientation equality is structural and supplies no empirical robustness evidence. "
              "The complete dihedral set is also structurally invariant under rotations/reversal; arbitrary-permutation invariance is not established for K≥4.", "",
              "Intervals use2000 fixed-seed whole-group percentile replicates and are descriptive, unadjusted for multiple comparisons. "
              "JCoLA source groups are sampled within split and stratum totals are normalized to their original item counts. "
              "Combined intervals are omitted if a source crosses splits; split intervals remain subject to group-count/undefined-estimate checks. "
              "An interval is also omitted if any replicate is undefined. Small groups and remaining source dependence limit interpretation.", "",
              "New selected IDs are relative to the audited earlier project evaluations; public-development data can still overlap model training. "
              "No fitted calibration, significance decision, causal size effect or universal improvement is claimed. "
              "Some improvements relative to average member losses/distances follow convexity; this study's primary comparison is against fixed single baselines. "
              "Summed per-forward durations describe observed computational work, not separately benchmarked optimized ensemble latency. "
              "A stable constant prediction need not discriminate classes; assess class marginals and quality alongside stability.", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, required=True)
    parser.add_argument("--model-key", choices=tuple(MODELS), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    schedule = read_records(args.study/"SCHEDULE.json")
    ensembles = read_records(args.study/"ENSEMBLES.json")
    tokenization = json.loads((args.study/"TOKENIZATION.json").read_text())
    freeze = json.loads((args.study/"FREEZE.json").read_text())
    for value, key in ((schedule, "schedule_sha256"), (ensembles, "ensembles_sha256"), (tokenization, "tokenization_sha256")):
        if hashlib.sha256(canonical(value).encode()).hexdigest() != freeze[key]:
            raise ValueError("Frozen analysis input hash mismatch: "+key)
    own_digest = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if own_digest != freeze["source_sha256"]["paper/order_ensemble/analyze.py"]:
        raise ValueError("Analyzer differs from pre-inference freeze")
    if MODELS[args.model_key] == "transformers":
        prepared = tokenization[args.model_key]
        if len(prepared) != len(schedule):
            raise ValueError("Frozen tokenization count mismatch")
        merged = []
        for row, tokens in zip(schedule, prepared):
            if any(key in row and row[key] != value for key, value in tokens.items()):
                raise ValueError("Source/tokenizer metadata mismatch")
            merged.append({**row, **tokens})
        schedule = merged
    folder = args.study/"results"/args.model_key
    predictions_path = folder/"predictions.jsonl"
    predictions = read_records(predictions_path) if predictions_path.exists() else []
    result = analyze(predictions, schedule, ensembles, args.model_key)
    summary = result["summary"]
    summary["input_files"] = {"analyzer_sha256": own_digest,
                               "predictions_sha256": hashlib.sha256(predictions_path.read_bytes()).hexdigest() if predictions_path.exists() else None,
                               "freeze_sha256": hashlib.sha256((args.study/"FREEZE.json").read_bytes()).hexdigest(),
                               "schedule_sha256": freeze["schedule_sha256"], "ensembles_sha256": freeze["ensembles_sha256"]}
    completion_path = folder/"COMPLETION.json"
    if completion_path.exists():
        receipt = json.loads(completion_path.read_text())
        summary["completion_receipt"] = {key: receipt.get(key) for key in ("status", "recorded_requests", "expected_requests", "failed_requests", "actual_calls_including_gate_and_warmup", "expected_excluded_calls", "call_kind", "model_closed_before_receipt", "source_unchanged")}
    args.output.mkdir(parents=True, exist_ok=False)
    with (args.output/"SUMMARY.json").open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False)+"\n")
    (args.output/"REPORT.md").write_text(report_text(summary), encoding="utf-8")
    with (args.output/"derived_answers.jsonl").open("x", encoding="utf-8") as stream:
        for row in result["derived_answers"]:
            stream.write(canonical(row)+"\n")
    for key, rows in result.items():
        if key not in ("summary", "derived_answers"):
            write_csv(args.output/(key+".csv"), rows)
    interval_rows = []
    for comparison in summary["quality_comparisons"]:
        bootstrap = comparison["bootstrap"]
        for metric, values in bootstrap["metrics"].items():
            interval_rows.append({**{key: comparison[key] for key in ("model_key", "dataset", "scope", "split", "method", "reference", "role", "n_complete_pairs", "n_incomplete_pairs")},
                                  "metric": metric, **values,
                                  **{key: bootstrap[key] for key in ("group_count", "stratum_group_counts", "small_group_warning", "combined_interval_omitted_for_shared_source", "seed")}})
    write_csv(args.output/"quality_comparison_intervals.csv", interval_rows)
    print(json.dumps(summary["accounting"], ensure_ascii=False))


if __name__ == "__main__":
    main()
