#!/usr/bin/env python3
"""Post-hoc independent integrity/numerical verifier; never runs a model.

This verifier was authored after the prospective source freeze. It does not
alter the study or choose outcomes. Requests/orbits, probability averages,
quality, orientation differences and descriptive bootstrap intervals are
recomputed without importing the study analyzer. Tokenizers alone may load.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from copy import deepcopy
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from native_engine import NativeEngine, MODEL_PIN, options_for
from paper.journal_robustness import audit as common
from paper.journal_robustness import run as native_run
from paper.journal_robustness import conditions as old_conditions
from paper.journal_robustness.cross_model import audit as cross
from paper.journal_robustness.cross_model import engine as adapter
from paper.order_ensemble.prepare import verify_source

canonical, sha, load, load_jsonl = common.canonical, common.sha, common.load, common.load_jsonl
equivalent, finite = common.equivalent, common.finite
MODELS = ('qwen3.6-35b-a3b', 'qwen2.5-0.5b', 'qwen2.5-1.5b')
METHODS = ('baseline', 'reverse_single', 'cyclic_forward', 'cyclic_reverse', 'dihedral')
SEED, BOOTSTRAP_SEED, REPLICATES = 2026092202, 2026092203, 2000
NATIVE_FIELDS = {'native_decode_count', 'native_total_decode_count', 'state_cleared', 'thinking_enabled'}
NATIVE_OBSERVATIONS = NATIVE_FIELDS | {'logits', 'probabilities', 'label', 'exact_top_logit_tie_keys', 'typed_value',
    'temperature', 'concentration', 'candidate_ids', 'input_tokens', 'output_tokens', 'model_ms', 'latency_ms', 'projection', 'error'}


def subset(actual, expected):
    return isinstance(actual, dict) and all(equivalent(actual.get(k), v) for k, v in expected.items())


def independent_schedule(rows):
    """Canonical formatter shared by design; orbit construction/replacement independent."""
    ordered = sorted(rows, key=lambda r: r['id'])
    rng = random.Random(SEED)
    rng.shuffle(ordered)
    schedule, requests, ensembles = [], [], []
    formatter = object.__new__(NativeEngine)
    formatter.prompt_style = 'repeat_typed_score'
    for row in ordered:
        options = options_for(row)
        keys = [k for k, _ in options]
        count = len(keys)
        if count != {'JCoLA': 2, 'JSTS': 6, 'JCommonsenseQA': 5}[row['dataset']]:
            raise ValueError('unsupported_candidate_schema')
        tokens, prefix, kind = formatter._candidate_spec(row, options)
        request = {'messages': formatter._messages(row, options), 'candidates': tokens, 'max_input_tokens': 2048}
        if prefix:
            request['assistant_prefix'] = prefix
        lines = ([f'{token}: {meaning}' for token, (_, meaning) in zip(tokens, options)] if kind == 'number'
                 else [f'{token}. {key}: {meaning}' for token, (key, meaning) in zip(tokens, options)])
        block = '\n'.join(lines)
        physical, by_order, conceptual = [], {}, {'forward': [], 'reverse': []}
        for orientation, base_order in [('forward', list(range(count))), ('reverse', list(reversed(range(count))))]:
            for rotation in range(count):
                order = tuple(base_order[rotation:]+base_order[:rotation])
                if order not in by_order:
                    name = f'{orientation}_{rotation}'
                    by_order[order] = name
                    rendered = deepcopy(request)
                    replacements = 0
                    for message in rendered['messages']:
                        replacements += message['content'].count(block)
                        message['content'] = message['content'].replace(block, '\n'.join(lines[i] for i in order))
                    if replacements != 2:
                        raise ValueError('option_block_must_occur_twice')
                    physical.append((name, order, rendered))
                conceptual[orientation].append(by_order[order])
        if len(physical) != (count if count == 2 else 2*count):
            raise ValueError('unexpected_orbit_intersection')
        rng.shuffle(physical)
        meta = {field: row[field] for field in ('dataset', 'split', 'group', 'type')}
        meta.update(item_id=row['id'], canonical_key_order=keys, candidate_keys=keys)
        if row['type'] == 'score':
            meta.update(gold_score=row['gold_score'], score_values={key: float(key) for key in keys})
        else:
            meta['gold_label'] = row['label']
        indices = {}
        for name, order, rendered in physical:
            index = len(schedule)
            indices[name] = index
            schedule.append({**meta, 'request_index': index, 'condition': name, 'candidate_tokens': tokens,
                'display_order': [keys[i] for i in order], 'request_sha256': sha(canonical(rendered).encode()),
                'source_question_sha256': sha(canonical(row).encode())})
            requests.append(rendered)
        forward = [indices[n] for n in conceptual['forward']]
        reverse = [indices[n] for n in conceptual['reverse']]
        ensembles.append({**meta, 'forward_request_indices': forward, 'reverse_request_indices': reverse,
            'baseline_request_index': forward[0], 'reverse_single_request_index': reverse[0],
            'structural_orbit_identity': count == 2})
    return schedule, requests, ensembles


def decode(probabilities, meta):
    keys = meta['canonical_key_order']
    if set(keys) != set(probabilities) or any(not finite(v) or not 0 <= v <= 1 for v in probabilities.values()):
        raise ValueError('invalid_probability_vector')
    if not math.isclose(math.fsum(probabilities.values()), 1, abs_tol=1e-6):
        raise ValueError('unnormalized_probability_vector')
    top = max(probabilities.values())
    ties = [key for key in keys if probabilities[key] == top]
    label = ties[0]
    value = label if meta['type'] == 'choice' else probabilities['true'] if meta['type'] == 'noul' else math.fsum(
        meta['score_values'][key]*probabilities[key] for key in keys)
    return {'probabilities': probabilities, 'label': label, 'typed_value': value,
            'tie_keys': ties, 'max_candidate_probability': top}


def independent_derived(meta, predictions, model):
    fwd, rev = meta['forward_request_indices'], meta['reverse_request_indices']
    pools = {'baseline': fwd[:1], 'reverse_single': rev[:1], 'cyclic_forward': fwd,
             'cyclic_reverse': rev, 'dihedral': list(dict.fromkeys(fwd+rev))}
    answers = {}
    for method, members in pools.items():
        measured = [predictions[index] for index in members]
        p = {key: math.fsum(row['probabilities'][key] for row in measured)/len(members)
             for key in meta['canonical_key_order']}
        answer = {field: meta[field] for field in ('item_id', 'dataset', 'split', 'group', 'type',
                  'canonical_key_order', 'gold_label', 'gold_score', 'score_values') if field in meta}
        answer.update(decode(p, meta))
        answer.update(model_key=model, method=method, physical_member_indices=members,
            physical_forwards_per_answer=len(members), input_tokens_sum=sum(row['input_tokens'] for row in measured),
            observed_forward_latency_sum_ms=math.fsum(row['latency_ms'] for row in measured),
            structural_orbit_identity=meta['structural_orbit_identity'],
            derivation='equal_weight_arithmetic_mean_of_canonical_candidate_probabilities' if len(members) > 1
                else 'reused_single_forward_probability_vector')
        answers[method] = answer
    return answers


def confusion(label, gold):
    return ('t' if label == gold else 'f')+('p' if label == 'true' else 'n')


def binary_metrics(counts):
    tp, tn, fp, fn = (counts.get(key, 0) for key in ('tp', 'tn', 'fp', 'fn'))
    denom = (tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
    true_recall = tp/(tp+fn) if tp+fn else None
    false_recall = tn/(tn+fp) if tn+fp else None
    return {'mcc': (tp*tn-fp*fn)/math.sqrt(denom) if denom else None,
            'recall_true': true_recall, 'recall_false': false_recall,
            'balanced_accuracy': (true_recall+false_recall)/2 if true_recall is not None and false_recall is not None else None}


def independent_quality(rows):
    result = {'n': len(rows), 'label_counts': dict(sorted(Counter(r['label'] for r in rows).items())),
              'exact_tie_answers': sum(len(r['tie_keys']) > 1 for r in rows),
              'group_count': len({r['group'] for r in rows})}
    if rows[0]['type'] == 'score':
        values = [row['typed_value'] for row in rows]
        result.update(expected_score_mae=statistics.mean(abs(r['typed_value']-r['gold_score']) for r in rows),
            hard_stage_mae=statistics.mean(abs(r['score_values'][r['label']]-r['gold_score']) for r in rows),
            expected_score_variance_across_items=statistics.pvariance(values))
    else:
        result.update(accuracy=sum(r['label'] == r['gold_label'] for r in rows)/len(rows),
            gold_label_counts=dict(sorted(Counter(r['gold_label'] for r in rows).items())))
        if rows[0]['dataset'] == 'JCoLA':
            counts = Counter(confusion(r['label'], r['gold_label']) for r in rows)
            result.update({key: counts[key] for key in ('tp', 'tn', 'fp', 'fn')})
            result.update(binary_metrics(counts))
            result['mcc_undefined'] = result['mcc'] is None
    return result


def distance(p, q):
    tv = sum(abs(p[k]-q[k]) for k in p)/2
    js = 0.0
    for k in p:
        midpoint = (p[k]+q[k])/2
        if p[k]:
            js += p[k]*math.log2(p[k]/midpoint)/2
        if q[k]:
            js += q[k]*math.log2(q[k]/midpoint)/2
    return tv, max(0., min(1., js))


def orientation(answers):
    a, b, c, d = [answers[name] for name in METHODS[:4]]
    first_tv, first_js = distance(a['probabilities'], b['probabilities'])
    cyclic_tv, cyclic_js = distance(c['probabilities'], d['probabilities'])
    r = {key: a[key] for key in ('model_key', 'item_id', 'dataset', 'split', 'group')}
    r.update(structural_orbit_identity=a['structural_orbit_identity'],
        empirical_orientation_stability_applicable=not a['structural_orbit_identity'],
        single_label_flip=a['label'] != b['label'], cyclic_label_flip=c['label'] != d['label'],
        single_total_variation=first_tv, cyclic_total_variation=cyclic_tv,
        single_normalized_jensen_shannon=first_js, cyclic_normalized_jensen_shannon=cyclic_js,
        any_single_tie=max(len(a['tie_keys']), len(b['tie_keys'])) > 1,
        any_ensemble_tie=max(len(c['tie_keys']), len(d['tie_keys'])) > 1)
    r['label_flip_difference'] = float(r['cyclic_label_flip'])-float(r['single_label_flip'])
    r['total_variation_difference'] = cyclic_tv-first_tv
    if a['type'] == 'score':
        r['single_absolute_expected_score_difference'] = abs(a['typed_value']-b['typed_value'])
        r['cyclic_absolute_expected_score_difference'] = abs(c['typed_value']-d['typed_value'])
        r['absolute_expected_score_difference_change'] = r['cyclic_absolute_expected_score_difference']-r['single_absolute_expected_score_difference']
    return r


def paired_sufficient(a, b):
    r = {'n': 1.0}
    if a['type'] == 'score':
        r['expected_score_mae_difference_sum'] = abs(b['typed_value']-b['gold_score'])-abs(a['typed_value']-a['gold_score'])
    else:
        r['accuracy_difference_sum'] = float(b['label'] == b['gold_label'])-float(a['label'] == a['gold_label'])
        if a['dataset'] == 'JCoLA':
            for prefix, row in [('a_', a), ('b_', b)]:
                for key in ('tp', 'tn', 'fp', 'fn'):
                    r[prefix+key] = float(confusion(row['label'], row['gold_label']) == key)
    return r


def estimate_sums(sums):
    r = {key[:-4]: value/sums['n'] for key, value in sums.items() if key.endswith('_sum')}
    if 'a_tp' in sums:
        before = binary_metrics({k: sums['a_'+k] for k in ('tp', 'tn', 'fp', 'fn')})
        after = binary_metrics({k: sums['b_'+k] for k in ('tp', 'tn', 'fp', 'fn')})
        for key in before:
            r[key+'_difference'] = after[key]-before[key] if before[key] is not None and after[key] is not None else None
    return r


def quantile(values, fraction):
    sorted_values = sorted(values)
    position = fraction*(len(sorted_values)-1)
    low = int(position)
    high = math.ceil(position)
    return sorted_values[low]*(high-position)+sorted_values[high]*(position-low) if high != low else sorted_values[low]


def independent_bootstrap(records, scope, stratified):
    """Records are (group, split, sufficient-statistics); no analyzer calls."""
    groups = {}
    for group, split, values in records:
        key = (split if stratified else 'all', group)
        group_values = groups.setdefault(key, defaultdict(float))
        for metric, value in values.items():
            group_values[metric] += value
    strata = {s: sorted(k for k in groups if k[0] == s) for s in sorted({k[0] for k in groups})}
    stratum_n = {s: math.fsum(groups[k]['n'] for k in members) for s, members in strata.items()}
    shared = sorted(k for k, n in Counter(k[1] for k in groups).items() if n > 1)
    total = defaultdict(float)
    for values in groups.values():
        for metric, value in values.items():
            total[metric] += value
    point = estimate_sums(total)
    seed = BOOTSTRAP_SEED+int(hashlib.sha256(scope.encode()).hexdigest()[:16], 16)
    rng = random.Random(seed)
    samples = {metric: [] for metric in point}
    enough = bool(groups) and min(map(len, strata.values())) >= 2 and not (stratified and shared)
    if enough:
        for _ in range(REPLICATES):
            sums = defaultdict(float)
            for s, members in strata.items():
                subtotal = defaultdict(float)
                for _ in range(len(members)):
                    picked = groups[members[rng.randrange(len(members))]]
                    for metric, value in picked.items():
                        subtotal[metric] += value
                scale = stratum_n[s]/subtotal['n'] if stratified else 1.0
                for metric, value in subtotal.items():
                    sums[metric] += value*scale
            estimates = estimate_sums(sums)
            for metric in samples:
                samples[metric].append(estimates[metric])
    output = {'group_count': len({key[1] for key in groups}), 'stratum_group_counts': {s: len(m) for s, m in strata.items()},
        'original_stratum_item_counts': stratum_n, 'shared_groups_across_strata': shared,
        'replicates_requested': REPLICATES, 'small_group_warning': any(len(m) < 20 for m in strata.values()),
        'cross_stratum_dependency_warning': bool(shared), 'seed': seed,
        'combined_interval_omitted_for_shared_source': bool(stratified and shared), 'metrics': {}}
    for metric, estimate in point.items():
        valid = [v for v in samples[metric] if finite(v)]
        usable = finite(estimate) and enough and len(valid) == REPLICATES
        output['metrics'][metric] = {'estimate': estimate, 'ci95_lower': quantile(valid, .025) if usable else None,
            'ci95_upper': quantile(valid, .975) if usable else None, 'defined_replicates': len(valid),
            'undefined_replicates': len(samples[metric])-len(valid), 'interval_available': usable}
    return output


def csv_records(path):
    with path.open(newline='', encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def csv_equivalent(actual, expected):
    # A CSV union schema has empty cells for fields absent from a task's rows.
    if not set(expected) <= set(actual) or any(actual[k] != '' for k in set(actual)-set(expected)):
        return False
    for key, value in expected.items():
        observed = actual[key]
        if value is None:
            if observed != '':
                return False
        elif isinstance(value, (dict, list)):
            if not equivalent(common.parse(observed), value):
                return False
        elif isinstance(value, bool) or isinstance(value, str):
            if observed != str(value):
                return False
        elif type(value) is int:
            if observed != str(value):
                return False
        elif not math.isclose(float(observed), value, abs_tol=1e-10, rel_tol=1e-9):
            return False
    return True


def analysis_checks(check, directory, model, predictions, ensembles, schedule, freeze, study):
    summary = load(directory/'SUMMARY.json')
    derived = [answer for meta in ensembles for answer in independent_derived(meta, predictions, model).values()]
    reported = load_jsonl(directory/'derived_answers.jsonl')
    check.check('all_3000_probability_averages_and_costs_'+model, equivalent(reported, derived))
    by_item = {(r['item_id'], r['method']): r for r in derived}
    all_orientation = [orientation({method: by_item[meta['item_id'], method] for method in METHODS}) for meta in ensembles]
    reported_orientation = csv_records(directory/'orientation_item_differences.csv')
    orientation_lookup = {r['item_id']: r for r in reported_orientation}
    check.check('all_600_orientation_item_differences_'+model, len(reported_orientation) == len(orientation_lookup) == 600
        and all(csv_equivalent(orientation_lookup.get(r['item_id'], {}), r) for r in all_orientation))
    expected_accounting = {'model_key': model, 'scheduled_physical_requests': 4800, 'observed_prediction_rows': 4800,
        'valid_physical_requests': 4800, 'unavailable_physical_requests': 0, 'unique_source_items': 600,
        'planned_derived_answers': 3000, 'valid_derived_answers': 3000, 'request_status_counts': {'valid': 4800},
        'derived_answer_status_counts': {'valid': 3000}, 'failure_code_counts': {},
        'unique_physical_requests_in_all_pools': 4800,
        'logical_member_references_all_derived_answers': sum(r['physical_forwards_per_answer'] for r in derived),
        'valid_physical_input_tokens': sum(r['input_tokens'] for r in predictions), 'valid_physical_output_tokens': 0,
        'actual_call_kind': 'native_decode' if model == MODELS[0] else 'transformers_forward', 'valid_actual_call_count': 4800}
    check.check('physical_and_logical_accounting_'+model, equivalent(summary['accounting'], expected_accounting))
    check.check('no_analysis_failure_records_'+model, not csv_records(directory/'failures.csv'))
    physical_expected = []
    paired_expected = []
    method_quality_expected = []
    interval_expected = []
    inputs = {'analyzer_sha256': sha((HERE/'analyze.py').read_bytes()),
        'predictions_sha256': sha((study/'results'/model/'predictions.jsonl').read_bytes()),
        'freeze_sha256': sha((study/'FREEZE.json').read_bytes()), 'schedule_sha256': freeze['schedule_sha256'],
        'ensembles_sha256': freeze['ensembles_sha256']}
    check.check('analysis_input_hashes_'+model, summary['input_files'] == inputs)
    completion = load(study/'results'/model/'COMPLETION.json')
    check.check('analysis_completion_receipt_'+model, all(completion.get(k) == v for k, v in summary['completion_receipt'].items()))
    scopes = [(dataset, 'all', '') for dataset in sorted({r['dataset'] for r in ensembles})]
    scopes += [('JCoLA', 'split', s) for s in sorted({r['split'] for r in ensembles if r['dataset'] == 'JCoLA'})]
    quality_lookup = {(r['dataset'], r['scope'], r['split'], r['method']): r for r in summary['method_quality']}
    comparison_lookup = {(r['dataset'], r['scope'], r['split'], r['method']): r for r in summary['quality_comparisons']}
    stability_lookup = {(r['dataset'], r['scope'], r['split']): r for r in summary['orientation_stability']}
    check.check('complete_summary_scopes_'+model, len(quality_lookup) == len(summary['method_quality']) == 25
        and len(comparison_lookup) == len(summary['quality_comparisons']) == 15
        and len(stability_lookup) == len(summary['orientation_stability']) == 5)
    recomputed = []
    for dataset, scope, split in scopes:
        selected = [r for r in ensembles if r['dataset'] == dataset and (not split or r['split'] == split)]
        prefix = {'model_key': model, 'dataset': dataset, 'scope': scope, 'split': split, 'n_scheduled_items': len(selected)}
        for method in METHODS:
            rows = [by_item[r['item_id'], method] for r in selected]
            cost = [r['physical_forwards_per_answer'] for r in rows]
            expected = {**prefix, 'method': method, **independent_quality(rows), 'n_unavailable_items': 0,
                'physical_forwards_per_answer': sorted(set(cost)), 'total_member_references': sum(cost),
                'observed_forward_latency_sum_ms': math.fsum(r['observed_forward_latency_sum_ms'] for r in rows)}
            check.check(f'quality_and_collapse_{model}_{dataset}_{scope}_{split}_{method}',
                        equivalent(quality_lookup[dataset, scope, split, method], expected))
            method_quality_expected.append(expected)
        relevant = [r for r in predictions if r['dataset'] == dataset and (not split or r['split'] == split)]
        for condition in sorted({r['condition'] for r in relevant}):
            physical = [{**r, **decode(r['probabilities'], r)} for r in relevant if r['condition'] == condition]
            physical_expected.append({**prefix, 'condition': condition, **independent_quality(physical), 'n_unavailable_items': 0})
        for method, reference, role in [('cyclic_forward', 'baseline', 'primary'), ('cyclic_reverse', 'reverse_single', 'secondary'),
                                         ('dihedral', 'baseline', 'structural_diagnostic')]:
            pairs = [(by_item[r['item_id'], reference], by_item[r['item_id'], method]) for r in selected]
            sufficient = [(a['group'], a['split'], paired_sufficient(a, b)) for a, b in pairs]
            boot = independent_bootstrap(sufficient, f'{model}/{dataset}/{scope}/{split}/{method}-{reference}', dataset == 'JCoLA')
            actual = comparison_lookup[dataset, scope, split, method]
            expected = {**prefix, 'method': method, 'reference': reference, 'role': role,
                'n_complete_pairs': len(selected), 'n_incomplete_pairs': 0,
                'reference_quality_same_items': independent_quality([a for a, _ in pairs]),
                'method_quality_same_items': independent_quality([b for _, b in pairs])}
            check.check(f'paired_quality_and_bootstrap_{model}_{dataset}_{scope}_{split}_{method}',
                        subset(actual, expected) and subset(actual['bootstrap'], boot))
            for metric, values in boot['metrics'].items():
                interval_expected.append({**{key: expected[key] for key in ('model_key', 'dataset', 'scope', 'split',
                    'method', 'reference', 'role', 'n_complete_pairs', 'n_incomplete_pairs')}, 'metric': metric, **values,
                    **{key: boot[key] for key in ('group_count', 'stratum_group_counts', 'small_group_warning',
                        'combined_interval_omitted_for_shared_source', 'seed')}})
            if scope == 'all':
                for a, b in pairs:
                    tv, js = distance(a['probabilities'], b['probabilities'])
                    change = {key: a[key] for key in ('model_key', 'dataset', 'item_id', 'split', 'group')}
                    change.update(method=method, reference=reference, label_changed=a['label'] != b['label'],
                        reference_label=a['label'], method_label=b['label'], total_variation=tv, normalized_jensen_shannon=js)
                    if a['type'] == 'score':
                        change.update(expected_score_absolute_change=abs(b['typed_value']-a['typed_value']),
                            expected_score_error_change=abs(b['typed_value']-a['gold_score'])-abs(a['typed_value']-a['gold_score']))
                    else:
                        first, second = a['label'] == a['gold_label'], b['label'] == b['gold_label']
                        change.update(accuracy_difference=int(second)-int(first), correct_to_incorrect=first and not second,
                            incorrect_to_correct=second and not first)
                    paired_expected.append(change)
        records = [r for r in all_orientation if r['dataset'] == dataset and (not split or r['split'] == split)]
        structural = dataset == 'JCoLA'
        expected = {'model_key': model, 'dataset': dataset, 'scope': scope, 'split': split,
            'n_eligible_items': len(records), 'n_complete_items': len(records), 'n_incomplete_items': 0,
            'empirical_orientation_stability_applicable': not structural, 'structural_orbit_identity': structural,
            'single_flip_count': sum(r['single_label_flip'] for r in records),
            'cyclic_flip_count': sum(r['cyclic_label_flip'] for r in records),
            'any_single_tie_count': sum(r['any_single_tie'] for r in records),
            'any_ensemble_tie_count': sum(r['any_ensemble_tie'] for r in records)}
        for name in ('single_label_flip', 'cyclic_label_flip', 'single_total_variation', 'cyclic_total_variation',
                     'single_absolute_expected_score_difference', 'cyclic_absolute_expected_score_difference'):
            if name in records[0]:
                expected[name+'_mean'] = statistics.mean(float(r[name]) for r in records)
        actual = stability_lookup[dataset, scope, split]
        boot_ok = actual['bootstrap'] is None if structural else False
        if not structural:
            primary = 'absolute_expected_score_difference_change' if dataset == 'JSTS' else 'label_flip_difference'
            expected['primary_estimand'] = primary
            sufficient = [(r['group'], r['split'], {'n': 1., primary+'_sum': r[primary],
                'total_variation_difference_sum': r['total_variation_difference']}) for r in records]
            boot = independent_bootstrap(sufficient, f'{model}/{dataset}/{scope}/{split}/orientation_stability', False)
            boot_ok = subset(actual['bootstrap'], boot)
            recomputed.append({'dataset': dataset, 'primary': primary, 'metrics': boot['metrics']})
        check.check(f'orientation_stability_and_bootstrap_{model}_{dataset}_{scope}_{split}', subset(actual, expected) and boot_ok)
    for filename, expected, identity in [('physical_order_quality.csv', physical_expected, ('dataset', 'scope', 'split', 'condition')),
                                        ('paired_quality_differences.csv', paired_expected, ('dataset', 'item_id', 'method')),
                                        ('method_quality.csv', method_quality_expected, ('dataset', 'scope', 'split', 'method')),
                                        ('quality_comparison_intervals.csv', interval_expected, ('dataset', 'scope', 'split', 'method', 'metric'))]:
        actual = csv_records(directory/filename)
        lookup = {tuple(r[k] for k in identity): r for r in actual}
        check.check('independent_'+filename+'_'+model, len(actual) == len(lookup) == len(expected)
            and all(csv_equivalent(lookup.get(tuple(r[k] for k in identity), {}), r) for r in expected))
    request_rows, answer_rows = csv_records(directory/'request_accounting.csv'), csv_records(directory/'answer_accounting.csv')
    expected_requests = [{**{k: r[k] for k in ('request_index', 'item_id', 'dataset', 'condition')}, 'status': 'valid'} for r in schedule]
    expected_answers = [{'item_id': r['item_id'], 'dataset': r['dataset'], 'method': r['method'], 'status': 'valid',
        'required_member_count': r['physical_forwards_per_answer'], 'unavailable_member_indices': []} for r in derived]
    check.check('all_request_and_answer_accounting_rows_'+model, len(request_rows) == len(expected_requests)
        and all(csv_equivalent(a, b) for a, b in zip(request_rows, expected_requests))
        and len(answer_rows) == len(expected_answers) and all(csv_equivalent(a, b) for a, b in zip(answer_rows, expected_answers)))
    check.recomputed[model] = {'independently_recomputed_primary': recomputed, 'n_derived_answers': len(derived),
                               'n_physical_requests': len(predictions)}
    check.check('no_benchmark_input_fields_in_analysis_'+model,
                not cross.private_fields(summary) and not cross.private_fields(reported))


def audit(study, questions, analysis, models=MODELS, raw_dir=None):
    check = common.Audit()
    state = {}
    def load_inputs():
        state.update(freeze=load(study/'FREEZE.json'), schedule=load(study/'SCHEDULE.json'),
                     ensembles=load(study/'ENSEMBLES.json'), tokens=load(study/'TOKENIZATION.json'), rows=verify_source(questions))
    check.phase('load_frozen_study', load_inputs)
    if not state:
        return check
    freeze, schedule, ensembles, tokens, rows = [state[k] for k in ('freeze', 'schedule', 'ensembles', 'tokens', 'rows')]
    preparers, requests = {}, []

    def source_checks():
        nonlocal requests
        actual = {key: sha((questions if key == 'external_questions' else ROOT/key).read_bytes()) for key in freeze['source_sha256']}
        check.check('all_frozen_source_file_hashes', actual == freeze['source_sha256'])
        required = {'paper/order_ensemble/'+name for name in ('PROTOCOL.json', 'SELECTION.json', 'DATA_FREEZE.json',
            'DATA_PROVENANCE.json', 'prepare.py', 'materialize.py', 'run.py', 'conditions.py', 'analyze.py',
            'test_conditions.py', 'test_analysis.py', 'test_runner.py')}
        check.check('required_prospective_source_inventory', required <= set(actual))
        data_freeze = load(HERE/'DATA_FREEZE.json')
        data_paths = {'prepare': HERE/'prepare.py', 'prior_prepare': ROOT/'paper/external_expanded/prepare.py',
            'prior_protocol': ROOT/'paper/external_expanded/PROTOCOL.json', 'native_formatter': ROOT/'native_engine.py'}
        check.check('data_selection_code_frozen_before_selection', data_freeze['source_sha256'] == {
            key: sha(path.read_bytes()) for key, path in data_paths.items()} and data_freeze['stage'] == 'before_selecting_new_item_IDs_and_before_any_inference')
        provenance, selection = load(HERE/'DATA_PROVENANCE.json'), load(HERE/'SELECTION.json')
        check.check('data_provenance_hash_chain', provenance['data_freeze_sha256'] == sha((HERE/'DATA_FREEZE.json').read_bytes())
            and provenance['selection_sha256'] == sha((HERE/'SELECTION.json').read_bytes())
            and provenance['questions_sha256'] == selection['questions_sha256'] == sha(questions.read_bytes())
            and provenance['questions_bytes'] == selection['questions_bytes'] == questions.stat().st_size
            and provenance['raw_question_text_published'] is False and provenance['model_calls'] == 0
            and datetime.fromisoformat(data_freeze['created_at']) <= datetime.fromisoformat(provenance['prepared_at'])
            <= datetime.fromisoformat(freeze['created_at']))
        expected_schedule, requests, expected_ensembles = independent_schedule(rows)
        check.check('independent_all_4800_schedule_metadata_and_request_hashes', expected_schedule == schedule)
        check.check('independent_all_600_physical_orbits', expected_ensembles == ensembles)
        check.check('freeze_stage_budget_and_seed', subset(freeze, {'stage': 'before_any_new_study_model_forward',
            'n_items': 600, 'physical_requests_per_model': 4800, 'model_order': list(MODELS), 'seed': SEED,
            'n_model_loads': 0, 'n_model_forwards': 0}))
        for filename, value, field in [('SCHEDULE.json', schedule, 'schedule_sha256'), ('ENSEMBLES.json', ensembles, 'ensembles_sha256'),
                                        ('TOKENIZATION.json', tokens, 'tokenization_sha256')]:
            check.check('canonical_hash_'+filename, sha(canonical(value).encode()) == freeze[field])
        check.check('physical_dataset_counts', Counter(r['dataset'] for r in schedule) == {'JCoLA': 400, 'JSTS': 2400, 'JCommonsenseQA': 2000})
        check.check('600_unique_items_and_source_groups', len({r['item_id'] for r in ensembles}) == 600
            and {d: len({r['group'] for r in ensembles if r['dataset'] == d}) for d in ('JCoLA', 'JSTS', 'JCommonsenseQA')}
            == {'JCoLA': 33, 'JSTS': 200, 'JCommonsenseQA': 200})
        jcola = [r for r in ensembles if r['dataset'] == 'JCoLA']
        by_split = {s: {r['group'] for r in jcola if r['split'] == s} for s in ('in_domain_valid', 'out_of_domain_valid')}
        check.check('jcola_strata_100_each_and_no_cross_stratum_groups', Counter(r['split'] for r in jcola)
            == {'in_domain_valid': 100, 'out_of_domain_valid': 100} and not set.intersection(*by_split.values()))
        check.check('selected_installed_implementation_files_unchanged', adapter.implementation_manifest() == freeze['implementation_manifest'])
        check.check('fixed_synthetic_fixture_and_warmup_hashes', freeze['synthetic_gate_sha256'] == sha(canonical(adapter.synthetic_gate_requests()).encode())
            and freeze['warmups_sha256'] == sha(canonical(native_run.WARMUPS).encode()))
        check.check('frozen_native_pinned_artifact', freeze['native_artifacts']['model_pin'] == MODEL_PIN)
        check.check('cross_tokenization_gate_receipt', freeze['cross_tokenization_gate'] == {
            'full_input_sequences_equal': True, 'candidate_ids_equal': True,
            'distinct_single_token_continuations_checked_in_context': True, 'requests_checked': 4800})
        check.check('all_4800_shared_frozen_tokenization_hashes', len(tokens[MODELS[1]]) == len(tokens[MODELS[2]]) == 4800
            and all(all(a[field] == b[field] for field in ('request_sha256', 'rendered_sha256', 'tokenized_input_sha256',
                'candidate_ids', 'candidate_tokens', 'input_tokens')) for a, b in zip(tokens[MODELS[1]], tokens[MODELS[2]])))
        check.check('no_private_inputs_in_public_study_records', not any(cross.private_fields(v) for v in (freeze, schedule, ensembles, tokens)))
    check.phase('source_schedule_orbits_and_freeze', source_checks)

    def materialization_check():
        from paper.order_ensemble.materialize import reconstruct
        raw = reconstruct(raw_dir or questions.parent.parent/'paper-external-expanded/raw')
        check.check('pinned_raw_selection_reconstruction_byte_exact', raw == questions.read_bytes())
    check.phase('public_selection_reconstruction_no_git_or_models', materialization_check)

    def tokenizer_checks(model):
        verified = adapter.verify_snapshot(model)
        check.check('fully_rehashed_pinned_model_files_'+model, verified.manifest() == freeze['model_artifacts'][model])
        preparers[model] = adapter.TokenizerPreparer(verified)
        expected = [cross.independent_preparation(preparers[model], request, model) for request in requests]
        public = [{key: value for key, value in row.items() if key != 'input_ids'} for row in expected]
        check.check('independent_complete_input_and_candidate_tokenization_'+model, public == tokens[model])
    for model in models:
        if model != MODELS[0]:
            check.phase('tokenizers_only_no_model_load_'+model, lambda m=model: tokenizer_checks(m))

    records = {}
    def model_checks(model):
        folder = study/'results'/model
        r = {'completion': load(folder/'COMPLETION.json'), 'attempt': load(folder/'ATTEMPT.json'),
             'runtime': load(folder/'RUNTIME.json'), 'warmups': load_jsonl(folder/'warmup.jsonl'),
             'predictions': load_jsonl(folder/'predictions.jsonl')}
        records[model] = r
        native = model == MODELS[0]
        offset = 3 if native else 27
        completion, attempt, runtime = r['completion'], r['attempt'], r['runtime']
        check.check('completed_actual_model_run_'+model, subset(completion, {'model_key': model, 'status': 'completed',
            'expected_requests': 4800, 'recorded_requests': 4800, 'failed_requests': 0, 'fatal_error_type': None,
            'actual_calls_including_gate_and_warmup': 4800+offset, 'last_observed_cumulative_call_count': 4800+offset,
            'expected_excluded_calls': offset, 'call_kind': 'native_decode' if native else 'transformers_forward',
            'model_closed_before_receipt': True, 'source_unchanged': True}))
        inventory = {p.name: sha(p.read_bytes()) for p in folder.glob('*.json*') if p.is_file() and p.name != 'COMPLETION.json'}
        wanted = {'ATTEMPT.json', 'RUNTIME.json', 'warmup.jsonl', 'predictions.jsonl'} | (set() if native else {'PARITY_GATE.json'})
        check.check('completion_file_inventory_'+model, completion['file_sha256'] == inventory and set(inventory) == wanted)
        check.check('attempt_binding_and_time_order_'+model, subset(attempt, {'model_key': model, 'expected_requests': 4800,
            'status': 'started_not_completed', 'freeze_sha256': sha((study/'FREEZE.json').read_bytes())})
            and attempt['started_at'] == completion['started_at'] and datetime.fromisoformat(freeze['created_at'])
            <= datetime.fromisoformat(attempt['started_at']) <= datetime.fromisoformat(completion['finished_at']))
        previous = MODELS.index(model)-1
        if previous >= 0:
            prior = load(study/'results'/MODELS[previous]/'COMPLETION.json')
            check.check('previous_model_closed_before_start_'+model, prior['status'] == 'completed'
                and prior['model_closed_before_receipt'] is True and datetime.fromisoformat(prior['finished_at']) <= datetime.fromisoformat(attempt['started_at']))
        if native:
            data = runtime['fingerprint_data']
            digest = sha(json.dumps(data, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())
            fixed = {'model': MODEL_PIN['repo_id'], 'revision': MODEL_PIN['revision'], 'model_sha256': MODEL_PIN['sha256'],
                'model_bytes': MODEL_PIN['bytes'], 'dtype': MODEL_PIN['quantization'], 'device': 'metal', 'threads': 6,
                'max_input_tokens': 2048, 'prompt_style': 'repeat_typed_score', 'attention': 'llama.cpp_flash',
                'python_source_sha256': freeze['source_sha256']['native_engine.py'],
                'llama_cpp_commit': freeze['native_artifacts']['llama_cpp_commit'],
                'native_files': {k: v for k, v in freeze['native_artifacts']['files_sha256'].items()
                                 if k.startswith('bin/') or k == 'llama_decision_helper.cpp'},
                'native_aliases': freeze['native_artifacts']['aliases']}
            check.check('native_runtime_fingerprint_and_model_pin', digest == runtime['fingerprint'] and subset(data, fixed))
            check.check('native_ready_zero_initial_decodes', subset(runtime['native_ready'], {'ready': True, 'mode': 'direct_logits',
                'ctx': 2048, 'gpu_layers': 99, 'total_decode_count': 0, 'batch_strategy': 'sequential_independent_requests'}))
        else:
            fixed = {'backend': 'transformers', 'device': 'mps', 'dtype': 'float32', 'attention': 'eager',
                'use_cache': False, 'batch_size': 1, 'logits_to_keep': 1, 'projection': cross.PROJECTION,
                'engine_source_sha256': freeze['source_sha256']['paper/journal_robustness/cross_model/engine.py'],
                'torch_version': freeze['implementation_manifest']['versions']['torch'],
                'transformers_version': freeze['implementation_manifest']['versions']['transformers']}
            check.check('transformer_runtime_pin_and_contract_'+model, subset(runtime, fixed) and subset(runtime, freeze['model_artifacts'][model]))
            gate = load(folder/'PARITY_GATE.json')
            check.check('gate_24_calls_12_fixtures_fixed_tolerances_'+model, subset(gate, {'passed': True, 'fixture_count': 12,
                'forward_calls': 24, 'expected_forward_calls': 24, 'exact_label_agreement_required': True,
                'fixtures_sha256': freeze['synthetic_gate_sha256'], 'logit_atol': .001, 'logit_rtol': 1e-5, 'probability_atol': 1e-5})
                and len(gate['checks']) == 12)
            for index, (fixture, observed) in enumerate(zip(adapter.synthetic_gate_requests(), gate['checks'])):
                prep = cross.independent_preparation(preparers[model], fixture['request'], model)
                a = cross.vector_answer(observed['optimized_logits'], fixture['keys'], fixture['type'])
                b = cross.vector_answer(observed['full_position_logits'], fixture['keys'], fixture['type'])
                delta = max(abs(x-y) for x, y in zip(observed['optimized_logits'], observed['full_position_logits']))
                pd = max(abs(a['probabilities'][k]-b['probabilities'][k]) for k in fixture['keys'])
                ok = all(abs(x-y) <= .001+1e-5*abs(y) for x, y in zip(observed['optimized_logits'], observed['full_position_logits'])) and pd <= 1e-5 and a['label'] == b['label']
                expected = {'fixture': fixture['fixture'], 'input_tokens': prep['input_tokens'], 'request_sha256': prep['request_sha256'],
                    'candidate_ids': prep['candidate_ids'], 'candidate_keys': fixture['keys'], 'optimized_probabilities': a['probabilities'],
                    'full_position_probabilities': b['probabilities'], 'optimized_top_logit_tie_count': a['top_logit_tie_count'],
                    'full_position_top_logit_tie_count': b['top_logit_tie_count'], 'optimized_label': a['label'], 'full_position_label': b['label'],
                    'max_absolute_logit_difference': delta, 'max_absolute_probability_difference': pd, 'labels_equal': True, 'passed': True}
                check.check(f'independent_actual_parity_{model}_{index}', ok and subset(observed, expected))
        check.check('exact_three_synthetic_warmups_'+model, len(r['warmups']) == 3
            and [w['synthetic_question'] for w in r['warmups']] == native_run.WARMUPS)
        for index, warm in enumerate(r['warmups']):
            answer, question = warm['answer'], warm['synthetic_question']
            keys = [key for key, _ in options_for(question)]
            calculated = cross.vector_answer(answer['candidate_logits' if native else 'logits'], keys, question['type'])
            if native:
                value_field = {'choice': 'choice', 'noul': 'noul', 'score': 'score'}[question['type']]
                numerical = {'probabilities': calculated['probabilities'], 'label': calculated['label'],
                    value_field: calculated['typed_value'], 'confidence': calculated['concentration'], 'candidate_keys': keys,
                    'native_decode_count': 1, 'temperature': 1., 'batch_size': 1,
                    'batch_strategy': 'sequential_independent_requests', 'projection': 'full_vocab_then_candidate_gather'}
            else:
                numerical = {**calculated, 'forward_calls': 1, 'use_cache': False, 'past_key_values_returned': False,
                    'model_training': False, 'grad_enabled': False, 'parameters_require_grad': False,
                    'inference_mode_enabled': True, 'candidate_boundary_verified': True, 'batch_size': 1,
                    'logits_to_keep': 1, 'projection': cross.PROJECTION, 'temperature': 1., 'error': None}
                prep = cross.independent_preparation(preparers[model],
                    old_conditions._request(question, options_for(question)), model)
                numerical.update(input_tokens=prep['input_tokens'], candidate_ids=prep['candidate_ids'])
            counter = answer.get('native_total_decode_count' if native else 'forward_calls_total')
            check.check(f'warmup_actual_decoding_{model}_{index}', set(warm) == {'index', 'synthetic_question', 'answer'}
                and warm['index'] == index and subset(answer, numerical) and counter == index+(1 if native else 25)
                and type(answer['output_tokens']) is int and answer['output_tokens'] == 0
                and type(answer['input_tokens']) is int and 1 <= answer['input_tokens'] <= 2048
                and finite(answer['latency_ms']) and finite(answer['model_ms']) and 0 <= answer['model_ms'] <= answer['latency_ms']+1e-6
                and len(answer['candidate_ids']) == len(set(answer['candidate_ids'])) == len(keys)
                and all(type(i) is int and i >= 0 for i in answer['candidate_ids']))
        measured = r['predictions']
        check.check('4800_rows_600_unique_items_'+model, len(measured) == 4800 and len({row['item_id'] for row in measured}) == 600)
        bad = defaultdict(list)
        for index, row in enumerate(measured):
            if index >= len(schedule):
                bad['unscheduled'].append(index)
                continue
            meta = dict(schedule[index], model_key=model, backend='llama.cpp' if native else 'transformers')
            if not native:
                meta.update(tokens[model][index])
            observations = NATIVE_OBSERVATIONS if native else cross.OBSERVATION_FIELDS
            if not subset(row, meta) or set(row) != set(meta) | observations:
                bad['metadata'].append(index)
            computed = cross.vector_answer(row['logits'], row['candidate_keys'], row['type'])
            if native:
                computed.pop('top_logit_tie_count')
                computed['exact_top_logit_tie_keys'] = [k for k, value in zip(row['candidate_keys'], row['logits']) if value == max(row['logits'])]
            if not subset(row, computed):
                bad['semantic_decoding'].append(index)
            contract = row.get('error') is None and row.get('output_tokens') == 0 and row.get('temperature') == 1
            contract &= type(row.get('output_tokens')) is int and type(row.get('temperature')) in (int, float)
            contract &= type(row.get('input_tokens')) is int and 1 <= row['input_tokens'] <= 2048
            contract &= finite(row.get('model_ms')) and finite(row.get('latency_ms')) and 0 <= row['model_ms'] <= row['latency_ms']+1e-6
            contract &= isinstance(row.get('candidate_ids'), list) and len(row['candidate_ids']) == len(set(row['candidate_ids'])) == len(row['candidate_keys'])
            contract &= all(type(i) is int and i >= 0 for i in row['candidate_ids'])
            if native:
                contract &= subset(row, {'native_decode_count': 1, 'native_total_decode_count': index+4, 'state_cleared': True,
                    'thinking_enabled': False, 'projection': 'full_vocab_then_candidate_gather'})
                contract &= 'forward_calls' not in row and 'forward_calls_total' not in row
            else:
                contract &= subset(row, {'forward_calls': 1, 'forward_calls_total': index+28, 'use_cache': False,
                    'past_key_values_returned': False, 'model_training': False, 'grad_enabled': False, 'parameters_require_grad': False,
                    'inference_mode_enabled': True, 'candidate_boundary_verified': True, 'batch_size': 1, 'logits_to_keep': 1,
                    'projection': cross.PROJECTION, 'tie_break': 'first_candidate_vector_index'})
                contract &= not bool(set(row) & NATIVE_FIELDS)
            if not contract:
                bad['actual_runtime_contract'].append(index)
            if cross.private_fields(row):
                bad['private_input_fields'].append(index)
        for name in ('metadata', 'semantic_decoding', 'actual_runtime_contract', 'private_input_fields', 'unscheduled'):
            check.check(name+'_'+model, not bad[name], {'failed_request_indices': bad[name]})
        check.check('no_private_inputs_in_model_receipts_'+model, not any(cross.private_fields(r[k]) for k in ('attempt', 'runtime', 'completion')))
    for model in models:
        check.phase('model_integrity_'+model, lambda m=model: model_checks(m))
        if model in records:
            directory = analysis/model if (analysis/model/'SUMMARY.json').exists() else analysis
            check.phase('independent_analysis_'+model, lambda m=model, d=directory: analysis_checks(
                check, d, m, records[m]['predictions'], ensembles, schedule, freeze, study))
    return check


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('study', 'questions', 'analysis', 'output'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--model-key', choices=MODELS)
    parser.add_argument('--raw-dir', type=Path, help='Pinned upstream cache; defaults beside the private order-ensemble directory')
    args = parser.parse_args()
    if args.output.exists():
        parser.error('Audit output already exists; preserve it and choose a new report path')
    if args.output.resolve().is_relative_to((args.study/'results').resolve()):
        parser.error('Write the audit outside immutable model results')
    models = (args.model_key,) if args.model_key else MODELS
    check = common.Audit()
    try:
        check = audit(args.study, args.questions, args.analysis, models, args.raw_dir)
    except Exception as error:
        check.check('unexpected_audit_exception', False, {'error_type': type(error).__name__})
    report = {'schema_version': 1, 'created_at': datetime.now(timezone.utc).isoformat(),
        'role': 'Post-hoc verifier authored after study source freeze; not a prospective method change.',
        'audit_source_sha256': sha(Path(__file__).read_bytes()), 'models_checked': list(models),
        'model_loads': 0, 'model_forwards': 0, 'passed': not check.failures, 'n_checks': len(check.checks),
        'n_failed': len(check.failures), 'checks': check.checks, 'failures': check.failures, 'recomputed': check.recomputed,
        'limits': ['Native model verification is tied to the frozen startup verification receipt; this audit does not reload that model.',
                   'Native warmup records omit state-cleared/thinking flags after the shared helper validator; only recorded warmup fields can be audited independently.',
                   'Selected installed implementation files are hashed; this is not exhaustive OS or transitive dependency verification.',
                   'Local timestamps and hashes are integrity evidence, not independent registration or proof against fabrication.',
                   'Descriptive bootstrap intervals retain the prospective grouping assumptions and do not establish pretraining independence.']}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    print(canonical({'passed': report['passed'], 'checks': report['n_checks'], 'failures': report['n_failed'], 'model_forwards': 0}))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
