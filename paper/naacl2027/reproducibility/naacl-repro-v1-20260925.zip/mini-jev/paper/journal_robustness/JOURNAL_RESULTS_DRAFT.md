# Candidate-presentation robustness: empirical section draft

**Working empirical section, not a submission-ready manuscript.** Both completed
panels passed independent audits: 93 native and 163 cross-checkpoint checks.

## Methods

We evaluated three frozen checkpoints on the same 600 previously selected
public-development items: 200 judgments from
[JCoLA](https://github.com/osekilab/JCoLA/tree/736d9eef3af04bb17e4cf59adf01325973234ff9)
(100 in-domain, 100 out-of-domain) and 200 examples each from JSTS and
JCommonsenseQA in [JGLUE](https://github.com/yahoojapan/JGLUE/tree/6f071c09316baae89c3d083a90985b4b1cb9968c).
The sample was reused without resampling; reference values, IDs and hashes were
verified. Its grouping proxies comprise 34 bibliographic sources, 196 caption
components and 200 exact-question groups, respectively.

The first panel used Qwen3.6-35B-A3B Q4_K_M through a native runtime on an Apple
M5 Pro 64GB system. Its 4,000 requests covered baseline, an exact repeat and
eligible presentation changes. The primary manipulation reversed option-line
order while preserving source content, candidate meanings, output-token
assignments and the candidate vector; both repeated prompt copies changed
consistently. Secondary manipulations appear in Table 1. Protocols and request
hashes were locally frozen before inference, without independent public
preregistration. Item blocks and conditions followed a fixed randomized order.

A separate replication filtered that schedule, without reordering or changing
completed requests, to baseline, exact repeat and display reversal. Pinned
Qwen2.5-0.5B-Instruct and Qwen2.5-1.5B-Instruct each executed 1,800 requests using
Transformers, MPS, float32, eager attention and no KV cache. All 1,800 input token
sequences and context-sensitive candidate IDs matched between their tokenizers
before freezing. Each model passed 12 synthetic final-position/full-position
parity comparisons (24 forwards), followed by three warmups: 27 excluded forwards
per model. Fixed tolerances were logit atol=1e-3/rtol=1e-5, probability atol=1e-5,
and exact argmax agreement. The native panel excluded three warmup requests.

Together the panels contain 7,600 benchmark measurements on 600 shared items,
not 7,600 independent questions. Actual Transformers forward counters remain
separate from native decode counters. Allowed-token logits were normalized at
T=1 and aligned by semantic key; no answer tokens, training or calibration fitting
were used. Primary outcomes are classification flip rates and JSTS mean absolute
expected-score change on its original 0–5 scale. Accuracy/MCC and continuous-gold
MAE describe performance separately. No confidence intervals or significance
tests are supplied.

## Results

All 7,600 requests completed without inference errors. The 600 exact-input repeat
pairs per checkpoint—1,800 pairs overall—had identical saved raw logits and
probabilities. No benchmark request had an exact top-logit tie. Thus the observed
changes exceed the repeat variability observed here and are not tie-breaking
artifacts; universal determinism is not established.

Table 1 reports all native-panel conditions. Each applicable entry represents
200 items. Changes compare against baseline; dashes denote inapplicable
conditions or the reference row. Display reversal is primary.

| Condition | JCoLA flips (%) | JCoLA accuracy (%) / MCC | JCQA flips (%) | JCQA accuracy (%) | JSTS mean absolute score change | JSTS expected-score MAE |
|---|---:|---:|---:|---:|---:|---:|
| Baseline | — | 86.0 / 0.5708 | — | 95.0 | — | 0.5065 |
| Exact baseline repeat | 0.0 | 86.0 / 0.5708 | 0.0 | 95.0 | 0.0000 | 0.5065 |
| **Display reversal** | **5.5** | **82.5 / 0.5055** | **5.5** | **96.0** | **0.1817** | **0.4844** |
| Display rotation | — | — | 8.5 | 90.0 | 0.2983 | 0.5391 |
| Output-label reversal | 3.0 | 87.0 / 0.5892 | 7.0 | 91.0 | — | — |
| Displayed-key substitution | 4.5 | 84.5 / 0.5626 | 3.5 | 95.5 | — | — |
| Instruction rewording | 5.0 | 86.0 / 0.5708 | 1.0 | 95.0 | 0.1209 | 0.5231 |
| Definition rewording | 3.5 | 87.5 / 0.6138 | — | — | 0.1287 | 0.5105 |

Display reversal changed 11/200 native classifications in each categorical task,
while accuracy decreased on JCoLA and increased on JCQA. JSTS MAE also improved
despite changed individual scores. Instruction rewording left JCoLA accuracy and
MCC unchanged while changing ten judgments: five correct-to-incorrect transitions
offset five incorrect-to-correct transitions. Aggregate performance therefore did
not summarize individual-decision stability.

Across native-panel manipulations, 19 flipped pairs involving 18 distinct JCQA
items had baseline maximum candidate probability ≥0.9: reversal 3, rotation 10,
label reversal 5 and key substitution 1. One rotation changed a correct answer
with maximum candidate probability 0.99936 to an incorrect answer with 0.91103.
These are candidate-normalized probabilities, not correctness probabilities or
entropy-based concentration; repeated pairs are not independent source items.

Table 2 reports smaller-checkpoint display reversal. Performance columns show
baseline→reversal; each dataset contains 200 paired items.

| Checkpoint | JCoLA flips (%) | JCQA flips (%) | JCQA accuracy (%) | JSTS mean absolute score change | JSTS expected-score MAE |
|---|---:|---:|---:|---:|---:|
| Qwen2.5-0.5B | 99.5 | 66.5 | 37.5→38.5 | 1.43094 | 1.3996→1.2293 |
| Qwen2.5-1.5B | 0.0 | 21.5 | 80.5→76.0 | 0.10173 | 1.2096→1.1910 |

Stable predictions could also be degenerate. On JCoLA, the 1.5B checkpoint
predicted `true` for all 200 items under baseline, repeat and reversal, yielding
zero flips but 79% accuracy—the sample's majority-label rate—and undefined MCC.
The 0.5B baseline predicted `false` 199 times and `true` once; reversal predicted
`true` throughout, increasing accuracy from 21.5% to 79% while producing 99.5%
flips and undefined reversal MCC. Neither stability alone nor majority-driven
accuracy establishes class discrimination. Performance, prediction marginals and
stability need joint interpretation.

## Limitations

These descriptive observations do not establish novelty, population significance,
a causal model-size effect or readout-specific failure. The smaller checkpoints
share a family and tokenizer; comparison with the native 35B run additionally
confounds architecture/version, quantization and backend. Latency is not a fair
cross-backend comparison. Reused public dev data are not newly held out; training
contamination and unmeasured dependence remain unknown. Fixed rewordings lack
human equivalence validation. Display changes jointly alter token positions and
contextual conditioning. No calibrated correctness or deployment reliability is
established, and favorable variants must not be selected on these outcomes.

Evidence: native [metrics](study_v1/analysis/SUMMARY.json) and
[audit](study_v1/AUDIT.json); cross-checkpoint
[metrics](cross_model/study_v1/analysis/SUMMARY.json) and
[audit](cross_model/study_v1/AUDIT.json). Full schedules, raw text-free predictions,
gate measurements and completion receipts accompany both panels.
An [audit-only correction](cross_model/study_v1/AUDIT_CORRECTION.json) records a
counter-field naming mismatch in the independent auditor; frozen inference
records were unchanged and no inference rerun was required.
