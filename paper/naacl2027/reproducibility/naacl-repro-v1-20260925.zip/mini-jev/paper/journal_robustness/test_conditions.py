"""Synthetic fixtures test semantic mappings; no source dataset text or model."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from conditions import (DEFINITION_REWORD, INSTRUCTION_REWORD, SOURCE_PROMPTS,
                        NativeEngine, options_for, variants)


def fixture(dataset):
    prompt = SOURCE_PROMPTS[dataset]
    row = {"id": "synthetic:" + dataset, "dataset": dataset, "type": prompt["type"],
           "state": "SYNTHETIC TEST INPUT", "instructions": prompt["instructions"],
           "criteria": deepcopy(prompt.get("criteria"))}
    if dataset == "JCommonsenseQA":
        row["criteria"] = {f"option_{i}": f"Synthetic candidate {i}" for i in range(5)}
        row["label"] = "option_3"
    elif dataset == "JCoLA":
        row["label"] = "true"
    else:
        row["gold_score"] = 3.75
    return row


def by_name(row):
    return {item["condition"]: item for item in variants(row)}


def option_lines(item):
    content = item["request"]["messages"][1]["content"]
    half = content[:(len(content) - 2) // 2]
    assert content == half + "\n\n" + half
    return half.rsplit("\n\n選択肢:\n", 1)[1].split("\n\n", 1)[0].splitlines()


class ConditionsTest(unittest.TestCase):
    def test_baseline_native_identity_and_repeat_deepcopy(self):
        for dataset in SOURCE_PROMPTS:
            row = fixture(dataset)
            before = deepcopy(row)
            out = by_name(row)
            formatter = object.__new__(NativeEngine)
            formatter.prompt_style = "repeat_typed_score"
            options = options_for(row)
            candidates, prefix, _ = formatter._candidate_spec(row, options)
            request = {"messages": formatter._messages(row, options),
                       "candidates": candidates, "max_input_tokens": 2048}
            if prefix:
                request["assistant_prefix"] = prefix
            self.assertEqual(out["baseline"]["request"], request)
            self.assertEqual(out["baseline"]["request"], out["baseline_repeat"]["request"])
            self.assertIsNot(out["baseline"]["request"], out["baseline_repeat"]["request"])
            self.assertEqual(row, before)

    def test_eligibility_and_exact_request_budget(self):
        counts = {dataset: len(variants(fixture(dataset))) for dataset in SOURCE_PROMPTS}
        self.assertEqual(counts, {"JCoLA": 7, "JSTS": 6, "JCommonsenseQA": 7})
        self.assertEqual(sum(counts.values()) * 200, 4000)
        self.assertNotIn("display_rotate", by_name(fixture("JCoLA")))
        self.assertNotIn("definition_reword", by_name(fixture("JCommonsenseQA")))
        for name in ("label_reverse", "opaque_keys"):
            self.assertNotIn(name, by_name(fixture("JSTS")))

    def test_display_mutations_keep_token_meaning_binding(self):
        for dataset in SOURCE_PROMPTS:
            out = by_name(fixture(dataset))
            baseline = out["baseline"]
            original = option_lines(baseline)
            for condition, expected in [("display_reverse", original[::-1]),
                                        ("display_rotate", original[1:] + original[:1])]:
                if condition not in out:
                    continue
                item = out[condition]
                self.assertEqual(option_lines(item), expected)
                self.assertEqual(item["candidate_keys"], baseline["candidate_keys"])
                self.assertEqual(item["request"]["candidates"], baseline["request"]["candidates"])
                self.assertEqual(item["request"].get("assistant_prefix"),
                                 baseline["request"].get("assistant_prefix"))

    def test_label_reversal_semantic_decoding(self):
        for dataset in ("JCoLA", "JCommonsenseQA"):
            row = fixture(dataset)
            out = by_name(row)
            base, reverse = out["baseline"], out["label_reverse"]
            self.assertEqual(reverse["request"]["candidates"], base["request"]["candidates"])
            # A fixture oracle chooses the same final semantic option in either
            # request, even though its required letter and vector index change.
            chosen_key = base["candidate_keys"][-1]
            self.assertEqual(reverse["candidate_keys"][0], chosen_key)
            semantic_sequence = [line.split(". ", 1)[1] for line in option_lines(reverse)]
            self.assertEqual(semantic_sequence,
                             [line.split(". ", 1)[1] for line in option_lines(base)])
            binding = {line.split(". ", 1)[0]: line.split(". ", 1)[1].split(": ", 1)[0]
                       for line in option_lines(reverse)}
            self.assertEqual([binding[token] for token in reverse["request"]["candidates"]],
                             reverse["candidate_keys"])

    def test_opaque_changes_keys_only(self):
        for dataset in ("JCoLA", "JCommonsenseQA"):
            out = by_name(fixture(dataset))
            base, opaque = out["baseline"], out["opaque_keys"]
            self.assertEqual(opaque["candidate_keys"], base["candidate_keys"])
            for i, (old, new) in enumerate(zip(option_lines(base), option_lines(opaque))):
                self.assertEqual(old.split(": ", 1)[1], new.split(": ", 1)[1])
                self.assertEqual(new.split(": ", 1)[0], f"{chr(65+i)}. slot_{i}")

    def test_rewording_preserves_state_and_gold_not_sent(self):
        for dataset in SOURCE_PROMPTS:
            row = fixture(dataset)
            out = by_name(row)
            request = out["instruction_reword"]["request"]
            user = request["messages"][1]["content"]
            self.assertEqual(user.count(INSTRUCTION_REWORD[dataset]), 2)
            self.assertEqual(user.count(row["state"]), 2)
            self.assertNotIn(row["id"], user)
            self.assertNotIn("gold_score", user)
            self.assertEqual(option_lines(out["instruction_reword"]), option_lines(out["baseline"]))
            if dataset in DEFINITION_REWORD:
                user = out["definition_reword"]["request"]["messages"][1]["content"]
                self.assertEqual(user.count(row["instructions"]), 2)
                definitions = DEFINITION_REWORD[dataset]
                values = definitions.values() if isinstance(definitions, dict) else definitions
                for value in values:
                    self.assertEqual(user.count(value), 2)

    def test_score_scale_and_numeric_labels_never_reassigned(self):
        row = fixture("JSTS")
        for item in variants(row):
            self.assertEqual(item["candidate_keys"], [str(i) for i in range(6)])
            self.assertEqual(item["request"]["candidates"], [str(i) for i in range(6)])
            self.assertEqual(item["request"]["assistant_prefix"], '{"answer":')
            self.assertIn("0から5", item["request"]["messages"][1]["content"])
        self.assertEqual(row["gold_score"], 3.75)

    def test_state_with_lookalike_options_is_unchanged(self):
        row = fixture("JCommonsenseQA")
        lookalike = "\n\n選択肢:\n" + "\n".join(
            f"{chr(65+i)}. option_{i}: Synthetic candidate {i}" for i in range(5)) + "\n\nEND"
        row["state"] += lookalike
        for name, item in by_name(row).items():
            self.assertEqual(item["request"]["messages"][1]["content"].count(row["state"]), 2, name)

    def test_fail_closed_on_unexpected_schema(self):
        examples = []
        row = fixture("JCommonsenseQA"); row["dataset"] = "UNSEEN"; examples.append(row)
        row = fixture("JCommonsenseQA"); row["criteria"]["option_5"] = "extra"; examples.append(row)
        row = fixture("JCoLA"); row["criteria"]["true"] = "changed meaning"; examples.append(row)
        row = fixture("JSTS"); row["criteria"] = row["criteria"][::-1]; examples.append(row)
        row = fixture("JSTS"); row["gold_score"] = float("nan"); examples.append(row)
        row = fixture("JSTS"); row["label"] = "4"; examples.append(row)
        row = fixture("JCoLA"); row["type"] = "choice"; examples.append(row)
        row = fixture("JCoLA"); row["state"] = {}; examples.append(row)
        row = fixture("JCoLA"); row["instructions"] += " modified"; examples.append(row)
        for row in examples:
            with self.assertRaises(ValueError):
                variants(row)


if __name__ == "__main__":
    unittest.main()
