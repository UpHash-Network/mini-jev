#!/usr/bin/env python3
"""Actual-Transformers contract audit with unchanged study_v1 semantic statistics.

This module never fabricates native observations or mutates the frozen analyzer.
Its accounting/validation is explicit; shared paired and dataset metric functions
are imported from the exact frozen study_v1 implementation.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from paper.journal_robustness import analyze as shared

TOL = shared.TOL
HIGH_MAX_PROBABILITY = shared.HIGH_MAX_PROBABILITY
IDENTITY_FIELDS = (*shared.IDENTITY_FIELDS, "model_key")
MODEL_REVISIONS = {"qwen2.5-0.5b": "7ae557604adf67be50417f59c2c2f167def9a775",
                   "qwen2.5-1.5b": "989aa7980e4cf806f80c7fef2b1adb7bc71aa306"}
MODEL_KEYS = tuple(MODEL_REVISIONS)
finite = shared.finite
softmax = shared.softmax
logical_key = shared.logical_key
item_key = shared.item_key
expected_score = shared.expected_score
metric_rows = shared.metric_rows
pair_measurement = shared.pair_measurement
comparison_row = shared.comparison_row
read_records = shared.read_records
write_csv = shared.write_csv

def validate_row(row: dict) -> list[str]:
    errors = []
    if any(field in row for field in ("input_ids", "messages", "state", "prompt", "rendered_prompt", "instructions", "criteria")):
        errors.append("private_input_fields_forbidden")
    for field in IDENTITY_FIELDS:
        if not isinstance(row.get(field), str) or not row[field]:
            errors.append(f"invalid_{field}")
    if type(row.get("request_index")) is not int or row["request_index"] < 0:
        errors.append("invalid_request_index")
    digest = row.get("request_sha256")
    if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        errors.append("invalid_request_sha256")
    keys = row.get("candidate_keys")
    if not isinstance(keys, list) or len(keys) < 2 or any(not isinstance(k, str) for k in keys) or len(set(keys)) != len(keys):
        return errors + ["invalid_candidate_keys"]
    probs, logits = row.get("probabilities"), row.get("logits")
    if not isinstance(probs, dict) or set(probs) != set(keys):
        return errors + ["probability_keys_mismatch"]
    if any(not finite(v) or not 0 <= v <= 1 for v in probs.values()) or not math.isclose(sum(probs.values()), 1.0, abs_tol=TOL):
        return errors + ["invalid_probability_distribution"]
    if not isinstance(logits, list) or len(logits) != len(keys) or any(not finite(x) for x in logits):
        errors.append("invalid_logits")
    else:
        if any(abs(probs[k] - p) > TOL for k, p in zip(keys, softmax(logits))):
            errors.append("probabilities_do_not_match_t1_logits")
        expected_label = keys[max(range(len(keys)), key=logits.__getitem__)]
        if row.get("label") != expected_label:
            errors.append("label_not_first_candidate_vector_argmax")
        if "exact_top_logit_tie_keys" in row and row["exact_top_logit_tie_keys"] != [k for k, v in zip(keys, logits) if v == max(logits)]:
            errors.append("top_logit_tie_metadata_mismatch")
    label = row.get("label")
    if label not in probs or (label in probs and max(probs.values()) - probs[label] > TOL):
        errors.append("label_not_canonical_argmax")
    for field in ("input_tokens", "output_tokens", "forward_calls", "forward_calls_total"):
        if type(row.get(field)) is not int or row[field] < 0:
            errors.append(f"invalid_{field}")
    if type(row.get("input_tokens")) is int and not 1 <= row["input_tokens"] <= 2048:
        errors.append("input_tokens_outside_1_to_2048")
    if row.get("output_tokens") != 0:
        errors.append("direct_readout_output_tokens_must_be_zero")
    if row.get("forward_calls") != 1:
        errors.append("forward_calls_must_be_one")
    if row.get("backend") != "transformers":
        errors.append("backend_must_be_transformers")
    if row.get("use_cache") is not False:
        errors.append("use_cache_must_be_false")
    if row.get("past_key_values_returned") is not False:
        errors.append("past_key_values_must_not_be_returned")
    if row.get("candidate_boundary_verified") is not True:
        errors.append("candidate_boundary_must_be_verified")
    if row.get("batch_size") != 1:
        errors.append("batch_size_must_be_one")
    if row.get("projection") != "stock_causal_lm_last_position_full_vocab_then_candidate_gather":
        errors.append("projection_mismatch")
    ids = row.get("candidate_ids")
    if not isinstance(ids, list) or len(ids) != len(keys) or any(type(x) is not int or x < 0 for x in ids) or len(set(ids)) != len(ids):
        errors.append("invalid_or_duplicate_candidate_ids")
    if row.get("model_training") is not False:
        errors.append("model_must_be_eval")
    if row.get("grad_enabled") is not False:
        errors.append("grad_must_be_disabled")
    if row.get("inference_mode_enabled") is not True:
        errors.append("inference_mode_must_be_enabled")
    if row.get("parameters_require_grad") is not False:
        errors.append("parameter_grads_must_be_disabled")
    if row.get("logits_to_keep") != 1:
        errors.append("logits_to_keep_must_be_one")
    if not finite(row.get("temperature")) or row["temperature"] != 1:
        errors.append("temperature_must_be_one")
    if any(field in row for field in ("native_decode_count", "native_total_decode_count", "state_cleared", "thinking_enabled")):
        errors.append("native_observation_fields_forbidden")
    if row.get("model_key") not in MODEL_KEYS:
        errors.append("unknown_model_key")
    else:
        if row.get("revision") != MODEL_REVISIONS[row["model_key"]]:
            errors.append("model_revision_mismatch")
    if type(row.get("model_request_index")) is not int or row["model_request_index"] < 0:
        errors.append("invalid_model_request_index")
    elif row.get("forward_calls_total") != row["model_request_index"] + 28:
        errors.append("cumulative_forward_count_mismatch")
    for field in ("tokenized_input_sha256", "rendered_sha256"):
        value = row.get(field)
        if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
            errors.append("invalid_" + field)
    if not finite(row.get("latency_ms")) or row["latency_ms"] < 0:
        errors.append("invalid_latency_ms")
    if not finite(row.get("model_ms")) or row["model_ms"] < 0 or (finite(row.get("latency_ms")) and row["model_ms"] > row["latency_ms"] + TOL):
        errors.append("invalid_model_ms")
    kind = row.get("type")
    if kind == "score":
        scale = row.get("score_values")
        if not isinstance(scale, dict) or set(scale) != set(keys) or any(not finite(v) for v in scale.values()):
            errors.append("invalid_score_values")
        else:
            gold = row.get("gold_score")
            if not finite(gold) or not min(scale.values()) <= gold <= max(scale.values()):
                errors.append("invalid_gold_score")
            if not finite(row.get("typed_value")) or not math.isclose(row["typed_value"], expected_score(row), abs_tol=TOL):
                errors.append("typed_value_not_expected_score")
            if row.get("dataset") == "JSTS" and scale != {str(i): i for i in range(6)}:
                errors.append("jsts_scale_must_be_0_to_5")
    elif kind in ("noul", "choice"):
        if row.get("gold_label") not in keys:
            errors.append("invalid_gold_label")
        if kind == "noul":
            if set(keys) != {"false", "true"}:
                errors.append("noul_keys_must_be_false_true")
            elif not finite(row.get("typed_value")) or not math.isclose(row["typed_value"], probs["true"], abs_tol=TOL):
                errors.append("typed_value_not_p_true")
        elif row.get("typed_value") != label:
            errors.append("typed_value_not_choice_label")
    else:
        errors.append("unsupported_type")
    return errors

def analyze_one(predictions: list[dict], schedule: list[dict] | None = None) -> dict:
    """Return output tables plus explicit request accounting; never silently deduplicate."""
    failures, valid, statuses = [], [], []
    def fail(row: dict, code: str, detail: str = "") -> None:
        failures.append({"request_index": row.get("request_index"), "dataset": row.get("dataset"),
                         "item_id": row.get("item_id"), "condition": row.get("condition"),
                         "code": code, "detail": detail})
    by_index = defaultdict(list)
    for row in predictions:
        index = row.get("request_index")
        if type(index) is int and index >= 0:
            by_index[index].append(row)
        else:
            fail(row, "invalid_request_index")
    expected = schedule if schedule is not None else predictions
    expected_indices = Counter(r.get("request_index") for r in expected)
    expected_logical = Counter(logical_key(r) for r in expected)
    observed_logical = Counter(logical_key(r) for r in predictions)
    for meta in expected:
        index = meta.get("request_index")
        candidates = by_index.get(index, [])
        status = "valid"
        row = candidates[0] if len(candidates) == 1 else None
        if expected_indices[index] > 1:
            status = "duplicate_schedule_request_index" if schedule is not None else "duplicate_request_index"
        elif expected_logical[logical_key(meta)] > 1:
            status = "duplicate_schedule_item_condition" if schedule is not None else "duplicate_item_condition"
        elif not candidates:
            status = "missing_prediction"
        elif len(candidates) > 1:
            status = "duplicate_request_index"
        elif observed_logical[logical_key(row)] > 1:
            status = "duplicate_item_condition"
        elif schedule is not None and any(row.get(k) != meta.get(k) for k in IDENTITY_FIELDS):
            status = "schedule_identity_mismatch"
        elif schedule is not None and any(row.get(k) != value for k, value in meta.items()):
            status = "schedule_metadata_mismatch"
        elif row.get("error") is not None:
            status = "inference_error"
        else:
            reasons = validate_row(row)
            if reasons:
                status = "invalid_measurement"
                fail(meta, status, ";".join(reasons))
        statuses.append({**{k: meta.get(k) for k in ("request_index", *IDENTITY_FIELDS)}, "status": status})
        if status == "valid":
            valid.append(row)
        elif status != "invalid_measurement":
            # Do not copy arbitrary model/HTTP error bodies: they may contain source text.
            fail(meta, status)
    if schedule is not None:
        for row in predictions:
            if row.get("request_index") not in expected_indices:
                fail(row, "unscheduled_prediction")
    # Cross-condition gold/scale/type/group invariance is an integrity requirement.
    grouped_valid = defaultdict(list)
    for row in valid:
        grouped_valid[item_key(row)].append(row)
    inconsistent = set()
    for key, rows in grouped_valid.items():
        anchor = next((r for r in rows if r["condition"] == "baseline"), rows[0])
        for row in rows:
            if set(row["candidate_keys"]) != set(anchor["candidate_keys"]) or any(row.get(f) != anchor.get(f) for f in ("type", "group", "split", "gold_label", "gold_score", "score_values")):
                inconsistent.add(key)
    if inconsistent:
        for row in valid:
            if item_key(row) in inconsistent:
                fail(row, "inconsistent_item_metadata")
        for status in statuses:
            if item_key(status) in inconsistent and status["status"] == "valid":
                status["status"] = "inconsistent_item_metadata"
        valid = [r for r in valid if item_key(r) not in inconsistent]
    lookup = {logical_key(r): r for r in valid}
    planned = {logical_key(r): r for r in expected}
    dataset_conditions = sorted({(r.get("dataset", ""), r.get("condition", "")) for r in expected})
    metrics, comparisons, paired = [], [], []
    for dataset, condition in dataset_conditions:
        selected = [r for r in valid if r["dataset"] == dataset and r["condition"] == condition]
        planned_rows = [r for r in expected if r.get("dataset") == dataset and r.get("condition") == condition]
        scopes = [("all", "")] + [(s, g) for s in ("split", "group") for g in sorted({r.get(s, "") for r in planned_rows})]
        for scope, group in scopes:
            scoped = selected if scope == "all" else [r for r in selected if r.get(scope) == group]
            n_scheduled = len(planned_rows) if scope == "all" else sum(r.get(scope) == group for r in planned_rows)
            met = metric_rows(scoped, dataset, condition, scope, group)
            met.update(n_scheduled=n_scheduled, n_unavailable=n_scheduled-len(scoped))
            metrics.append(met)
        if condition == "baseline":
            continue
        eligible = []
        complete = []
        for meta in planned_rows:
            key = (dataset, meta.get("item_id"), "baseline")
            if key not in planned:
                fail(meta, "baseline_not_scheduled")
            eligible.append(meta)
            base, variant = lookup.get(key), lookup.get(logical_key(meta))
            if not base or not variant:
                continue
            try:
                pair = pair_measurement(base, variant)
            except ValueError as exc:
                fail(meta, "invalid_pair", str(exc))
                continue
            complete.append(pair)
        paired.extend(complete)
        for scope, group in scopes:
            pairs = complete if scope == "all" else [p for p in complete if p.get(scope) == group]
            n_eligible = len(eligible) if scope == "all" else sum(r.get(scope) == group for r in eligible)
            comparisons.append(comparison_row(pairs, n_eligible, dataset, condition, scope, group))
    summary = {
        "schema_version": 1,
        "accounting": {"schedule_supplied": schedule is not None, "scheduled_requests": len(expected),
                       "observed_prediction_rows": len(predictions), "valid_requests": len(valid),
                       "unavailable_scheduled_requests": len(expected)-len(valid),
                       "scheduled_status_counts": dict(sorted(Counter(s["status"] for s in statuses).items())),
                       "failure_records": len(failures), "failure_code_counts": dict(sorted(Counter(f["code"] for f in failures).items())),
                       "unique_source_items": len({item_key(r) for r in expected}),
                       "source_items_by_dataset": dict(sorted(Counter(d for d, _ in {item_key(r) for r in expected}).items())),
                       "observed_total_input_tokens": sum(r.get("input_tokens", 0) for r in predictions if type(r.get("input_tokens")) is int),
                       "observed_total_output_tokens": sum(r.get("output_tokens", 0) for r in predictions if type(r.get("output_tokens")) is int),
                       "observed_forward_calls_total": sum(r.get("forward_calls", 0) for r in predictions if type(r.get("forward_calls")) is int)},
        "definitions": {"alignment": "Canonical semantic candidate keys; list/token positions may change across conditions.",
                        "probability_validation": "Candidate-only softmax of measured logits at T=1; no calibration fitted.",
                        "observation_contract": "Transformers; input tokens1..2048; zero output tokens; one forward; eval/inference without parameter gradients or KV cache; logits_to_keep=1; T=1. No native counters.",
                        "tie_breaking": "First maximum in the actual candidate/logit vector order; exact ties and tie-associated flips reported separately.",
                        "normalized_jensen_shannon": "Jensen-Shannon divergence divided by ln(2), range [0,1]; not square-root distance.",
                        "high_max_probability_threshold": HIGH_MAX_PROBABILITY,
                        "high_max_probability_warning": "Maximum candidate probability is not calibrated correctness probability; this threshold is distinct from entropy-based concentration.",
                        "flip_rate_denominator": "Complete valid baseline/condition pairs only; unavailable and invalid pairs counted separately.",
                        "mcc_degenerate_convention": "MCC = null when denominator is zero; mcc_degenerate is explicitly true.",
                        "inference_scope": "Descriptive fixed-sample statistics; repeated conditions are not independent questions. No confidence interval or population significance claim.",
                        "dependencies": "Group counts expose measured source proxies only; semantic dependencies and model training contamination remain unknown.",
                        "schedule_warning": None if schedule is not None else "Without a schedule, requests absent from the entire predictions file cannot be detected."},
        "per_dataset": [m for m in metrics if m["scope"] == "all"],
        "per_split": [m for m in metrics if m["scope"] == "split"],
        "condition_differences": [c for c in comparisons if c["scope"] == "all"],
        "condition_differences_by_split": [c for c in comparisons if c["scope"] == "split"]}
    return {"summary": summary, "per_dataset": metrics, "condition_differences": comparisons,
            "paired_differences": paired, "failures": failures, "request_accounting": statuses,
            "high_max_probability_flips": [p for p in paired if p["baseline_high_max_probability_flip"]]}


def analyze(predictions: list[dict], schedule: list[dict]) -> dict:
    if not schedule:
        raise ValueError("A nonempty frozen schedule is required")
    if any(row.get("model_key") not in MODEL_KEYS for row in schedule):
        raise ValueError("Unknown model in schedule")
    tables = {key: [] for key in ("per_dataset", "condition_differences", "paired_differences",
                                 "failures", "request_accounting", "high_max_probability_flips")}
    models = {}
    for model_key in MODEL_KEYS:
        planned = [r for r in schedule if r.get("model_key") == model_key]
        observed = [r for r in predictions if r.get("model_key") == model_key]
        result = analyze_one(observed, planned)
        models[model_key] = result["summary"]
        for key in tables:
            tables[key].extend({"model_key": model_key, **row} for row in result[key])
    unknown = [r for r in predictions if r.get("model_key") not in MODEL_KEYS]
    for row in unknown:
        tables["failures"].append({"model_key": str(row.get("model_key")),
                                  "request_index": row.get("request_index"), "code": "unknown_model_prediction",
                                  "item_id": row.get("item_id"), "dataset": row.get("dataset"),
                                  "condition": row.get("condition"), "detail": ""})
    accounting = {"scheduled_requests": len(schedule), "observed_prediction_rows": len(predictions),
                  "unique_source_items": len({item_key(r) for r in schedule}),
                  "model_item_pairs": len({(r["model_key"], *item_key(r)) for r in schedule}),
                  "valid_requests": sum(m["accounting"]["valid_requests"] for m in models.values()),
                  "unknown_model_prediction_rows": len(unknown),
                  "failure_records": len(tables["failures"]),
                  "failure_code_counts": dict(sorted(Counter(f["code"] for f in tables["failures"]).items()))}
    accounting["unavailable_scheduled_requests"] = len(schedule) - accounting["valid_requests"]
    tables["summary"] = {"schema_version": 1, "accounting": accounting, "models": models,
                         "interpretation": "Separate descriptive checkpoint results on the same source items; no pooled accuracy, causal model-size effect, cross-backend speed comparison, or new held-out generalization.",
                         "shared_metric_source_sha256": hashlib.sha256(Path(shared.__file__).read_bytes()).hexdigest()}
    return tables


def report_text(summary: dict) -> str:
    a = summary["accounting"]
    lines = ["# Two-checkpoint display-reversal replication", "",
             f"{a['scheduled_requests']} scheduled model requests reuse {a['unique_source_items']} source items "
             f"({a['model_item_pairs']} model-item pairs). {a['valid_requests']} valid requests; "
             f"{a['unavailable_scheduled_requests']} unavailable scheduled requests; {a['failure_records']} retained failure records.", "",
             "| Model | Dataset | Condition | Complete / eligible pairs | Semantic label flips | Mean absolute expected-score change |",
             "|---|---|---|---:|---:|---:|"]
    def fmt(value):
        return "—" if value is None else f"{value:.6f}"
    for model, result in summary["models"].items():
        for row in result["condition_differences"]:
            lines.append(f"| {model} | {row['dataset']} | {row['condition']} | {row['n_complete_pairs']} / {row['n_eligible_pairs']} | "
                         f"{row['label_flip_count']} ({fmt(row['label_flip_rate'])}) | {fmt(row.get('expected_score_absolute_delta_mean'))} |")
    lines += ["", "JSTS's primary outcome is the change in expected score on its unchanged0–5 scale. "
              "Hard-stage flips are a separate descriptive statistic. All paired distributions are aligned by semantic keys.", "",
              "The actual observation contract is Transformers forward calls with no generated tokens and no KV cache. "
              "No native llama_decode counters are inferred. The27 excluded warmup/parity forwards per checkpoint are separate from benchmark requests. "
              "A single exact-prompt repeat is a limited control; candidate probabilities are not calibrated correctness probabilities.", "",
              "These checkpoints share a model family and tokenizer. The repeated public-development sample is not a new held-out set, "
              "and its source groups remain dependent. No population significance, causal size effect, calibration, cross-backend latency advantage, "
              "or readout-specific failure mechanism is established. Detailed metrics, domain/group counts, failures and request accounting are in JSON/CSV.", ""]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--predictions", type=Path, required=True, help="JSONL file or directory containing model result directories")
    parser.add_argument("--schedule", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    files = sorted(args.predictions.glob("*/predictions.jsonl")) if args.predictions.is_dir() else [args.predictions]
    predictions = [row for path in files for row in read_records(path)]
    result = analyze(predictions, read_records(args.schedule))
    result["summary"]["input_files"] = {"predictions": {str(path.relative_to(args.predictions) if args.predictions.is_dir() else path.name): hashlib.sha256(path.read_bytes()).hexdigest() for path in files},
                                           "schedule_sha256": hashlib.sha256(args.schedule.read_bytes()).hexdigest(),
                                           "analyzer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "SUMMARY.json").write_text(json.dumps(result["summary"], ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    (args.output / "REPORT.md").write_text(report_text(result["summary"]), encoding="utf-8")
    for key, rows in result.items():
        if key != "summary":
            write_csv(args.output / (key + ".csv"), rows)
    print(json.dumps(result["summary"]["accounting"]))


if __name__ == "__main__":
    main()
