# Two-checkpoint display-reversal replication

This directory implements a separate prospective replication on the pinned local
Qwen2.5-0.5B-Instruct and Qwen2.5-1.5B-Instruct checkpoints. It reuses the exact
600 public-development items and filters the original frozen request schedule to
`baseline`, `baseline_repeat`, and `display_reverse`: **1,800 requests per model,
3,600 requests total**. The request count is not an independent-question count.
This code's existence does not imply that preparation, parity gates or measured
benchmark inference have passed; those require their saved receipts.

The checkpoints share tokenizer artifacts. Before any model load, preparation
compares all1,800 complete input token sequences and context-sensitive candidate
token IDs across both tokenizers. It preserves each original completed request's
hash. Prompt text and full input IDs remain private; only IDs, metadata, candidate
IDs, counts and hashes enter the public schedule.

The runtime uses offline pinned Transformers loading, MPS, float32, eager
attention, batch size1, frozen parameters and inference mode. A stock causal-LM
forward computes final-position logits with `logits_to_keep=1` and `use_cache=False`;
allowed candidate logits are gathered and normalized at T=1. No answer tokens are
generated. **Actual Transformers forward counters are recorded; native decode
counters are not invented.**

Each model first runs12 fixed synthetic parity fixtures: optimized final-position
logits versus full-position stock logits, using24 actual forwards. Every fixture
must meet the prospective logit tolerance (`atol=1e-3`, `rtol=1e-5`), probability
tolerance (`atol=1e-5`), and exact semantic argmax agreement. A failed gate blocks
benchmark execution. Three synthetic warmups follow a passed gate, leaving27
excluded forwards before the first benchmark request. These are implementation
checks, not accuracy filters or additional benchmark questions.

From the repository root, use the local Python environment containing the pinned
PyTorch/Transformers dependencies. The source questions file must stay outside
this repository. The following environment variables are placeholders for those
local paths, not files distributed here.
Use a new `JEV_REPLICATION` directory; the supplied `study_v1` records are the
completed historical experiment and must not be overwritten. Installed versions
and selected implementation hashes are in its `FREEZE.json`.

```bash
"$JEV_PYTHON" -m unittest discover -s paper/journal_robustness/cross_model -p 'test_*.py' -v

"$JEV_PYTHON" paper/journal_robustness/cross_model/run.py prepare \
  --questions "$JEV_PRIVATE_QUESTIONS" \
  --source-study paper/journal_robustness/study_v1 \
  --output "$JEV_REPLICATION"
```

`prepare` hashes both complete local weight snapshots and relevant installed
implementations, loads tokenizers only, and writes a new `FREEZE.json` and
`SCHEDULE.json`. It performs zero model forwards. If local artifacts, tokenization
or source hashes disagree, it fails instead of changing prompts or downloading
different files. Model artifacts and protocol remain unchanged after the freeze.

After the original native study completes and closes its engine, start the two
models serially. Omitting `--model-key` runs both in the fixed0.5B→1.5B order;
supplying it permits separate explicit starts. The second model requires the
first model's close receipt. An exclusive run lock also prevents overlapping
cross-model runs; do not run unrelated GPU workloads concurrently.

```bash
"$JEV_PYTHON" paper/journal_robustness/cross_model/run.py run \
  --questions "$JEV_PRIVATE_QUESTIONS" \
  --source-study paper/journal_robustness/study_v1 \
  --output "$JEV_REPLICATION"

"$JEV_PYTHON" paper/journal_robustness/cross_model/analyze.py \
  --predictions "$JEV_REPLICATION/results" \
  --schedule "$JEV_REPLICATION/SCHEDULE.json" \
  --output "$JEV_REPLICATION/analysis"
```

Freezes, model result directories, and analysis output directories refuse
overwrite. Each attempted benchmark request is retained. A failed benchmark
request stops that model's attempt without retries or replacements; its completion
receipt records actual forward totals and missing requests remain in analysis.
Error types are saved without arbitrary exception bodies that might contain
benchmark input. An interrupted run is not silently resumed.

The analyzer validates the actual Transformers fields and every frozen schedule
field before using the unchanged semantic metric functions from the original
frozen analyzer. Results remain separate by checkpoint and dataset, with JCoLA
domain splits and source group counts. Main outcomes are classification semantic
flip rates and JSTS absolute expected-score change on the0–5 scale. Baseline-repeat
controls, TV, normalized Jensen-Shannon divergence, exact ties, high maximum
candidate probability flips, descriptive gold metrics, failures and all scheduled
request statuses are retained. No calibration or confidence intervals are fitted.

This is a bounded replication on two related checkpoints and reused public dev
data. It cannot establish a causal model-size effect, fresh held-out generalization,
readout-specific instability, population significance or a fair cross-backend
latency advantage. The original35B native experiment differs in architecture,
model version, quantization and backend. Upstream dataset-derived metadata and
results retain the source licensing and attribution described in the repository;
project MIT licensing does not relicense those datasets.

## Runtime inventory scope

The execution manifest hashes 30 selected installed implementation files and
records package/Python/platform versions. It includes relevant Python modules,
PyTorch native libraries and tokenizer/safetensors extensions; it is **not** an
exhaustive inventory of every transitively imported framework module or operating
system component. Model weights and required checkpoint configuration/tokenizer
files are separately verified in full against fixed SHA-256 pins. Interpret the
runtime record as the explicitly listed environment evidence, not a proof of
complete environmental equivalence on another machine.
