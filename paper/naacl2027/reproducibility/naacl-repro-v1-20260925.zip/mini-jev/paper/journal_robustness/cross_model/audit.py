#!/usr/bin/env python3
"""Independent post-run record/tokenization/numerical audit; no model forwards.

Rehashes local pinned artifacts and loads tokenizers only. Full benchmark inputs
and token IDs stay in memory. --output is a new JSON file outside results/.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import math
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from paper.journal_robustness import audit as common
from paper.journal_robustness import conditions
from paper.journal_robustness.cross_model import analyze as analyzer
from paper.journal_robustness.cross_model import engine as adapter

canonical, sha, load, load_jsonl = common.canonical, common.sha, common.load, common.load_jsonl
equivalent, finite = common.equivalent, common.finite
MODELS = ("qwen2.5-0.5b", "qwen2.5-1.5b")
CONDITIONS = {"baseline", "baseline_repeat", "display_reverse"}
PROJECTION = "stock_causal_lm_last_position_full_vocab_then_candidate_gather"
OBSERVATION_FIELDS = {
    "backend", "batch_size", "candidate_boundary_verified", "candidate_ids", "concentration",
    "error", "forward_calls", "forward_calls_total", "grad_enabled", "inference_mode_enabled",
    "input_tokens", "label", "latency_ms", "logits", "logits_to_keep", "model_ms", "model_training",
    "output_tokens", "parameters_require_grad", "past_key_values_returned", "probabilities",
    "projection", "temperature", "tie_break", "top_logit_tie_count", "typed_value", "use_cache",
}
PRIVATE_FIELDS = common.FORBIDDEN_TEXT_FIELDS | {
    "input_ids", "attention_mask", "rendered_prompt", "prompt", "full_input_ids", "tokenized_input",
}
FORBIDDEN_NATIVE_FIELDS = {"native_decode_count", "native_total_decode_count", "state_cleared", "thinking_enabled"}


def private_fields(value):
    if isinstance(value, dict):
        return bool(set(value) & PRIVATE_FIELDS) or any(private_fields(v) for v in value.values())
    return isinstance(value, list) and any(private_fields(v) for v in value)


def vector_answer(logits, keys, kind):
    """Independent T=1 semantic decoding; no native or Transformers metadata added."""
    if not logits or len(logits) != len(keys) or any(not finite(v) for v in logits):
        raise ValueError("invalid_finite_vector")
    peak = max(logits)
    weights = [math.exp(value - peak) for value in logits]
    normalizer = math.fsum(weights)
    probabilities = {key: weight / normalizer for key, weight in zip(keys, weights)}
    first = max(range(len(logits)), key=logits.__getitem__)
    label = keys[first]
    value = (label if kind == "choice" else probabilities["true"] if kind == "noul"
             else math.fsum(float(key) * p for key, p in probabilities.items()))
    return {"probabilities": probabilities, "label": label, "typed_value": value,
            "top_logit_tie_count": sum(value == peak for value in logits),
            "concentration": max(0.0, min(1.0, 1 + math.fsum(
                p * math.log(p) for p in probabilities.values() if p > 0) / math.log(len(keys))))}


def independent_preparation(preparer, request, model_key):
    """Do not use adapter.prepare: reconstruct the complete assistant-boundary input."""
    tokenizer = preparer.tokenizer
    rendered = tokenizer.apply_chat_template(request["messages"], tokenize=False, add_generation_prompt=True)
    full = rendered + request.get("assistant_prefix", "")
    ids = tokenizer.encode(full, add_special_tokens=False)
    if not 1 <= len(ids) <= 2048:
        raise ValueError("invalid_untruncated_input_length")
    candidate_ids = []
    for candidate in request["candidates"]:
        isolated = tokenizer.encode(candidate, add_special_tokens=False)
        if len(isolated) != 1 or tokenizer.encode(full + candidate, add_special_tokens=False) != ids + isolated:
            raise ValueError("candidate_boundary_not_one_token")
        candidate_ids.append(isolated[0])
    if len(candidate_ids) != len(set(candidate_ids)):
        raise ValueError("duplicate_candidate_ids")
    prepared = {"model_key": model_key, "revision": adapter.MODEL_SPECS[model_key]["revision"],
                "input_ids": ids, "candidate_ids": candidate_ids,
                "candidate_tokens": list(request["candidates"]), "input_tokens": len(ids),
                "request_sha256": sha(canonical(request).encode()), "rendered_sha256": sha(full.encode()),
                "tokenized_input_sha256": sha(canonical(ids).encode()), "candidate_boundary_verified": True}
    prepared["prepared_integrity_sha256"] = sha(canonical(prepared).encode())
    return prepared


def source_files(questions, source_study):
    return {"cross_runner": HERE / "run.py", "cross_engine": HERE / "engine.py",
            "cross_analyzer": HERE / "analyze.py", "cross_protocol": HERE / "PROTOCOL.json",
            "cross_engine_tests": HERE / "test_engine.py", "cross_analysis_tests": HERE / "test_analysis.py",
            "v1_runner": HERE.parent / "run.py", "v1_conditions": HERE.parent / "conditions.py",
            "v1_analyzer": HERE.parent / "analyze.py", "v1_protocol": HERE.parent / "PROTOCOL.json",
            "v1_freeze": source_study / "FREEZE.json", "v1_schedule": source_study / "SCHEDULE.json",
            "native_formatter": ROOT / "native_engine.py", "source_questions": questions,
            "external_selection": ROOT / "paper/external_expanded/SELECTION.json",
            "external_protocol": ROOT / "paper/external_expanded/PROTOCOL.json"}


def audit(study, questions, source_study, analysis):
    study, questions, source_study, analysis = [Path(p).resolve() for p in (study, questions, source_study, analysis)]
    check = common.Audit()
    freeze = check.phase("load_cross_freeze", lambda: load(study / "FREEZE.json"))
    schedule = check.phase("load_cross_schedule", lambda: load(study / "SCHEDULE.json"))
    source_freeze = check.phase("load_v1_freeze", lambda: load(source_study / "FREEZE.json"))
    source_schedule = check.phase("load_v1_schedule", lambda: load(source_study / "SCHEDULE.json"))
    source_rows = check.phase("verify_600_original_source_rows", lambda: conditions.verify_source(questions))
    protocol = check.phase("load_protocol", lambda: load(HERE / "PROTOCOL.json"))
    summary = check.phase("load_cross_summary", lambda: load(analysis / "SUMMARY.json"))
    records = {}
    for model in MODELS:
        folder = study / "results" / model
        records[model] = {}
        for key, filename in {"attempt": "ATTEMPT.json", "runtime": "RUNTIME.json",
                              "completion": "COMPLETION.json", "gate": "PARITY_GATE.json",
                              "warmups": "warmup.jsonl", "predictions": "predictions.jsonl"}.items():
            reader = load_jsonl if filename.endswith("jsonl") else load
            records[model][key] = check.phase("load_" + model + "_" + key,
                                             lambda p=folder / filename, f=reader: f(p))
    prepared_by_model, preparers, chosen = {}, {}, []

    def source_checks():
        actual = {key: sha(path.read_bytes()) for key, path in source_files(questions, source_study).items()}
        check.check("all_16_frozen_source_hashes", actual == freeze["source_sha256"])
        for key, digest in actual.items():
            check.check("source_sha_" + key, freeze["source_sha256"].get(key) == digest)
        original = common.rebuild_schedule(source_rows)
        check.check("independent_original_4000_schedule", original == source_schedule
                    and sha(canonical(original).encode()) == source_freeze["schedule_sha256"]
                    and source_freeze["schedule_sha256"] == protocol["source"]["study_v1_schedule_sha256"])
        from paper.journal_robustness import run as original_runner
        check.check("original_freeze_sources_unchanged", original_runner.source_hashes(questions) == source_freeze["source_sha256"])
        by_item = {row["id"]: row for row in source_rows}
        for meta in original:
            if meta["condition"] not in CONDITIONS:
                continue
            request = next(v["request"] for v in conditions.variants(by_item[meta["item_id"]])
                           if v["condition"] == meta["condition"])
            if sha(canonical(request).encode()) != meta["request_sha256"]:
                raise ValueError("original_request_hash_mismatch")
            chosen.append((meta, request))
        check.check("1800_filtered_original_requests", len(chosen) == 1800
                    and Counter(meta["condition"] for meta, _ in chosen) == {condition: 600 for condition in CONDITIONS})
        check.check("cross_freeze_stage_and_budget", freeze["stage"] == "before_any_cross_model_forward"
                    and freeze["n_requests"] == 3600 and freeze["requests_per_model"] == 1800
                    and freeze["n_items"] == 600 and freeze["model_order"] == list(MODELS)
                    and freeze["model_loads_during_prepare"] == 0 and freeze["forward_calls_during_prepare"] == 0)
        check.check("cross_schedule_hash", sha(canonical(schedule).encode()) == freeze["schedule_sha256"])
        check.check("selected_installed_implementation_hashes", adapter.implementation_manifest() == freeze["implementation_manifest"])
        check.check("synthetic_fixture_and_warmup_hashes",
                    sha(canonical(adapter.synthetic_gate_requests()).encode()) == freeze["synthetic_gate_fixtures_sha256"]
                    and sha(canonical(original_runner.WARMUPS).encode()) == freeze["synthetic_warmups_sha256"])
        expected_schedule = []
        for model in MODELS:
            verified = adapter.verify_snapshot(model)
            check.check("fully_rehashed_pinned_artifacts_" + model, verified.manifest() == freeze["model_artifacts"][model])
            preparers[model] = adapter.TokenizerPreparer(verified)
            prepared_by_model[model] = [independent_preparation(preparers[model], request, model) for _, request in chosen]
            for index, ((meta, _), prepared) in enumerate(zip(chosen, prepared_by_model[model])):
                public = {key: value for key, value in prepared.items() if key != "input_ids"}
                expected_schedule.append({**meta, **public, "source_request_index": meta["request_index"],
                                          "model_request_index": index, "request_index": len(expected_schedule)})
        check.check("independent_3600_tokenized_schedule_exact", expected_schedule == schedule)
        check.check("all_1800_full_inputs_and_candidate_ids_identical", all(
            first["input_ids"] == second["input_ids"] and first["candidate_ids"] == second["candidate_ids"]
            for first, second in zip(prepared_by_model[MODELS[0]], prepared_by_model[MODELS[1]])))
        check.check("frozen_tokenization_gate_receipt", freeze["tokenization_gate"] == {
            "all_1800_full_input_sequences_identical": True, "all_candidate_ids_identical": True,
            "all_context_sensitive_single_token_candidates": True,
            "input_token_range": [min(row["input_tokens"] for row in expected_schedule),
                                  max(row["input_tokens"] for row in expected_schedule)]})
        check.check("unique_shared_600_items_1200_model_item_pairs", len(schedule) == 3600
                    and len({row["item_id"] for row in schedule}) == 600
                    and len({(row["model_key"], row["item_id"]) for row in schedule}) == 1200
                    and [row["request_index"] for row in schedule] == list(range(3600)))
        original_completion = load(source_study / "results/COMPLETION.json")
        check.check("native_study_completed_before_cross_model_start", original_completion["status"] == "completed"
                    and all(datetime.fromisoformat(original_completion["finished_at"]) <=
                            datetime.fromisoformat(records[m]["attempt"]["started_at"]) for m in MODELS))

    check.phase("source_artifact_and_tokenized_schedule_integrity", source_checks)

    def model_checks(model):
        record, spec = records[model], adapter.MODEL_SPECS[model]
        folder = study / "results" / model
        completion, runtime = record["completion"], record["runtime"]
        expected_artifact = freeze["model_artifacts"][model]
        check.check("runtime_pinned_artifacts_" + model, all(runtime.get(k) == v for k, v in expected_artifact.items()))
        expected_runtime = {"backend": "transformers", "device": "mps", "dtype": "float32",
                            "attention": "eager", "use_cache": False, "batch_size": 1, "logits_to_keep": 1,
                            "projection": PROJECTION, "engine_source_sha256": freeze["source_sha256"]["cross_engine"],
                            "torch_version": freeze["implementation_manifest"]["versions"]["torch"],
                            "transformers_version": freeze["implementation_manifest"]["versions"]["transformers"]}
        check.check("runtime_contract_" + model, all(runtime.get(k) == v for k, v in expected_runtime.items())
                    and runtime["revision"] == spec["revision"] and runtime["model_key"] == model)
        check.check("model_completion_success_" + model, completion["model_key"] == model
                    and completion["status"] == "completed" and completion["expected_requests"] == 1800
                    and completion["recorded_requests"] == 1800 and completion["failed_requests"] == 0
                    and completion["fatal_error_type"] is None and completion["parity_gate_passed"] is True
                    and completion["forward_calls_total_including_gate_and_warmup"] == 1827
                    and completion["model_closed_before_receipt"] is True and completion["source_unchanged"] is True)
        inventory = {path.name: sha(path.read_bytes()) for path in folder.glob("*.json*")
                     if path.is_file() and path.name != "COMPLETION.json"}
        check.check("completion_file_inventory_" + model, completion["file_sha256"] == inventory
                    and set(inventory) == {"ATTEMPT.json", "RUNTIME.json", "PARITY_GATE.json", "warmup.jsonl", "predictions.jsonl"})
        attempt = record["attempt"]
        check.check("attempt_freeze_and_timestamps_" + model,
                    attempt["freeze_sha256"] == sha((study / "FREEZE.json").read_bytes())
                    and attempt["status"] == "started_not_completed" and attempt["model_key"] == model
                    and attempt["expected_requests"] == 1800 and attempt["started_at"] == completion["started_at"]
                    and datetime.fromisoformat(freeze["created_at"]) <= datetime.fromisoformat(attempt["started_at"])
                    <= datetime.fromisoformat(completion["finished_at"]))
        if model == MODELS[1]:
            check.check("checkpoints_ran_serially", datetime.fromisoformat(records[MODELS[0]]["completion"]["finished_at"])
                        <= datetime.fromisoformat(attempt["started_at"]))

        gate = record["gate"]
        gate_config = protocol["implementation_gate"]
        check.check("gate_counts_and_fixed_thresholds_" + model, gate["passed"] is True
                    and gate["fixture_count"] == 12 and gate["forward_calls"] == gate["expected_forward_calls"] == 24
                    and len(gate["checks"]) == 12 and gate["exact_label_agreement_required"] is True
                    and gate["fixtures_sha256"] == freeze["synthetic_gate_fixtures_sha256"]
                    and (gate["logit_atol"], gate["logit_rtol"], gate["probability_atol"]) ==
                    (gate_config["logit_atol"], gate_config["logit_rtol"], gate_config["probability_atol"]) ==
                    (adapter.LOGIT_ATOL, adapter.LOGIT_RTOL, adapter.PROBABILITY_ATOL))
        for index, (fixture, observed) in enumerate(zip(adapter.synthetic_gate_requests(), gate["checks"])):
            prep = independent_preparation(preparers[model], fixture["request"], model)
            a = vector_answer(observed["optimized_logits"], fixture["keys"], fixture["type"])
            b = vector_answer(observed["full_position_logits"], fixture["keys"], fixture["type"])
            raw_a, raw_b = observed["optimized_logits"], observed["full_position_logits"]
            delta = max(abs(x-y) for x, y in zip(raw_a, raw_b))
            pdelta = max(abs(a["probabilities"][key]-b["probabilities"][key]) for key in fixture["keys"])
            genuine_pass = all(abs(x-y) <= gate["logit_atol"] + gate["logit_rtol"]*abs(y)
                               for x, y in zip(raw_a, raw_b)) and pdelta <= gate["probability_atol"] and a["label"] == b["label"]
            expected = {"fixture": fixture["fixture"], "input_tokens": prep["input_tokens"],
                        "request_sha256": prep["request_sha256"], "candidate_ids": prep["candidate_ids"],
                        "candidate_keys": fixture["keys"], "optimized_probabilities": a["probabilities"],
                        "full_position_probabilities": b["probabilities"], "optimized_top_logit_tie_count": a["top_logit_tie_count"],
                        "full_position_top_logit_tie_count": b["top_logit_tie_count"],
                        "optimized_label": a["label"], "full_position_label": b["label"],
                        "max_absolute_logit_difference": delta, "max_absolute_probability_difference": pdelta,
                        "labels_equal": a["label"] == b["label"], "passed": genuine_pass}
            check.check(f"independent_parity_{model}_{index}", genuine_pass
                        and all(equivalent(observed.get(key), value) for key, value in expected.items()))

        from paper.journal_robustness import run as original_runner
        check.check("three_warmup_records_" + model, len(record["warmups"]) == 3)
        for index, (warm, expected_q) in enumerate(zip(record["warmups"], original_runner.WARMUPS)):
            options = conditions.options_for(expected_q)
            request = conditions._request(expected_q, options)
            prep = independent_preparation(preparers[model], request, model)
            public = {key: value for key, value in prep.items() if key != "input_ids"}
            answer = warm["answer"]
            keys = [key for key, _ in options]
            recalculated = vector_answer(answer["logits"], keys, expected_q["type"])
            check.check(f"synthetic_warmup_{model}_{index}", set(warm) == {"index", "synthetic_question", "preparation", "answer"}
                        and warm["index"] == index and warm["synthetic_question"] == expected_q
                        and warm["preparation"] == public and set(answer) == OBSERVATION_FIELDS
                        and answer["forward_calls_total"] == index+25 and answer["forward_calls"] == 1
                        and answer["output_tokens"] == 0 and not (set(answer) & FORBIDDEN_NATIVE_FIELDS)
                        and all(equivalent(answer.get(k), v) for k, v in recalculated.items()))

        planned = [row for row in schedule if row["model_key"] == model]
        measured = record["predictions"]
        check.check("1800_benchmark_records_" + model, len(measured) == len(planned) == 1800)
        invalid_metadata, invalid_contract, invalid_vectors, invalid_ties, invalid_private = [], [], [], [], []
        for index, row in enumerate(measured):
            if index >= len(planned) or not isinstance(row, dict):
                invalid_metadata.append(index)
                continue
            meta = planned[index]
            if set(row) != set(meta) | OBSERVATION_FIELDS or any(row.get(k) != v for k, v in meta.items()):
                invalid_metadata.append(index)
                continue
            if (analyzer.validate_row(row) or row["error"] is not None or row["forward_calls_total"] != index+28
                    or row["forward_calls"] != 1 or row["output_tokens"] != 0):
                invalid_contract.append(index)
                continue
            calculated = vector_answer(row["logits"], row["candidate_keys"], row["type"])
            if not all(equivalent(row.get(k), v) for k, v in calculated.items()):
                invalid_vectors.append(index)
            if row["tie_break"] != "first_candidate_vector_index" or row["top_logit_tie_count"] != calculated["top_logit_tie_count"]:
                invalid_ties.append(index)
            if private_fields(row) or set(row) & FORBIDDEN_NATIVE_FIELDS:
                invalid_private.append(index)
        for name, indices in [("exact_scheduled_metadata", invalid_metadata), ("actual_forward_contract", invalid_contract),
                              ("independent_t1_semantic_decoding", invalid_vectors), ("exact_tie_information", invalid_ties),
                              ("no_private_or_native_fields", invalid_private)]:
            check.check(name + "_" + model, not indices, {"failed_model_request_indices": indices})
        check.check("conditions_and_dataset_counts_" + model,
                    Counter(row["condition"] for row in measured) == {condition: 600 for condition in CONDITIONS}
                    and Counter(row["dataset"] for row in measured) == {dataset: 600 for dataset in common.EXPECTED_GROUPS})
        for dataset, groups in common.EXPECTED_GROUPS.items():
            rows = [row for row in measured if row["dataset"] == dataset]
            check.check("source_items_and_groups_" + model + "_" + dataset,
                        len({row["item_id"] for row in rows}) == 200 and len({row["group"] for row in rows}) == groups)
        check.check("no_private_fields_in_model_public_receipts_" + model,
                    not any(private_fields(record[k]) for k in ("attempt", "runtime", "completion", "gate", "predictions")))

    for model in MODELS:
        check.phase("complete_model_integrity_" + model, lambda m=model: model_checks(m))

    def analysis_checks():
        global_accounting = {"scheduled_requests": 3600, "observed_prediction_rows": 3600, "unique_source_items": 600,
                             "model_item_pairs": 1200, "valid_requests": 3600, "unknown_model_prediction_rows": 0,
                             "failure_records": 0, "failure_code_counts": {}, "unavailable_scheduled_requests": 0}
        check.check("independent_global_accounting", equivalent(summary["accounting"], global_accounting))
        input_hashes = {"predictions": {f"{model}/predictions.jsonl": sha((study / "results" / model / "predictions.jsonl").read_bytes())
                                        for model in MODELS}, "schedule_sha256": sha((study / "SCHEDULE.json").read_bytes()),
                        "analyzer_sha256": sha((HERE / "analyze.py").read_bytes())}
        check.check("analysis_input_hashes", summary["input_files"] == input_hashes)
        check.check("shared_semantic_metric_source_hash", summary["shared_metric_source_sha256"] == freeze["source_sha256"]["v1_analyzer"])
        check.check("exact_two_model_summaries", set(summary["models"]) == set(MODELS))
        for model in MODELS:
            measured = records[model]["predictions"]
            reported = summary["models"][model]
            expected_accounting = {"schedule_supplied": True, "scheduled_requests": 1800,
                                  "observed_prediction_rows": 1800, "valid_requests": 1800,
                                  "unavailable_scheduled_requests": 0, "scheduled_status_counts": {"valid": 1800},
                                  "failure_records": 0, "failure_code_counts": {}, "unique_source_items": 600,
                                  "source_items_by_dataset": {dataset: 200 for dataset in common.EXPECTED_GROUPS},
                                  "observed_total_input_tokens": sum(row["input_tokens"] for row in measured),
                                  "observed_total_output_tokens": 0, "observed_forward_calls_total": 1800}
            check.check("independent_model_accounting_" + model, equivalent(reported["accounting"], expected_accounting))
            grouped, lookup = defaultdict(list), {}
            for row in measured:
                # Adapt only a recomputable semantic tie list for the pure metric
                # helper; no native observation fields are inserted or persisted.
                tied = [key for key, value in zip(row["candidate_keys"], row["logits"]) if value == max(row["logits"])]
                semantic = dict(row, exact_top_logit_tie_keys=tied)
                grouped[row["dataset"], row["condition"]].append(semantic)
                lookup[row["dataset"], row["item_id"], row["condition"]] = semantic
            table = {(row["dataset"], row["condition"]): row for row in reported["per_dataset"]}
            check.check("exact_nine_metric_rows_" + model, set(table) == set(grouped) and len(table) == len(reported["per_dataset"]) == 9)
            independent_gold = []
            for key, rows in sorted(grouped.items()):
                expected = common.independent_gold_metrics(rows)
                check.check("independent_gold_" + model + "_" + "_".join(key),
                            all(equivalent(table[key].get(field), value) for field, value in expected.items()))
                independent_gold.append({"dataset": key[0], "condition": key[1], **expected})
            comparison = {(row["dataset"], row["condition"]): row for row in reported["condition_differences"]}
            expected_keys = {(dataset, condition) for dataset in common.EXPECTED_GROUPS
                             for condition in ("display_reverse", "baseline_repeat")}
            check.check("exact_six_pair_rows_" + model, set(comparison) == expected_keys
                        and len(comparison) == len(reported["condition_differences"]) == 6)
            independent_pairs = []
            for dataset, condition in sorted(expected_keys):
                pairs = [(lookup[dataset, row["item_id"], "baseline"], row) for row in grouped[dataset, condition]]
                expected = common.independently_compare(pairs, dataset, condition)
                check.check("independent_pair_summary_" + model + "_" + dataset + "_" + condition,
                            equivalent(comparison[dataset, condition], expected))
                independent_pairs.append(expected)
            check.recomputed[model] = {"gold_metrics_all_conditions": independent_gold,
                                      "primary_and_repeat_comparisons": independent_pairs}
        check.check("no_private_fields_in_schedule_freeze_summary", not any(private_fields(v) for v in (schedule, freeze, summary)))
        paths = [study / "SCHEDULE.json"] + [study / "results" / model / "predictions.jsonl" for model in MODELS]
        paths += [p for p in analysis.iterdir() if p.is_file() and p.suffix in {".json", ".md", ".csv"}]
        public_text = "\n".join(p.read_text(encoding="utf-8") for p in paths)
        import json
        leaked = [i for i, source in enumerate(source_rows) if source["state"] in public_text
                  or json.dumps(source["state"], ensure_ascii=False)[1:-1] in public_text]
        check.check("no_complete_benchmark_state_text", not leaked, {"source_row_indices": leaked})

    check.phase("independent_cross_model_analysis_recomputation", analysis_checks)
    return {"schema_version": 1, "audit_created_at": datetime.now(timezone.utc).isoformat(),
            "passed": not check.failures, "checks_run": len(check.checks), "failed_check_count": len(check.failures),
            "checks": check.checks, "failures": check.failures, "independently_recomputed": check.recomputed,
            "audit_source_sha256": sha(Path(__file__).read_bytes()),
            "pure_metric_audit_dependency_sha256": sha(Path(common.__file__).read_bytes()),
            "scope": "Post-run audit of both complete checkpoints: independently reconstructed schedule and tokenization, fully rehashed pinned model/tokenizer files, selected installed implementation hashes, actual saved parity vectors, warmups/benchmark counters, metadata and independent semantic summaries. No model weights loaded and no forward calls.",
            "limitations": "Does not replay inference or validate scientific generalization/human wording equivalence. Installed implementation coverage is the frozen selection of files, not an exhaustive OS/framework proof. Full source text/input IDs remain in memory only."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, required=True)
    parser.add_argument("--questions", type=Path, required=True)
    parser.add_argument("--source-study", type=Path, required=True)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        parser.error("output must be a new file; preserve prior audit evidence")
    if output.is_relative_to((args.study / "results").resolve()):
        parser.error("audit output must remain outside frozen results inventories")
    report = audit(args.study, args.questions, args.source_study, args.analysis)
    output.parent.mkdir(parents=True, exist_ok=True)
    import json
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"passed": report["passed"], "checks_run": report["checks_run"],
                      "failed_check_count": report["failed_check_count"], "output": str(output)}))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
