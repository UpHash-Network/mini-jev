"""No-model tests of Transformers accounting, semantic metrics and run gates."""
from __future__ import annotations
import copy
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch, Mock

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from paper.journal_robustness.test_analysis import measurement as native_fixture
from paper.journal_robustness.cross_model import analyze, run


def row(index=0, model_key="qwen2.5-0.5b", **kwargs):
    value = native_fixture(index=index, **kwargs)
    for field in ("native_decode_count", "state_cleared", "thinking_enabled"):
        del value[field]
    value.update(model_key=model_key, revision=analyze.MODEL_REVISIONS[model_key],
                 model_request_index=index, source_request_index=index*2,
                 backend="transformers", forward_calls=1, forward_calls_total=index+28,
                 use_cache=False, model_training=False, grad_enabled=False,
                 parameters_require_grad=False, inference_mode_enabled=True,
                 batch_size=1, past_key_values_returned=False, model_ms=1.0,
                 projection="stock_causal_lm_last_position_full_vocab_then_candidate_gather",
                 logits_to_keep=1, candidate_boundary_verified=True,
                 candidate_ids=list(range(len(value["candidate_keys"]))),
                 tokenized_input_sha256="2"*64, rendered_sha256="3"*64)
    if model_key == "qwen2.5-1.5b":
        value["request_index"] += 1800
    return value


def schedule(rows):
    fields = ("request_index", "model_request_index", "source_request_index", "model_key", "revision",
              "item_id", "dataset", "type", "group", "split", "condition", "candidate_keys", "request_sha256",
              "gold_label", "gold_score", "score_values", "candidate_ids", "input_tokens",
              "tokenized_input_sha256", "rendered_sha256", "candidate_boundary_verified")
    return [{k: r[k] for k in fields if k in r} for r in rows]


class CrossModelAnalysisTests(unittest.TestCase):
    def test_real_transformers_contract_needs_no_native_fields(self):
        value = row()
        before = copy.deepcopy(value)
        self.assertEqual(analyze.validate_row(value), [])
        result = analyze.analyze([value], schedule([value]))
        self.assertEqual(result["summary"]["accounting"]["valid_requests"], 1)
        self.assertEqual(value, before)
        self.assertNotIn("native_decode_count", value)
        value["native_decode_count"] = 1
        self.assertIn("native_observation_fields_forbidden", analyze.validate_row(value))

    def test_actual_forward_contract_violations_rejected(self):
        for key, value, code in [
            ("forward_calls", 2, "forward_calls_must_be_one"),
            ("forward_calls_total", 1, "cumulative_forward_count_mismatch"),
            ("use_cache", True, "use_cache_must_be_false"),
            ("grad_enabled", True, "grad_must_be_disabled"),
            ("inference_mode_enabled", False, "inference_mode_must_be_enabled"),
            ("model_training", True, "model_must_be_eval"),
            ("parameters_require_grad", True, "parameter_grads_must_be_disabled"),
            ("backend", "llama.cpp", "backend_must_be_transformers"),
            ("past_key_values_returned", True, "past_key_values_must_not_be_returned"),
            ("candidate_boundary_verified", False, "candidate_boundary_must_be_verified"),
            ("batch_size", 2, "batch_size_must_be_one"),
            ("candidate_ids", [1, 1], "invalid_or_duplicate_candidate_ids"),
            ("model_ms", 5, "invalid_model_ms"),
            ("input_ids", [1, 2, 3], "private_input_fields_forbidden"),
            ("output_tokens", 1, "direct_readout_output_tokens_must_be_zero")]:
            measurement = row()
            measurement[key] = value
            self.assertIn(code, analyze.validate_row(measurement))

    def test_models_keep_separate_pair_metrics_and_one_shared_item_count(self):
        first = [row(), row(index=1, condition="display_reverse")]
        second = [row(model_key="qwen2.5-1.5b"), row(index=1, model_key="qwen2.5-1.5b", condition="display_reverse",
                   probabilities={"false": .9, "true": .1})]
        rows = first+second
        result = analyze.analyze(rows, schedule(rows))
        a = result["summary"]["accounting"]
        self.assertEqual(a["valid_requests"], 4)
        self.assertEqual(a["unique_source_items"], 1)
        self.assertEqual(a["model_item_pairs"], 2)
        first_comp = result["summary"]["models"]["qwen2.5-0.5b"]["condition_differences"][0]
        second_comp = result["summary"]["models"]["qwen2.5-1.5b"]["condition_differences"][0]
        self.assertEqual(first_comp["label_flip_count"], 0)
        self.assertEqual(second_comp["label_flip_count"], 1)
        self.assertNotIn("accuracy", a)

    def test_semantic_alignment_and_jsts_scale_reuse(self):
        probs = {str(i): .0 for i in range(6)}
        probs.update({"2": .75, "3": .25})
        first = row(dataset="JSTS", probabilities=probs)
        second = row(index=1, dataset="JSTS", probabilities=probs,
                     keys=list(reversed(list(probs))), condition="display_reverse")
        result = analyze.analyze([first, second], schedule([first, second]))
        pair = result["paired_differences"][0]
        self.assertEqual(pair["total_variation"], 0)
        self.assertEqual(pair["expected_score_absolute_delta"], 0)
        metric = result["summary"]["models"]["qwen2.5-0.5b"]["per_dataset"][0]
        self.assertAlmostEqual(metric["expected_score_mae"], .45)
        self.assertAlmostEqual(metric["hard_label_mae"], .7)
        self.assertNotIn("accuracy", metric)

    def test_missing_failed_duplicates_and_unknown_models_accounted(self):
        first = row()
        failed = row(index=1, condition="display_reverse")
        missing = row(index=2, condition="baseline_repeat")
        failed["error"] = "Do not repeat PRIVATE INPUT TEXT"
        unknown = copy.deepcopy(first)
        unknown["model_key"] = "unexpected"
        result = analyze.analyze([first, copy.deepcopy(first), failed, unknown], schedule([first, failed, missing]))
        a = result["summary"]["accounting"]
        self.assertEqual(a["scheduled_requests"], 3)
        self.assertEqual(a["observed_prediction_rows"], 4)
        self.assertEqual(a["valid_requests"], 0)
        self.assertEqual(a["unknown_model_prediction_rows"], 1)
        self.assertEqual(a["failure_code_counts"]["missing_prediction"], 1)
        self.assertEqual(a["failure_code_counts"]["duplicate_request_index"], 1)
        self.assertNotIn("PRIVATE INPUT TEXT", str(result))

    def test_tokenization_metadata_must_match_frozen_schedule(self):
        measurement = row()
        planned = schedule([measurement])
        measurement["tokenized_input_sha256"] = "4"*64
        result = analyze.analyze([measurement], planned)
        self.assertEqual(result["summary"]["accounting"]["valid_requests"], 0)
        self.assertEqual(result["summary"]["accounting"]["failure_code_counts"]["schedule_metadata_mismatch"], 1)

    def test_duplicate_target_file_cannot_be_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/"FREEZE.json"
            run.write_new(path, {"original": True})
            with self.assertRaises(FileExistsError):
                run.write_new(path, {"replacement": True})
            self.assertIn('"original": true', path.read_text())

    def test_preparation_compares_entire_input_ids_without_model_load(self):
        requests = [({"request_index": 0, "request_sha256": "0"*64}, {"synthetic": True})]
        class Preparer:
            def __init__(self, verified):
                self.verified = verified
            def prepare(self, _):
                return {"model_key": self.verified.model_key, "input_ids": [1, 2 if self.verified.model_key == run.MODELS[0] else 3],
                        "candidate_ids": [4, 5], "request_sha256": "0"*64, "rendered_sha256": "0"*64,
                        "tokenized_input_sha256": "0"*64, "candidate_tokens": ["A", "B"], "input_tokens": 2}
        def verified(key, _):
            return SimpleNamespace(model_key=key, manifest=lambda: {})
        with patch.object(run, "selected_requests", return_value=requests), \
             patch.object(run.adapter, "verify_snapshot", side_effect=verified), \
             patch.object(run.adapter, "TokenizerPreparer", Preparer), \
             patch.object(run.adapter, "TransformersResearchEngine") as model:
            with self.assertRaisesRegex(ValueError, "complete input"):
                run.preparation_material(Path("private"), Path("source"), Path("cache"))
            model.assert_not_called()

    def test_failed_parity_gate_prevents_all_benchmark_requests(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root/"FREEZE.json").write_text("{}")
            args = SimpleNamespace(output=root, questions=root/"private", source_study=root/"v1")
            engine = SimpleNamespace(runtime_metadata={"synthetic": True}, forward_calls=24, closed=False,
                                     evaluate_request=Mock())
            engine.close = lambda: setattr(engine, "closed", True)
            gate = {"passed": False, "fixture_count": 12, "forward_calls": 24}
            with patch.object(run, "assert_sources"), patch.object(run, "source_hashes", return_value={}), \
                 patch.object(run.adapter, "TransformersResearchEngine", return_value=engine), \
                 patch.object(run.adapter, "validate_forward_parity", return_value=gate):
                with self.assertRaisesRegex(RuntimeError, "parity gate failed"):
                    run.run_one(args, run.MODELS[0], {"source_sha256": {}}, [], None, [])
            engine.evaluate_request.assert_not_called()
            self.assertTrue(engine.closed)
            self.assertTrue((root/"results"/run.MODELS[0]/"COMPLETION.json").exists())
            self.assertFalse((root/"results"/run.MODELS[0]/"predictions.jsonl").exists())


if __name__ == "__main__":
    unittest.main()
