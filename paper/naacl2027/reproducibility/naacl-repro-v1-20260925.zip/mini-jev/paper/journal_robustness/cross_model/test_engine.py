"""Contract tests without loading any real model, downloading, or GPU inference."""
from copy import deepcopy
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from paper.journal_robustness.cross_model.engine import (
    MODEL_SPECS, MAX_INPUT_TOKENS, LOGIT_ATOL, LOGIT_RTOL, PROBABILITY_ATOL,
    TokenizerPreparer, TransformersResearchEngine, VerifiedSnapshot,
    _prepare_with_tokenizer, _verify_file, candidate_answer, canonical,
    sha, synthetic_gate_requests, validate_forward_parity,
)


def request():
    return {"messages": [{"role": "system", "content": "S"}, {"role": "user", "content": "U"}],
            "candidates": ["0", "1"], "assistant_prefix": '{"answer":', "max_input_tokens": 2048}


class CharacterTokenizer:
    """Tiny non-model fixture with independently inspectable token boundaries."""
    def apply_chat_template(self, messages, *, tokenize, add_generation_prompt):
        assert tokenize is False and add_generation_prompt is True
        return "".join(m["role"]+":"+m["content"]+"\n" for m in messages)+"assistant\n"

    def encode(self, text, *, add_special_tokens):
        assert add_special_tokens is False
        return [ord(c) for c in text]


class FakePreparer:
    def prepare(self, req):
        return _prepare_with_tokenizer(CharacterTokenizer(), req, "test", "revision")


class FakeGateEngine:
    def __init__(self, corrupt=False):
        self.preparer, self.corrupt = FakePreparer(), corrupt
        self.calls = []
        self.forward_calls = 0
        self._gate_passed = False

    def _forward(self, prepared, keep):
        self.calls.append(keep)
        self.forward_calls += 1
        logits = [float(i) for i in range(len(prepared["candidate_ids"]))]
        if self.corrupt and keep == 1:
            logits[0] += 100
        return logits, 0.1


class CrossModelEngineTest(unittest.TestCase):
    def test_exact_text_and_actual_json_prefix_boundary(self):
        req = request()
        before = deepcopy(req)
        p = _prepare_with_tokenizer(CharacterTokenizer(), req, "test", "r")
        expected = 'system:S\nuser:U\nassistant\n{"answer":'
        self.assertEqual(p["input_ids"], [ord(c) for c in expected])
        self.assertEqual(p["candidate_ids"], [ord("0"), ord("1")])
        self.assertEqual(p["rendered_sha256"], sha(expected.encode()))
        self.assertEqual(p["request_sha256"], sha(canonical(req).encode()))
        self.assertEqual(req, before)

    def test_prompt_boundary_retokenization_is_rejected(self):
        class MergeTokenizer(CharacterTokenizer):
            def encode(self, text, *, add_special_tokens):
                ids = super().encode(text, add_special_tokens=add_special_tokens)
                return ids[:-2]+[999] if text.endswith(":0") else ids
        with self.assertRaisesRegex(ValueError, "actual assistant boundary"):
            _prepare_with_tokenizer(MergeTokenizer(), request(), "test", "r")

    def test_isolated_multitoken_candidate_is_rejected(self):
        req = request(); req["candidates"] = ["word", "1"]
        with self.assertRaisesRegex(ValueError, "isolated token"):
            _prepare_with_tokenizer(CharacterTokenizer(), req, "test", "r")

    def test_no_silent_truncation_and_wrong_context_limit(self):
        req = request(); req["messages"][1]["content"] = "x" * MAX_INPUT_TOKENS
        with self.assertRaisesRegex(ValueError, "no truncation"):
            _prepare_with_tokenizer(CharacterTokenizer(), req, "test", "r")
        req = request(); req["max_input_tokens"] = 8192
        with self.assertRaises(ValueError):
            _prepare_with_tokenizer(CharacterTokenizer(), req, "test", "r")

    def test_duplicate_and_malformed_candidates_fail(self):
        for values in [["0", "0"], ["0", {}], ["0"]]:
            req = request(); req["candidates"] = values
            with self.assertRaises(ValueError):
                _prepare_with_tokenizer(CharacterTokenizer(), req, "test", "r")

    def test_public_metadata_has_no_reconstructible_input_ids(self):
        p = _prepare_with_tokenizer(CharacterTokenizer(), request(), "test", "r")
        public = TokenizerPreparer.public_metadata(p)
        self.assertNotIn("input_ids", public)
        self.assertNotIn("messages", public)
        self.assertIn("prepared_integrity_sha256", public)
        self.assertEqual(p["prepared_integrity_sha256"], sha(canonical({k: v for k, v in p.items() if k != "prepared_integrity_sha256"}).encode()))

    def test_canonical_mapping_and_numeric_expectation(self):
        a = candidate_answer([0.0, 2.0], ["true", "false"], "noul")
        self.assertEqual(a["label"], "false")
        self.assertAlmostEqual(a["typed_value"], 1/(1+2.718281828459045**2))
        b = candidate_answer([0.0, 0.0, 0.0], ["2", "0", "1"], "score")
        self.assertEqual(b["typed_value"], 1.0)
        self.assertEqual(b["label"], "2")
        self.assertEqual(b["top_logit_tie_count"], 3)

    def test_nonfinite_and_invalid_semantics_rejected(self):
        for args in [([float("nan"), 0], ["a", "b"], "choice"),
                     ([0, 0], ["yes", "no"], "noul"), ([0, 0], ["1", "2"], "score")]:
            with self.assertRaises(ValueError):
                candidate_answer(*args)

    def test_file_verification_and_stat_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/"weights"; p.write_bytes(b"abc")
            identity = _verify_file(p, 3, hashlib.sha256(b"abc").hexdigest())
            snapshot = VerifiedSnapshot("qwen2.5-0.5b", Path(tmp), {"weights": identity})
            snapshot.assert_unchanged()
            p.write_bytes(b"abd")
            with self.assertRaisesRegex(ValueError, "changed"):
                snapshot.assert_unchanged()
            with self.assertRaisesRegex(ValueError, "hash mismatch"):
                _verify_file(p, 3, hashlib.sha256(b"abc").hexdigest())

    def test_frozen_model_pair_has_identical_tokenizer_pins(self):
        a, b = MODEL_SPECS.values()
        for name in ["tokenizer.json", "tokenizer_config.json", "vocab.json", "merges.txt"]:
            self.assertEqual(a["files"][name], b["files"][name])
        self.assertNotEqual(a["files"]["model.safetensors"], b["files"]["model.safetensors"])

    def test_fixed_synthetic_gate_budget_and_thresholds(self):
        fixtures = synthetic_gate_requests()
        self.assertEqual(len(fixtures), 12)
        self.assertEqual({f["type"]: sum(x["type"] == f["type"] for x in fixtures) for f in fixtures},
                         {"choice": 4, "noul": 4, "score": 4})
        self.assertEqual((LOGIT_ATOL, LOGIT_RTOL, PROBABILITY_ATOL), (1e-3, 1e-5, 1e-5))
        engine = FakeGateEngine()
        result = validate_forward_parity(engine)
        self.assertTrue(result["passed"])
        self.assertEqual(engine.calls, [1, 0]*12)
        self.assertEqual(result["forward_calls"], 24)
        self.assertIn("optimized_logits", result["checks"][0])
        self.assertIn("full_position_probabilities", result["checks"][0])

    def test_failed_gate_is_preserved_and_blocks_measurement(self):
        fake = FakeGateEngine(corrupt=True)
        result = validate_forward_parity(fake)
        self.assertFalse(result["passed"])
        self.assertEqual(len(result["checks"]), 12)
        instance = object.__new__(TransformersResearchEngine)
        instance._gate_passed = False
        with self.assertRaisesRegex(RuntimeError, "gate has not passed"):
            instance.evaluate_request({}, [], "choice")


if __name__ == "__main__":
    unittest.main()
