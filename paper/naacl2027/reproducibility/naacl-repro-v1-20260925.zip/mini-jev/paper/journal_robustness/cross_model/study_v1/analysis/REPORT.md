# Two-checkpoint display-reversal replication

3600 scheduled model requests reuse 600 source items (1200 model-item pairs). 3600 valid requests; 0 unavailable scheduled requests; 0 retained failure records.

| Model | Dataset | Condition | Complete / eligible pairs | Semantic label flips | Mean absolute expected-score change |
|---|---|---|---:|---:|---:|
| qwen2.5-0.5b | JCoLA | baseline_repeat | 200 / 200 | 0 (0.000000) | — |
| qwen2.5-0.5b | JCoLA | display_reverse | 200 / 200 | 199 (0.995000) | — |
| qwen2.5-0.5b | JCommonsenseQA | baseline_repeat | 200 / 200 | 0 (0.000000) | — |
| qwen2.5-0.5b | JCommonsenseQA | display_reverse | 200 / 200 | 133 (0.665000) | — |
| qwen2.5-0.5b | JSTS | baseline_repeat | 200 / 200 | 0 (0.000000) | 0.000000 |
| qwen2.5-0.5b | JSTS | display_reverse | 200 / 200 | 195 (0.975000) | 1.430940 |
| qwen2.5-1.5b | JCoLA | baseline_repeat | 200 / 200 | 0 (0.000000) | — |
| qwen2.5-1.5b | JCoLA | display_reverse | 200 / 200 | 0 (0.000000) | — |
| qwen2.5-1.5b | JCommonsenseQA | baseline_repeat | 200 / 200 | 0 (0.000000) | — |
| qwen2.5-1.5b | JCommonsenseQA | display_reverse | 200 / 200 | 43 (0.215000) | — |
| qwen2.5-1.5b | JSTS | baseline_repeat | 200 / 200 | 0 (0.000000) | 0.000000 |
| qwen2.5-1.5b | JSTS | display_reverse | 200 / 200 | 10 (0.050000) | 0.101733 |

JSTS's primary outcome is the change in expected score on its unchanged0–5 scale. Hard-stage flips are a separate descriptive statistic. All paired distributions are aligned by semantic keys.

The actual observation contract is Transformers forward calls with no generated tokens and no KV cache. No native llama_decode counters are inferred. The27 excluded warmup/parity forwards per checkpoint are separate from benchmark requests. A single exact-prompt repeat is a limited control; candidate probabilities are not calibrated correctness probabilities.

These checkpoints share a model family and tokenizer. The repeated public-development sample is not a new held-out set, and its source groups remain dependent. No population significance, causal size effect, calibration, cross-backend latency advantage, or readout-specific failure mechanism is established. Detailed metrics, domain/group counts, failures and request accounting are in JSON/CSV.
