#!/usr/bin/env python3
"""Prepare without model loads, then explicitly run serial pinned replications.

Benchmark text/input IDs stay in memory and outside public result files. The
prepare action hashes local weights and tokenizes every request but performs no
model forwards. Existing freezes and result directories are never overwritten.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import fcntl
import hashlib
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from paper.journal_robustness import run as source_run
from paper.journal_robustness import conditions as source_conditions
from paper.journal_robustness.cross_model import engine as adapter
from native_engine import options_for

MODELS = ("qwen2.5-0.5b", "qwen2.5-1.5b")
CONDITIONS = {"baseline", "baseline_repeat", "display_reverse"}


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def protocol():
    value = json.loads((HERE / "PROTOCOL.json").read_text())
    gate = value["implementation_gate"]
    if (gate["logit_atol"], gate["logit_rtol"], gate["probability_atol"]) != (adapter.LOGIT_ATOL, adapter.LOGIT_RTOL, adapter.PROBABILITY_ATOL):
        raise ValueError("Adapter and frozen protocol tolerances differ")
    for model in value["models"]:
        spec = adapter.MODEL_SPECS[model["model_key"]]
        if model["id"] != spec["repo_id"] or model["revision"] != spec["revision"]:
            raise ValueError("Model pin differs between protocol and adapter")
    return value


def source_hashes(questions, source_study):
    paths = {"cross_runner": Path(__file__), "cross_engine": HERE / "engine.py",
             "cross_analyzer": HERE / "analyze.py", "cross_protocol": HERE / "PROTOCOL.json",
             "cross_engine_tests": HERE / "test_engine.py", "cross_analysis_tests": HERE / "test_analysis.py",
             "v1_runner": Path(source_run.__file__), "v1_conditions": Path(source_conditions.__file__),
             "v1_analyzer": HERE.parent / "analyze.py", "v1_protocol": HERE.parent / "PROTOCOL.json",
             "v1_freeze": source_study / "FREEZE.json", "v1_schedule": source_study / "SCHEDULE.json",
             "native_formatter": ROOT / "native_engine.py", "source_questions": questions,
             "external_selection": ROOT / "paper/external_expanded/SELECTION.json",
             "external_protocol": ROOT / "paper/external_expanded/PROTOCOL.json"}
    return {key: sha(path.read_bytes()) for key, path in paths.items()}


def selected_requests(questions, source_study):
    frozen = json.loads((source_study / "FREEZE.json").read_text())
    stored = json.loads((source_study / "SCHEDULE.json").read_text())
    schedule, requests = source_run.build_schedule(questions)
    if stored != schedule or sha(canonical(schedule).encode()) != frozen["schedule_sha256"]:
        raise ValueError("Source study schedule cannot be reconstructed exactly")
    if frozen["schedule_sha256"] != protocol()["source"]["study_v1_schedule_sha256"]:
        raise ValueError("Source schedule differs from prospective protocol")
    if source_run.source_hashes(questions) != frozen["source_sha256"]:
        raise ValueError("Source study files no longer match their original freeze")
    chosen = [(meta, request) for meta, request in zip(schedule, requests) if meta["condition"] in CONDITIONS]
    if len(chosen) != 1800 or Counter(m["condition"] for m, _ in chosen) != {key: 600 for key in CONDITIONS}:
        raise ValueError("Unexpected filtered source count")
    if len({(m["dataset"], m["item_id"]) for m, _ in chosen}) != 600:
        raise ValueError("Unexpected source item count")
    for meta, request in chosen:
        if sha(canonical(request).encode()) != meta["request_sha256"]:
            raise ValueError("Source request hash mismatch")
    return chosen


def preparation_material(questions, source_study, cache_root):
    """No engine construction and no model forward occurs on this path."""
    chosen = selected_requests(questions, source_study)
    preparers, prepared_by_model, manifests = {}, {}, {}
    for model_key in MODELS:
        verified = adapter.verify_snapshot(model_key, cache_root)
        preparer = adapter.TokenizerPreparer(verified)
        preparers[model_key] = preparer
        prepared_by_model[model_key] = [preparer.prepare(request) for _, request in chosen]
        manifests[model_key] = verified.manifest()
    for first, second in zip(*(prepared_by_model[key] for key in MODELS)):
        if first["input_ids"] != second["input_ids"] or first["candidate_ids"] != second["candidate_ids"]:
            raise ValueError("Checkpoint tokenizers disagree on complete input or candidate IDs")
        for key in ("request_sha256", "rendered_sha256", "tokenized_input_sha256", "candidate_tokens", "input_tokens"):
            if first[key] != second[key]:
                raise ValueError("Checkpoint tokenization metadata mismatch: " + key)
    schedule = []
    for model_key in MODELS:
        for model_index, ((meta, _), prepared) in enumerate(zip(chosen, prepared_by_model[model_key])):
            if prepared["request_sha256"] != meta["request_sha256"]:
                raise ValueError("Adapter changed the original completed request")
            record = {**meta, **preparers[model_key].public_metadata(prepared),
                      "source_request_index": meta["request_index"],
                      "model_request_index": model_index, "request_index": len(schedule)}
            if "input_ids" in record or "messages" in record:
                raise ValueError("Private benchmark input entered public metadata")
            schedule.append(record)
    return schedule, preparers, prepared_by_model, manifests


def prepare(args):
    protocol()
    before = source_hashes(args.questions, args.source_study)
    schedule, _, _, artifacts = preparation_material(args.questions, args.source_study, args.cache_root)
    implementations = adapter.implementation_manifest()
    if before != source_hashes(args.questions, args.source_study):
        raise ValueError("Study source changed during preparation")
    args.output.mkdir(parents=True, exist_ok=False)
    manifest = {"schema_version": 1, "stage": "before_any_cross_model_forward", "created_at": now(),
                "source_sha256": before, "model_artifacts": artifacts, "implementation_manifest": implementations,
                "schedule_sha256": sha(canonical(schedule).encode()), "n_requests": len(schedule),
                "n_items": 600, "requests_per_model": 1800, "model_order": list(MODELS),
                "tokenization_gate": {"all_1800_full_input_sequences_identical": True,
                                      "all_candidate_ids_identical": True,
                                      "all_context_sensitive_single_token_candidates": True,
                                      "input_token_range": [min(r["input_tokens"] for r in schedule), max(r["input_tokens"] for r in schedule)]},
                "synthetic_gate_fixtures_sha256": sha(canonical(adapter.synthetic_gate_requests()).encode()),
                "synthetic_warmups_sha256": sha(canonical(source_run.WARMUPS).encode()),
                "model_loads_during_prepare": 0, "forward_calls_during_prepare": 0,
                "registration": "Local timestamped freeze, not independent public preregistration",
                "source_text_and_full_input_ids_public": False}
    write_new(args.output / "SCHEDULE.json", schedule)
    write_new(args.output / "FREEZE.json", manifest)
    print(canonical({"prepared": len(schedule), "items": 600, "forward_calls": 0,
                     "freeze_sha256": sha((args.output / "FREEZE.json").read_bytes())}), flush=True)


def assert_sources(args, freeze):
    if source_hashes(args.questions, args.source_study) != freeze["source_sha256"]:
        raise ValueError("Frozen cross-model study source changed")
    if adapter.implementation_manifest() != freeze["implementation_manifest"]:
        raise ValueError("Installed runtime implementation changed after freeze")


def run_one(args, model_key, freeze, schedule, preparer, prepared):
    results = args.output / "results" / model_key
    results.mkdir(parents=True, exist_ok=False)
    started = now()
    write_new(results / "ATTEMPT.json", {"started_at": started, "model_key": model_key,
              "status": "started_not_completed", "expected_requests": 1800,
              "freeze_sha256": sha((args.output / "FREEZE.json").read_bytes())})
    engine, completed, failed, fatal, gate_passed = None, 0, 0, None, False
    try:
        assert_sources(args, freeze)
        engine = adapter.TransformersResearchEngine(preparer, device="mps")
        write_new(results / "RUNTIME.json", engine.runtime_metadata)
        assert_sources(args, freeze)
        gate = adapter.validate_forward_parity(engine)
        write_new(results / "PARITY_GATE.json", gate)
        if gate.get("passed") is not True or gate.get("fixture_count") != 12 or gate.get("forward_calls") != 24:
            raise RuntimeError("Fixed synthetic implementation parity gate failed; benchmark not started")
        gate_passed = True
        with (results / "warmup.jsonl").open("x", encoding="utf-8") as stream:
            for index, question in enumerate(source_run.WARMUPS):
                request = source_conditions._request(question, options_for(question))
                p = preparer.prepare(request)
                answer = engine.evaluate_request(p, [key for key, _ in options_for(question)], question["type"])
                stream.write(canonical({"index": index, "synthetic_question": question,
                                        "preparation": preparer.public_metadata(p), "answer": answer}) + "\n")
                stream.flush()
        if engine.forward_calls != 27:
            raise RuntimeError("Unexpected actual warmup/parity forward count")
        assert_sources(args, freeze)
        beginning = time.perf_counter()
        with (results / "predictions.jsonl").open("x", encoding="utf-8") as stream:
            for meta, p in zip(schedule, prepared):
                row = dict(meta)
                try:
                    row.update(engine.evaluate_request(p, meta["candidate_keys"], meta["type"]))
                except Exception as error:
                    # Error bodies can contain benchmark text or input IDs.
                    row["error"] = type(error).__name__
                    failed += 1
                stream.write(canonical(row) + "\n")
                stream.flush()
                completed += 1
                if row.get("error"):
                    raise RuntimeError("Benchmark request failed; partial attempt retained without retry")
                if completed % 100 == 0 or completed == len(schedule):
                    print(canonical({"model_key": model_key, "completed": completed, "total": len(schedule),
                                     "errors": failed, "elapsed_s": round(time.perf_counter()-beginning, 1)}), flush=True)
                    assert_sources(args, freeze)
    except BaseException as error:
        fatal = type(error).__name__
        raise
    finally:
        actual_forwards = engine.forward_calls if engine is not None else 0
        if engine is not None:
            engine.close()
        hashes = {p.name: sha(p.read_bytes()) for p in results.glob("*.json*") if p.is_file()}
        write_new(results / "COMPLETION.json", {"model_key": model_key,
                  "status": "completed" if completed == 1800 and not fatal else "incomplete",
                  "started_at": started, "finished_at": now(), "expected_requests": 1800,
                  "recorded_requests": completed, "failed_requests": failed, "fatal_error_type": fatal,
                  "parity_gate_passed": gate_passed, "forward_calls_total_including_gate_and_warmup": actual_forwards,
                  "model_closed_before_receipt": engine is None or engine.closed,
                  "file_sha256": hashes, "source_unchanged": source_hashes(args.questions, args.source_study) == freeze["source_sha256"],
                  "failure_policy": "No replacement, retry, overwrite, outcome selection or implicit resume."})


def run(args):
    # This receipt is written by v1 only after its engine.close() has returned.
    source_completion = json.loads((args.source_study / "results/COMPLETION.json").read_text())
    if source_completion.get("status") != "completed":
        raise ValueError("The original native study must finish before cross-model loading")
    freeze = json.loads((args.output / "FREEZE.json").read_text())
    assert_sources(args, freeze)
    with (args.output / "RUN.lock").open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        schedule, preparers, prepared, artifacts = preparation_material(args.questions, args.source_study, args.cache_root)
        if artifacts != freeze["model_artifacts"] or sha(canonical(schedule).encode()) != freeze["schedule_sha256"]:
            raise ValueError("Artifact manifest or tokenized schedule differs from freeze")
        if schedule != json.loads((args.output / "SCHEDULE.json").read_text()):
            raise ValueError("Stored cross-model schedule differs from reconstruction")
        selected = (args.model_key,) if args.model_key else MODELS
        for model_key in selected:
            if model_key == MODELS[1]:
                previous = args.output / "results" / MODELS[0] / "COMPLETION.json"
                if not previous.exists():
                    raise ValueError("Run the first model and close it before starting the second model")
                receipt = json.loads(previous.read_text())
                if receipt.get("model_key") != MODELS[0] or receipt.get("model_closed_before_receipt") is not True:
                    raise ValueError("The first model lacks a verified close receipt")
            model_schedule = [r for r in schedule if r["model_key"] == model_key]
            run_one(args, model_key, freeze, model_schedule, preparers[model_key], prepared[model_key])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "run"))
    parser.add_argument("--questions", type=Path, required=True, help="Private verified600-item JSONL outside this repository")
    parser.add_argument("--source-study", type=Path, default=HERE.parent / "study_v1")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cache-root", type=Path, default=adapter.DEFAULT_CACHE_ROOT)
    parser.add_argument("--model-key", choices=MODELS, help="Explicit single-model run; omitted runs both in fixed serial order")
    args = parser.parse_args()
    (prepare if args.action == "prepare" else run)(args)


if __name__ == "__main__":
    main()
