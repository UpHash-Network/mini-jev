#!/usr/bin/env python3
"""Audit and summarize paired candidate-presentation experiments (standard library).

Probabilities are aligned by canonical semantic keys, never by token position.
Inputs contain IDs and measurements only. The analyzer does not fit calibration,
select by correctness, pool classification/regression accuracy, or treat repeated
requests as independent questions. Missing and invalid requests remain accounted.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

TOL = 1e-6
HIGH_MAX_PROBABILITY = 0.9
IDENTITY_FIELDS = ("item_id", "dataset", "type", "group", "split", "condition")


def finite(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def logical_key(row: dict) -> tuple:
    return (row.get("dataset"), row.get("item_id"), row.get("condition"))


def item_key(row: dict) -> tuple:
    return (row.get("dataset"), row.get("item_id"))


def softmax(logits: list[float]) -> list[float]:
    peak = max(logits)
    exps = [math.exp(x - peak) for x in logits]
    return [x / sum(exps) for x in exps]


def distribution(values: list[float]) -> dict:
    if not values:
        return {key: None for key in ("mean", "median", "p95", "min", "max")}
    ordered = sorted(values)
    pos = (len(ordered) - 1) * 0.95
    lo, hi = math.floor(pos), math.ceil(pos)
    return {"mean": statistics.mean(values), "median": statistics.median(values),
            "p95": ordered[lo] + (pos - lo) * (ordered[hi] - ordered[lo]),
            "min": min(values), "max": max(values)}


def divergences(p: dict[str, float], q: dict[str, float]) -> tuple[float, float]:
    """Total variation and Jensen-Shannon divergence / ln(2), both in [0, 1]."""
    if set(p) != set(q):
        raise ValueError("canonical_candidate_set_mismatch")
    tv = sum(abs(p[k] - q[k]) for k in p) / 2
    js = 0.0
    for key in p:
        mid = (p[key] + q[key]) / 2
        if p[key] > 0:
            js += 0.5 * p[key] * math.log(p[key] / mid)
        if q[key] > 0:
            js += 0.5 * q[key] * math.log(q[key] / mid)
    return tv, max(0.0, min(1.0, js / math.log(2)))


def expected_score(row: dict) -> float:
    return sum(row["probabilities"][key] * row["score_values"][key]
               for key in row["candidate_keys"])


def top_logit_tie_count(row: dict) -> int:
    maximum = max(row["logits"])
    return sum(value == maximum for value in row["logits"])


def validate_row(row: dict) -> list[str]:
    errors = []
    for field in IDENTITY_FIELDS:
        if not isinstance(row.get(field), str) or not row[field]:
            errors.append(f"invalid_{field}")
    if type(row.get("request_index")) is not int or row["request_index"] < 0:
        errors.append("invalid_request_index")
    digest = row.get("request_sha256")
    if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        errors.append("invalid_request_sha256")
    keys = row.get("candidate_keys")
    if not isinstance(keys, list) or len(keys) < 2 or any(not isinstance(k, str) for k in keys) or len(set(keys)) != len(keys):
        return errors + ["invalid_candidate_keys"]
    probs, logits = row.get("probabilities"), row.get("logits")
    if not isinstance(probs, dict) or set(probs) != set(keys):
        return errors + ["probability_keys_mismatch"]
    if any(not finite(v) or not 0 <= v <= 1 for v in probs.values()) or not math.isclose(sum(probs.values()), 1.0, abs_tol=TOL):
        return errors + ["invalid_probability_distribution"]
    if not isinstance(logits, list) or len(logits) != len(keys) or any(not finite(x) for x in logits):
        errors.append("invalid_logits")
    else:
        if any(abs(probs[k] - p) > TOL for k, p in zip(keys, softmax(logits))):
            errors.append("probabilities_do_not_match_t1_logits")
        expected_label = keys[max(range(len(keys)), key=logits.__getitem__)]
        if row.get("label") != expected_label:
            errors.append("label_not_first_candidate_vector_argmax")
        if "exact_top_logit_tie_keys" in row and row["exact_top_logit_tie_keys"] != [k for k, v in zip(keys, logits) if v == max(logits)]:
            errors.append("top_logit_tie_metadata_mismatch")
    label = row.get("label")
    if label not in probs or (label in probs and max(probs.values()) - probs[label] > TOL):
        errors.append("label_not_canonical_argmax")
    for field in ("input_tokens", "output_tokens", "native_decode_count"):
        if type(row.get(field)) is not int or row[field] < 0:
            errors.append(f"invalid_{field}")
    if type(row.get("input_tokens")) is int and not 1 <= row["input_tokens"] <= 2048:
        errors.append("input_tokens_outside_1_to_2048")
    if row.get("output_tokens") != 0:
        errors.append("direct_readout_output_tokens_must_be_zero")
    if row.get("native_decode_count") != 1:
        errors.append("native_decode_count_must_be_one_prefill")
    if row.get("state_cleared") is not True:
        errors.append("state_not_cleared")
    if row.get("thinking_enabled") is not False:
        errors.append("thinking_must_be_disabled")
    if not finite(row.get("temperature")) or row["temperature"] != 1:
        errors.append("temperature_must_be_one")
    if not finite(row.get("latency_ms")) or row["latency_ms"] < 0:
        errors.append("invalid_latency_ms")
    kind = row.get("type")
    if kind == "score":
        scale = row.get("score_values")
        if not isinstance(scale, dict) or set(scale) != set(keys) or any(not finite(v) for v in scale.values()):
            errors.append("invalid_score_values")
        else:
            gold = row.get("gold_score")
            if not finite(gold) or not min(scale.values()) <= gold <= max(scale.values()):
                errors.append("invalid_gold_score")
            if not finite(row.get("typed_value")) or not math.isclose(row["typed_value"], expected_score(row), abs_tol=TOL):
                errors.append("typed_value_not_expected_score")
            if row.get("dataset") == "JSTS" and scale != {str(i): i for i in range(6)}:
                errors.append("jsts_scale_must_be_0_to_5")
    elif kind in ("noul", "choice"):
        if row.get("gold_label") not in keys:
            errors.append("invalid_gold_label")
        if kind == "noul":
            if set(keys) != {"false", "true"}:
                errors.append("noul_keys_must_be_false_true")
            elif not finite(row.get("typed_value")) or not math.isclose(row["typed_value"], probs["true"], abs_tol=TOL):
                errors.append("typed_value_not_p_true")
        elif row.get("typed_value") != label:
            errors.append("typed_value_not_choice_label")
    else:
        errors.append("unsupported_type")
    return errors


def metric_rows(rows: list[dict], dataset: str, condition: str, scope: str, group: str) -> dict:
    out = {"dataset": dataset, "condition": condition, "scope": scope,
           "group": group if scope == "group" else "", "split": group if scope == "split" else "",
           "n_valid": len(rows), "unique_items": len({r["item_id"] for r in rows}),
           "unique_groups": len({r["group"] for r in rows})}
    out["exact_top_logit_tie_count"] = sum(top_logit_tie_count(r) > 1 for r in rows)
    if rows and rows[0]["type"] == "score":
        exp_errors = [abs(expected_score(r) - r["gold_score"]) for r in rows]
        hard_errors = [abs(r["score_values"][r["label"]] - r["gold_score"]) for r in rows]
        out.update(expected_score_mae=statistics.mean(exp_errors),
                   hard_label_mae=statistics.mean(hard_errors))
    elif rows:
        out["accuracy"] = sum(r["label"] == r["gold_label"] for r in rows) / len(rows)
        if dataset == "JCoLA":
            positive = "true"
            tp = sum(r["label"] == positive and r["gold_label"] == positive for r in rows)
            tn = sum(r["label"] != positive and r["gold_label"] != positive for r in rows)
            fp = sum(r["label"] == positive and r["gold_label"] != positive for r in rows)
            fn = sum(r["label"] != positive and r["gold_label"] == positive for r in rows)
            denom = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
            out.update(mcc=(tp * tn - fp * fn) / denom if denom else None,
                       mcc_degenerate=not bool(denom), tp=tp, tn=tn, fp=fp, fn=fn)
    out.update({"latency_ms_" + k: v for k, v in distribution([r["latency_ms"] for r in rows]).items()})
    return out


def pair_measurement(base: dict, variant: dict) -> dict:
    """Independent semantic alignment, including reordered token vectors."""
    if set(base["candidate_keys"]) != set(variant["candidate_keys"]):
        raise ValueError("canonical_candidate_set_mismatch")
    for field in ("type", "group", "split", "gold_label", "gold_score", "score_values"):
        if base.get(field) != variant.get(field):
            raise ValueError(f"pair_{field}_mismatch")
    if variant["condition"] == "baseline_repeat" and base["request_sha256"] != variant["request_sha256"]:
        raise ValueError("baseline_repeat_prompt_hash_mismatch")
    tv, js = divergences(base["probabilities"], variant["probabilities"])
    flip = base["label"] != variant["label"]
    bmax, vmax = max(base["probabilities"].values()), max(variant["probabilities"].values())
    btie, vtie = top_logit_tie_count(base), top_logit_tie_count(variant)
    out = {"dataset": base["dataset"], "item_id": base["item_id"], "group": base["group"], "split": base["split"],
           "condition": variant["condition"], "baseline_request_index": base["request_index"],
           "variant_request_index": variant["request_index"], "baseline_label": base["label"],
           "variant_label": variant["label"], "label_flip": flip, "total_variation": tv,
           "normalized_jensen_shannon": js, "baseline_max_probability": bmax,
           "variant_max_probability": vmax,
           "baseline_high_max_probability_flip": flip and bmax >= HIGH_MAX_PROBABILITY,
           "both_high_max_probability_flip": flip and min(bmax, vmax) >= HIGH_MAX_PROBABILITY,
           "baseline_top_logit_tie_candidates": btie, "variant_top_logit_tie_candidates": vtie,
           "any_top_logit_tie": btie > 1 or vtie > 1,
           "tie_associated_flip": flip and (btie > 1 or vtie > 1),
           "exact_prompt_hash_equal": base["request_sha256"] == variant["request_sha256"],
           "canonical_probabilities_exact_equal": base["probabilities"] == variant["probabilities"]}
    if base["type"] == "score":
        b, v = expected_score(base), expected_score(variant)
        out.update(expected_score_delta=v-b, expected_score_absolute_delta=abs(v-b),
                   expected_score_error_delta=abs(v-base["gold_score"])-abs(b-base["gold_score"]),
                   hard_score_absolute_delta=abs(base["score_values"][base["label"]]-variant["score_values"][variant["label"]]))
    else:
        correct_b, correct_v = base["label"] == base["gold_label"], variant["label"] == base["gold_label"]
        out.update(correct_to_incorrect=correct_b and not correct_v,
                   incorrect_to_correct=not correct_b and correct_v,
                   both_correct=correct_b and correct_v, both_incorrect=not correct_b and not correct_v)
        if base["type"] == "noul":
            delta = variant["probabilities"]["true"] - base["probabilities"]["true"]
            out.update(p_true_delta=delta, p_true_absolute_delta=abs(delta))
    return out


def comparison_row(pairs: list[dict], eligible: int, dataset: str, condition: str, scope: str, group: str) -> dict:
    count = len(pairs)
    out = {"dataset": dataset, "condition": condition, "scope": scope,
           "group": group if scope == "group" else "", "split": group if scope == "split" else "",
           "comparison": "exact_prompt_control" if condition == "baseline_repeat" else "primary" if condition == "display_reverse" else "secondary",
           "n_eligible_pairs": eligible, "n_complete_pairs": count, "n_incomplete_pairs": eligible-count,
           "unique_groups": len({p["group"] for p in pairs}),
           "label_flip_count": sum(p["label_flip"] for p in pairs),
           "label_flip_rate": sum(p["label_flip"] for p in pairs)/count if count else None}
    for key in ("baseline_high_max_probability_flip", "both_high_max_probability_flip", "correct_to_incorrect",
                "incorrect_to_correct", "both_correct", "both_incorrect", "exact_prompt_hash_equal",
                "canonical_probabilities_exact_equal", "any_top_logit_tie", "tie_associated_flip"):
        if pairs and key in pairs[0]:
            out[key + "_count"] = sum(p[key] for p in pairs)
    for key in ("total_variation", "normalized_jensen_shannon", "p_true_delta", "p_true_absolute_delta",
                "expected_score_delta", "expected_score_absolute_delta", "expected_score_error_delta", "hard_score_absolute_delta"):
        if pairs and key in pairs[0]:
            out.update({key + "_" + stat: value for stat, value in distribution([p[key] for p in pairs]).items()})
    return out


def analyze(predictions: list[dict], schedule: list[dict] | None = None) -> dict:
    """Return output tables plus explicit request accounting; never silently deduplicate."""
    failures, valid, statuses = [], [], []
    def fail(row: dict, code: str, detail: str = "") -> None:
        failures.append({"request_index": row.get("request_index"), "dataset": row.get("dataset"),
                         "item_id": row.get("item_id"), "condition": row.get("condition"),
                         "code": code, "detail": detail})
    by_index = defaultdict(list)
    for row in predictions:
        index = row.get("request_index")
        if type(index) is int and index >= 0:
            by_index[index].append(row)
        else:
            fail(row, "invalid_request_index")
    expected = schedule if schedule is not None else predictions
    expected_indices = Counter(r.get("request_index") for r in expected)
    expected_logical = Counter(logical_key(r) for r in expected)
    observed_logical = Counter(logical_key(r) for r in predictions)
    for meta in expected:
        index = meta.get("request_index")
        candidates = by_index.get(index, [])
        status = "valid"
        row = candidates[0] if len(candidates) == 1 else None
        if expected_indices[index] > 1:
            status = "duplicate_schedule_request_index" if schedule is not None else "duplicate_request_index"
        elif expected_logical[logical_key(meta)] > 1:
            status = "duplicate_schedule_item_condition" if schedule is not None else "duplicate_item_condition"
        elif not candidates:
            status = "missing_prediction"
        elif len(candidates) > 1:
            status = "duplicate_request_index"
        elif observed_logical[logical_key(row)] > 1:
            status = "duplicate_item_condition"
        elif schedule is not None and any(row.get(k) != meta.get(k) for k in IDENTITY_FIELDS):
            status = "schedule_identity_mismatch"
        elif schedule is not None and any(k in meta and row.get(k) != meta[k] for k in ("candidate_keys", "request_sha256", "gold_label", "gold_score", "score_values")):
            status = "schedule_metadata_mismatch"
        elif row.get("error") is not None:
            status = "inference_error"
        else:
            reasons = validate_row(row)
            if reasons:
                status = "invalid_measurement"
                fail(meta, status, ";".join(reasons))
        statuses.append({**{k: meta.get(k) for k in ("request_index", *IDENTITY_FIELDS)}, "status": status})
        if status == "valid":
            valid.append(row)
        elif status != "invalid_measurement":
            # Do not copy arbitrary model/HTTP error bodies: they may contain source text.
            fail(meta, status)
    if schedule is not None:
        for row in predictions:
            if row.get("request_index") not in expected_indices:
                fail(row, "unscheduled_prediction")
    # Cross-condition gold/scale/type/group invariance is an integrity requirement.
    grouped_valid = defaultdict(list)
    for row in valid:
        grouped_valid[item_key(row)].append(row)
    inconsistent = set()
    for key, rows in grouped_valid.items():
        anchor = next((r for r in rows if r["condition"] == "baseline"), rows[0])
        for row in rows:
            if set(row["candidate_keys"]) != set(anchor["candidate_keys"]) or any(row.get(f) != anchor.get(f) for f in ("type", "group", "split", "gold_label", "gold_score", "score_values")):
                inconsistent.add(key)
    if inconsistent:
        for row in valid:
            if item_key(row) in inconsistent:
                fail(row, "inconsistent_item_metadata")
        for status in statuses:
            if item_key(status) in inconsistent and status["status"] == "valid":
                status["status"] = "inconsistent_item_metadata"
        valid = [r for r in valid if item_key(r) not in inconsistent]
    lookup = {logical_key(r): r for r in valid}
    planned = {logical_key(r): r for r in expected}
    dataset_conditions = sorted({(r.get("dataset", ""), r.get("condition", "")) for r in expected})
    metrics, comparisons, paired = [], [], []
    for dataset, condition in dataset_conditions:
        selected = [r for r in valid if r["dataset"] == dataset and r["condition"] == condition]
        planned_rows = [r for r in expected if r.get("dataset") == dataset and r.get("condition") == condition]
        scopes = [("all", "")] + [(s, g) for s in ("split", "group") for g in sorted({r.get(s, "") for r in planned_rows})]
        for scope, group in scopes:
            scoped = selected if scope == "all" else [r for r in selected if r.get(scope) == group]
            n_scheduled = len(planned_rows) if scope == "all" else sum(r.get(scope) == group for r in planned_rows)
            met = metric_rows(scoped, dataset, condition, scope, group)
            met.update(n_scheduled=n_scheduled, n_unavailable=n_scheduled-len(scoped))
            metrics.append(met)
        if condition == "baseline":
            continue
        eligible = []
        complete = []
        for meta in planned_rows:
            key = (dataset, meta.get("item_id"), "baseline")
            if key not in planned:
                fail(meta, "baseline_not_scheduled")
            eligible.append(meta)
            base, variant = lookup.get(key), lookup.get(logical_key(meta))
            if not base or not variant:
                continue
            try:
                pair = pair_measurement(base, variant)
            except ValueError as exc:
                fail(meta, "invalid_pair", str(exc))
                continue
            complete.append(pair)
        paired.extend(complete)
        for scope, group in scopes:
            pairs = complete if scope == "all" else [p for p in complete if p.get(scope) == group]
            n_eligible = len(eligible) if scope == "all" else sum(r.get(scope) == group for r in eligible)
            comparisons.append(comparison_row(pairs, n_eligible, dataset, condition, scope, group))
    summary = {
        "schema_version": 1,
        "accounting": {"schedule_supplied": schedule is not None, "scheduled_requests": len(expected),
                       "observed_prediction_rows": len(predictions), "valid_requests": len(valid),
                       "unavailable_scheduled_requests": len(expected)-len(valid),
                       "scheduled_status_counts": dict(sorted(Counter(s["status"] for s in statuses).items())),
                       "failure_records": len(failures), "failure_code_counts": dict(sorted(Counter(f["code"] for f in failures).items())),
                       "unique_source_items": len({item_key(r) for r in expected}),
                       "source_items_by_dataset": dict(sorted(Counter(d for d, _ in {item_key(r) for r in expected}).items())),
                       "observed_total_input_tokens": sum(r.get("input_tokens", 0) for r in predictions if type(r.get("input_tokens")) is int),
                       "observed_total_output_tokens": sum(r.get("output_tokens", 0) for r in predictions if type(r.get("output_tokens")) is int),
                       "observed_total_native_decode_count": sum(r.get("native_decode_count", 0) for r in predictions if type(r.get("native_decode_count")) is int)},
        "definitions": {"alignment": "Canonical semantic candidate keys; list/token positions may change across conditions.",
                        "probability_validation": "Candidate-only softmax of measured logits at T=1; no calibration fitted.",
                        "native_contract": "Input tokens 1..2048, zero output tokens, one native prefill decode, cleared state, disabled thinking, T=1.",
                        "tie_breaking": "First maximum in the actual candidate/logit vector order; exact ties and tie-associated flips reported separately.",
                        "normalized_jensen_shannon": "Jensen-Shannon divergence divided by ln(2), range [0,1]; not square-root distance.",
                        "high_max_probability_threshold": HIGH_MAX_PROBABILITY,
                        "high_max_probability_warning": "Maximum candidate probability is not calibrated correctness probability; this threshold is distinct from entropy-based concentration.",
                        "flip_rate_denominator": "Complete valid baseline/condition pairs only; unavailable and invalid pairs counted separately.",
                        "mcc_degenerate_convention": "MCC = null when denominator is zero; mcc_degenerate is explicitly true.",
                        "inference_scope": "Descriptive fixed-sample statistics; repeated conditions are not independent questions. No confidence interval or population significance claim.",
                        "dependencies": "Group counts expose measured source proxies only; semantic dependencies and model training contamination remain unknown.",
                        "schedule_warning": None if schedule is not None else "Without a schedule, requests absent from the entire predictions file cannot be detected."},
        "per_dataset": [m for m in metrics if m["scope"] == "all"],
        "per_split": [m for m in metrics if m["scope"] == "split"],
        "condition_differences": [c for c in comparisons if c["scope"] == "all"],
        "condition_differences_by_split": [c for c in comparisons if c["scope"] == "split"]}
    return {"summary": summary, "per_dataset": metrics, "condition_differences": comparisons,
            "paired_differences": paired, "failures": failures, "request_accounting": statuses,
            "high_max_probability_flips": [p for p in paired if p["baseline_high_max_probability_flip"]]}


def read_records(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8")
    if text.lstrip().startswith("["):
        rows = json.loads(text)
    else:
        rows = [json.loads(line) for line in text.splitlines() if line.strip()]
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Input must be a JSON array or JSONL stream of objects")
    return rows


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or ["no_records"])
        writer.writeheader()
        writer.writerows(rows)


def report_text(summary: dict) -> str:
    accounting = summary["accounting"]
    lines = ["# Candidate-presentation robustness: descriptive results", "",
             f"{accounting['scheduled_requests']:,} scheduled requests concern {accounting['unique_source_items']:,} source items. "
             f"{accounting['valid_requests']:,} valid measurements; {accounting['unavailable_scheduled_requests']:,} scheduled requests unavailable. "
             f"{accounting['failure_records']:,} failure/integrity records are retained.", "",
             "Predictions and divergences are aligned by canonical semantic candidate keys. Reordered token positions do not themselves constitute changed answers. "
             "The exact-prompt baseline repeat is a control. Display-order reversal is the primary manipulation; other conditions are secondary.", "",
             "| Dataset | Condition | Valid / scheduled | Accuracy | MCC | Expected-score MAE | Hard-stage MAE |",
             "|---|---|---:|---:|---:|---:|---:|"]
    def fmt(value: Any) -> str:
        return "—" if value is None else f"{value:.6f}"
    for row in summary["per_dataset"]:
        lines.append(f"| {row['dataset']} | {row['condition']} | {row['n_valid']} / {row['n_scheduled']} | "
                     + " | ".join(fmt(row.get(k)) for k in ("accuracy", "mcc", "expected_score_mae", "hard_label_mae")) + " |")
    lines += ["", "| Dataset | Baseline vs condition | Complete / eligible pairs | Semantic label flips | Mean total variation | Mean absolute expected-score change |",
              "|---|---|---:|---:|---:|---:|"]
    for row in summary["condition_differences"]:
        lines.append(f"| {row['dataset']} | {row['condition']} | {row['n_complete_pairs']} / {row['n_eligible_pairs']} | "
                     f"{row['label_flip_count']} ({fmt(row['label_flip_rate'])}) | {fmt(row.get('total_variation_mean'))} | "
                     f"{fmt(row.get('expected_score_absolute_delta_mean'))} |")
    lines += ["", "JSTS label flips describe the selected hard stage; the primary JSTS stability quantity is the change in expected score on its original 0–5 scale. "
              "Classification and regression metrics are not pooled into one accuracy.", "",
              "Split-level and group-level rows, all complete-pair measurements, high-maximum-probability flips, exact-top-logit tie diagnostics, and every scheduled request's status are available in the CSV files. "
              "Arbitrary error bodies and source text are not reproduced. Duplicate measurements are rejected, not resolved by selecting a preferred result.", "",
              "These are descriptive results on fixed public-development examples and one measured model/environment. "
              "Repeated requests and condition variants are not independent questions. No confidence intervals, significance claims, or new calibration fit are supplied. "
              "Measured grouping proxies do not remove all dependencies; training-data contamination remains unknown. "
              "High maximum candidate probability does not establish correctness or suitability for deployment and differs from entropy-based concentration. "
              "Presentation sensitivity here concerns the model-plus-prompt system; it does not by itself identify a defect specific to direct readout or prove a causal token-position mechanism. "
              "A single exact-prompt repeat estimates a limited observed numerical floor and cannot establish universal invariance.", ""]
    if summary["definitions"]["schedule_warning"]:
        lines += ["WARNING: " + summary["definitions"]["schedule_warning"], ""]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--schedule", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = analyze(read_records(args.predictions), read_records(args.schedule) if args.schedule else None)
    results["summary"]["input_files"] = {
        "predictions_sha256": hashlib.sha256(args.predictions.read_bytes()).hexdigest(),
        "schedule_sha256": hashlib.sha256(args.schedule.read_bytes()).hexdigest() if args.schedule else None,
        "analyzer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "SUMMARY.json").write_text(json.dumps(results["summary"], indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    (args.output / "REPORT.md").write_text(report_text(results["summary"]), encoding="utf-8")
    for key, rows in results.items():
        if key != "summary":
            write_csv(args.output / (key + ".csv"), rows)
    print(json.dumps(results["summary"]["accounting"], ensure_ascii=False))


if __name__ == "__main__":
    main()
