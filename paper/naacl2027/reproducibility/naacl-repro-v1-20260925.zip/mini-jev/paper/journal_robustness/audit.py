#!/usr/bin/env python3
"""Post-run independent integrity audit; never performs inference or changes study files.

--study is the directory containing FREEZE.json and results/. --analysis is the
directory containing SUMMARY.json. --output is a new JSON report file. Failures
contain check names and indices, never source questions or arbitrary error bodies.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from native_engine import MODEL_PIN, LLAMA_COMMIT
from paper.journal_robustness.conditions import (
    SEED, EXPECTED_CONDITION_COUNTS, variants, verify_source,
)
from paper.journal_robustness.analyze import validate_row

EXPECTED_DATASET_REQUESTS = {"JCoLA": 1400, "JSTS": 1200, "JCommonsenseQA": 1400}
EXPECTED_GROUPS = {"JCoLA": 34, "JSTS": 196, "JCommonsenseQA": 200}
OUTPUT_FIELDS = {
    "logits", "probabilities", "label", "exact_top_logit_tie_keys", "typed_value",
    "temperature", "concentration", "candidate_ids", "input_tokens", "output_tokens",
    "native_decode_count", "native_total_decode_count", "model_ms", "latency_ms",
    "state_cleared", "thinking_enabled", "projection", "error",
}
FORBIDDEN_TEXT_FIELDS = {
    "state", "instructions", "criteria", "messages", "content", "question",
    "sentence", "sentence1", "sentence2", "synthetic_question",
    "choice0", "choice1", "choice2", "choice3", "choice4",
}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate_json_key")
        result[key] = value
    return result


def _constant(_):
    raise ValueError("nonfinite_json_constant")


def parse(text):
    return json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant)


def load(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def load_jsonl(path):
    raw = Path(path).read_bytes()
    if not raw.endswith(b"\n"):
        raise ValueError("incomplete_jsonl_final_line")
    lines = raw.decode("utf-8").splitlines()
    if any(not line for line in lines):
        raise ValueError("blank_jsonl_line")
    return [parse(line) for line in lines]


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def equivalent(actual, expected):
    """Strict structure and booleans; bounded rounding tolerance for metrics only."""
    if type(expected) is bool or expected is None or isinstance(expected, str):
        return type(actual) is type(expected) and actual == expected
    if type(expected) is int:
        return type(actual) is int and actual == expected
    if type(expected) is float:
        return finite(actual) and math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-10)
    if isinstance(expected, list):
        return isinstance(actual, list) and len(actual) == len(expected) and all(
            equivalent(a, b) for a, b in zip(actual, expected))
    if isinstance(expected, dict):
        return isinstance(actual, dict) and set(actual) == set(expected) and all(
            equivalent(actual[key], value) for key, value in expected.items())
    return actual == expected


def has_text_fields(value):
    if isinstance(value, dict):
        return bool(set(value) & FORBIDDEN_TEXT_FIELDS) or any(has_text_fields(v) for v in value.values())
    return isinstance(value, list) and any(has_text_fields(v) for v in value)


def rebuild_schedule(source_rows):
    """Independently reconstruct runner ordering and metadata, not run.build_schedule."""
    rows = sorted(source_rows, key=lambda row: row["id"])
    rng = random.Random(SEED)
    rng.shuffle(rows)
    schedule = []
    for row in rows:
        conditions = variants(row)
        rng.shuffle(conditions)
        for condition in conditions:
            request = condition["request"]
            keys = condition["candidate_keys"]
            meta = {
                "request_index": len(schedule), "item_id": row["id"],
                "dataset": row["dataset"], "type": row["type"], "group": row["group"],
                "split": row["split"], "condition": condition["condition"],
                "candidate_keys": keys, "candidate_tokens": request["candidates"],
                "request_sha256": sha(canonical(request).encode()),
                "source_question_sha256": sha(canonical({k: row[k] for k in
                    ("type", "state", "instructions", "criteria")}).encode()),
            }
            if row["type"] == "score":
                meta.update(gold_score=row["gold_score"], score_values={key: float(key) for key in keys})
            else:
                meta["gold_label"] = row["label"]
            schedule.append(meta)
    return schedule


def describe(values):
    ordered = sorted(values)
    at = 0.95 * (len(values) - 1)
    low, high = math.floor(at), math.ceil(at)
    return {"mean": statistics.mean(values), "median": statistics.median(values),
            "p95": ordered[low] + (at - low) * (ordered[high] - ordered[low]),
            "min": min(values), "max": max(values)}


def independently_compare(pairs, dataset, condition):
    """Recompute all first-order paired summaries without analyzer metric helpers."""
    values = defaultdict(list)
    counts = Counter()
    for base, variant in pairs:
        bp, vp = base["probabilities"], variant["probabilities"]
        keys = sorted(bp)
        flip = base["label"] != variant["label"]
        bmax, vmax = max(bp.values()), max(vp.values())
        btie = sum(x == max(base["logits"]) for x in base["logits"]) > 1
        vtie = sum(x == max(variant["logits"]) for x in variant["logits"]) > 1
        counts.update({
            "label_flip": int(flip),
            "baseline_high_max_probability_flip": int(flip and bmax >= 0.9),
            "both_high_max_probability_flip": int(flip and min(bmax, vmax) >= 0.9),
            "exact_prompt_hash_equal": int(base["request_sha256"] == variant["request_sha256"]),
            "canonical_probabilities_exact_equal": int(bp == vp),
            "any_top_logit_tie": int(btie or vtie),
            "tie_associated_flip": int(flip and (btie or vtie)),
        })
        values["total_variation"].append(math.fsum(abs(bp[k] - vp[k]) for k in keys) / 2)
        js = 0.0
        for key in keys:
            midpoint = (bp[key] + vp[key]) / 2
            for p in (bp[key], vp[key]):
                if p > 0:
                    js += p * math.log2(p / midpoint) / 2
        values["normalized_jensen_shannon"].append(max(0.0, min(1.0, js)))
        if dataset == "JSTS":
            b = math.fsum(float(k) * bp[k] for k in keys)
            v = math.fsum(float(k) * vp[k] for k in keys)
            values["expected_score_delta"].append(v - b)
            values["expected_score_absolute_delta"].append(abs(v - b))
            values["expected_score_error_delta"].append(abs(v - base["gold_score"]) - abs(b - base["gold_score"]))
            values["hard_score_absolute_delta"].append(abs(float(base["label"]) - float(variant["label"])))
        else:
            bc = base["label"] == base["gold_label"]
            vc = variant["label"] == variant["gold_label"]
            counts.update({"correct_to_incorrect": int(bc and not vc),
                           "incorrect_to_correct": int(not bc and vc),
                           "both_correct": int(bc and vc), "both_incorrect": int(not bc and not vc)})
            if dataset == "JCoLA":
                delta = vp["true"] - bp["true"]
                values["p_true_delta"].append(delta)
                values["p_true_absolute_delta"].append(abs(delta))
    total = len(pairs)
    out = {"dataset": dataset, "condition": condition, "scope": "all", "group": "", "split": "",
           "comparison": "primary" if condition == "display_reverse" else "exact_prompt_control",
           "n_eligible_pairs": total, "n_complete_pairs": total, "n_incomplete_pairs": 0,
           "unique_groups": len({base["group"] for base, _ in pairs}),
           "label_flip_rate": counts["label_flip"] / total}
    out.update({key + "_count": count for key, count in counts.items()})
    for key, observations in values.items():
        out.update({key + "_" + statistic: value for statistic, value in describe(observations).items()})
    return out


def independent_gold_metrics(rows):
    out = {"n_valid": len(rows), "n_scheduled": len(rows), "n_unavailable": 0,
           "unique_items": len({row["item_id"] for row in rows}),
           "unique_groups": len({row["group"] for row in rows}),
           "exact_top_logit_tie_count": sum(len(row["exact_top_logit_tie_keys"]) > 1 for row in rows)}
    if rows[0]["dataset"] == "JSTS":
        out["expected_score_mae"] = statistics.mean(abs(
            math.fsum(float(key) * probability for key, probability in row["probabilities"].items())
            - row["gold_score"]) for row in rows)
        out["hard_label_mae"] = statistics.mean(abs(float(row["label"]) - row["gold_score"]) for row in rows)
    else:
        out["accuracy"] = sum(row["label"] == row["gold_label"] for row in rows) / len(rows)
        if rows[0]["dataset"] == "JCoLA":
            confusion = Counter((row["gold_label"], row["label"]) for row in rows)
            tp, tn = confusion["true", "true"], confusion["false", "false"]
            fp, fn = confusion["false", "true"], confusion["true", "false"]
            denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
            out.update(tp=tp, tn=tn, fp=fp, fn=fn,
                       mcc=(tp * tn - fp * fn) / denominator if denominator else None,
                       mcc_degenerate=not bool(denominator))
    return out


class Audit:
    def __init__(self):
        self.checks = []
        self.failures = []
        self.recomputed = {}

    def check(self, name, passed, details=None):
        record = {"check": name, "passed": bool(passed)}
        if details is not None:
            record["details"] = details
        self.checks.append(record)
        if not passed:
            self.failures.append(record)
        return bool(passed)

    def phase(self, name, function):
        before = len(self.failures)
        try:
            result = function()
        except Exception as error:
            self.check(name, False, {"error_type": type(error).__name__,
                                    "message": "Phase could not complete; exception body omitted to avoid source-text disclosure."})
            return None
        self.check(name, len(self.failures) == before)
        return result


def audit(study, questions, analysis):
    study, questions, analysis = Path(study).resolve(), Path(questions).resolve(), Path(analysis).resolve()
    result = Audit()
    results_dir = study / "results"
    freeze = result.phase("load_freeze", lambda: load(study / "FREEZE.json"))
    protocol = result.phase("load_protocol", lambda: load(HERE / "PROTOCOL.json"))
    schedule = result.phase("load_schedule", lambda: load(study / "SCHEDULE.json"))
    predictions = result.phase("load_predictions", lambda: load_jsonl(results_dir / "predictions.jsonl"))
    completion = result.phase("load_completion", lambda: load(results_dir / "COMPLETION.json"))
    runtime = result.phase("load_runtime", lambda: load(results_dir / "RUNTIME.json"))
    attempt = result.phase("load_attempt", lambda: load(results_dir / "ATTEMPT.json"))
    warmups = result.phase("load_warmups", lambda: load_jsonl(results_dir / "warmup.jsonl"))
    summary = result.phase("load_analysis_summary", lambda: load(analysis / "SUMMARY.json"))
    source_rows = result.phase("verify_original_600_source_rows", lambda: verify_source(questions))

    def frozen_source_checks():
        paths = {"runner": HERE / "run.py", "conditions": HERE / "conditions.py",
                 "protocol": HERE / "PROTOCOL.json", "analyzer": HERE / "analyze.py",
                 "native_engine": ROOT / "native_engine.py", "model_pin": ROOT / "native_model.json",
                 "source_selection": ROOT / "paper/external_expanded/SELECTION.json",
                 "source_protocol": ROOT / "paper/external_expanded/PROTOCOL.json", "questions": questions}
        actual = {key: sha(path.read_bytes()) for key, path in paths.items()}
        result.check("all_nine_frozen_source_hashes", freeze["source_sha256"] == actual)
        for key in paths:
            result.check("frozen_sha_" + key, freeze["source_sha256"].get(key) == actual[key])
        result.check("frozen_stage_seed_and_item_budget", freeze["stage"] == "before_model_inference"
                     and freeze["seed"] == SEED and freeze["n_items"] == 600
                     and freeze["n_measured_requests"] == 4000)
        result.check("pinned_model_freeze_and_manifest", freeze["model_pin"] == MODEL_PIN
                     and all(load(ROOT / "native_model.json").get(k) == v for k, v in MODEL_PIN.items()))
        reconstructed = rebuild_schedule(source_rows)
        result.check("independent_schedule_reconstruction", reconstructed == schedule)
        result.check("canonical_schedule_hash", sha(canonical(schedule).encode()) == freeze["schedule_sha256"])
        result.check("freeze_condition_counts", freeze["condition_counts"] == EXPECTED_CONDITION_COUNTS)
        result.check("freeze_dataset_request_counts", freeze["dataset_counts"] == EXPECTED_DATASET_REQUESTS)
        result.check("600_items_4000_requests", len(schedule) == 4000
                     and len({r["item_id"] for r in schedule}) == 600)
        result.check("schedule_condition_counts", dict(Counter(r["condition"] for r in schedule)) == EXPECTED_CONDITION_COUNTS)
        result.check("schedule_dataset_request_counts", dict(Counter(r["dataset"] for r in schedule)) == EXPECTED_DATASET_REQUESTS)
        for dataset, groups in EXPECTED_GROUPS.items():
            rows = [r for r in schedule if r["dataset"] == dataset]
            result.check("item_and_group_count_" + dataset, len({r["item_id"] for r in rows}) == 200
                         and len({r["group"] for r in rows}) == groups
                         and protocol["source"]["per_dataset"][dataset]["groups"] == groups)

    result.phase("frozen_source_and_schedule", frozen_source_checks)

    def completion_checks():
        result.check("completion_success", completion["status"] == "completed"
                     and completion["expected_requests"] == 4000 and completion["recorded_requests"] == 4000
                     and completion["failed_requests"] == 0 and completion["fatal_error"] is None
                     and completion["source_unchanged"] is True)
        result.check("completion_total_decodes", completion["native_total_decode_count_including_warmup"] == 4003)
        inventory = {path.name: sha(path.read_bytes()) for path in results_dir.glob("*.json*")
                     if path.is_file() and path.name != "COMPLETION.json"}
        result.check("completion_result_inventory_exact", completion["file_sha256"] == inventory)
        result.check("completion_expected_result_files", set(inventory) == {
            "ATTEMPT.json", "RUNTIME.json", "warmup.jsonl", "predictions.jsonl"})
        result.check("attempt_freeze_binding", attempt["freeze_sha256"] == sha((study / "FREEZE.json").read_bytes())
                     and attempt["expected_requests"] == 4000 and attempt["status"] == "started_not_completed")
        stamps = [freeze["created_at"], attempt["started_at"], runtime["verified_at"], completion["finished_at"]]
        stamps = [datetime.fromisoformat(value) for value in stamps]
        result.check("recorded_timestamp_order", all(a <= b for a, b in zip(stamps, stamps[1:])))
        result.check("completion_attempt_start_agrees", completion["started_at"] == attempt["started_at"])

    result.phase("completion_and_record_integrity", completion_checks)

    def runtime_checks():
        data = runtime["fingerprint_data"]
        # NativeEngine uses ensure_ascii=True for this hash, unlike request hashes.
        digest = sha(json.dumps(data, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())
        result.check("runtime_fingerprint_recomputed", digest == runtime["fingerprint"])
        fixed = {"schema_version": 1, "model": MODEL_PIN["repo_id"], "revision": MODEL_PIN["revision"],
                 "model_sha256": MODEL_PIN["sha256"], "model_bytes": MODEL_PIN["bytes"],
                 "llama_cpp_commit": LLAMA_COMMIT, "dtype": MODEL_PIN["quantization"],
                 "device": "metal", "threads": 6, "max_input_tokens": 2048,
                 "prompt_style": "repeat_typed_score", "attention": "llama.cpp_flash",
                 "python_source_sha256": freeze["source_sha256"]["native_engine"],
                 "machine": "arm64", "os": "Darwin"}
        result.check("runtime_pinned_model_and_settings", all(data.get(k) == v for k, v in fixed.items()))
        native_files = data["native_files"]
        result.check("runtime_native_inventory", len([key for key in native_files if key.endswith(".dylib")]) >= 7
                     and {"bin/llama-decision-helper", "llama_decision_helper.cpp"} <= set(native_files)
                     and all(isinstance(d, str) and len(d) == 64 and set(d) <= set("0123456789abcdef")
                             for d in native_files.values()))
        ready = runtime["native_ready"]
        expected_ready = {"ready": True, "mode": "direct_logits", "ctx": 2048,
                          "gpu_layers": 99, "total_decode_count": 0,
                          "batch_strategy": "sequential_independent_requests"}
        result.check("runtime_native_ready", all(ready.get(k) == v for k, v in expected_ready.items())
                     and type(ready.get("vocab_size")) is int and ready["vocab_size"] >= 26)
        from paper.journal_robustness.run import WARMUPS
        result.check("exact_three_synthetic_warmups", len(warmups) == 3
                     and [row["index"] for row in warmups] == [0, 1, 2]
                     and [row["synthetic_question"] for row in warmups] == WARMUPS
                     and all(set(row) == {"index", "synthetic_question", "answer"} for row in warmups))
        result.check("warmup_decode_counters", all(
            row["answer"]["native_total_decode_count"] == index + 1
            and row["answer"]["native_decode_count"] == 1 and row["answer"]["output_tokens"] == 0
            for index, row in enumerate(warmups)))

    result.phase("runtime_and_warmups", runtime_checks)

    def measurement_checks():
        result.check("prediction_count_4000", len(predictions) == 4000)
        bad_metadata, bad_schema, bad_contract, bad_counters, bad_ties = [], [], [], [], []
        bad_mapping, bad_concentration, bad_timing = [], [], []
        token_ids = {}
        vocabulary = runtime["native_ready"]["vocab_size"]
        for index, row in enumerate(predictions):
            if not isinstance(row, dict):
                bad_schema.append(index)
                continue
            if index >= len(schedule):
                bad_metadata.append(index)
                continue
            meta = schedule[index]
            if {key: row.get(key) for key in meta} != meta:
                bad_metadata.append(index)
            if set(row) != set(meta) | OUTPUT_FIELDS:
                bad_schema.append(index)
                # Retain the failing index without dereferencing missing fields.
                continue
            if validate_row(row) or row.get("error") is not None or row.get("projection") != "full_vocab_then_candidate_gather":
                bad_contract.append(index)
                continue
            if (type(row.get("native_total_decode_count")) is not int
                    or row["native_total_decode_count"] != index + 4
                    or type(row.get("native_decode_count")) is not int or row["native_decode_count"] != 1
                    or type(row.get("output_tokens")) is not int or row["output_tokens"] != 0):
                bad_counters.append(index)
            keys, logits, ids, tokens = row["candidate_keys"], row["logits"], row["candidate_ids"], row["candidate_tokens"]
            if (not isinstance(ids, list) or not isinstance(tokens, list)
                    or any(type(value) is not int for value in ids)
                    or any(not isinstance(value, str) for value in tokens)):
                bad_mapping.append(index)
                continue
            peak = max(logits)
            if row.get("exact_top_logit_tie_keys") != [key for key, value in zip(keys, logits) if value == peak]:
                bad_ties.append(index)
            mapping_valid = (len(ids) == len(keys) == len(tokens) and len(set(ids)) == len(ids)
                             and all(0 <= value < vocabulary for value in ids))
            for token, token_id in zip(tokens, ids):
                if token in token_ids and token_ids[token] != token_id:
                    mapping_valid = False
                token_ids[token] = token_id
            weights = [math.exp(value - peak) for value in logits]
            probabilities = [weight / math.fsum(weights) for weight in weights]
            first = max(range(len(logits)), key=logits.__getitem__)
            mapping_valid = mapping_valid and row["label"] == keys[first] and all(
                math.isclose(row["probabilities"][key], p, rel_tol=1e-10, abs_tol=1e-12)
                for key, p in zip(keys, probabilities))
            if not mapping_valid:
                bad_mapping.append(index)
            entropy_concentration = 1 + math.fsum(p * math.log(p) for p in probabilities if p > 0) / math.log(len(keys))
            if not finite(row.get("concentration")) or not math.isclose(row["concentration"], entropy_concentration, abs_tol=1e-10):
                bad_concentration.append(index)
            if not finite(row.get("model_ms")) or row["model_ms"] < 0 or row["latency_ms"] + 1e-6 < row["model_ms"]:
                bad_timing.append(index)
        for name, indices in [("all_prediction_schedule_metadata", bad_metadata),
                              ("strict_prediction_schema", bad_schema), ("analyzer_and_native_contract", bad_contract),
                              ("serial_native_counters_index_plus_four", bad_counters),
                              ("exact_top_logit_tie_keys", bad_ties), ("independent_token_probability_mapping", bad_mapping),
                              ("independent_entropy_concentration", bad_concentration), ("valid_runtime_timing", bad_timing)]:
            result.check(name, not indices, {"failure_count": len(indices), "request_indices": indices})
        result.recomputed["recorded_token_ids"] = token_ids
        result.check("prediction_condition_counts", dict(Counter(row["condition"] for row in predictions)) == EXPECTED_CONDITION_COUNTS)
        result.check("prediction_dataset_request_counts", dict(Counter(row["dataset"] for row in predictions)) == EXPECTED_DATASET_REQUESTS)
        result.check("no_source_text_fields_in_public_records", not any(has_text_fields(value) for value in
                     (schedule, predictions, freeze, completion, runtime, attempt, summary)))
        # Full source-state strings are unique enough to check without treating
        # short JCQA answer words as forbidden substrings of explanatory prose.
        public_paths = [study / "SCHEDULE.json", results_dir / "predictions.jsonl"]
        public_paths += [path for path in analysis.iterdir() if path.is_file() and path.suffix in {".json", ".csv", ".md"}]
        public_text = "\n".join(path.read_text(encoding="utf-8") for path in public_paths)
        leaked = [i for i, source in enumerate(source_rows) if source["state"] in public_text
                  or json.dumps(source["state"], ensure_ascii=False)[1:-1] in public_text]
        result.check("no_complete_benchmark_state_text", not leaked, {"source_row_indices": leaked})

    result.phase("measurement_integrity", measurement_checks)

    def analysis_checks():
        input_files = {"predictions_sha256": sha((results_dir / "predictions.jsonl").read_bytes()),
                       "schedule_sha256": sha((study / "SCHEDULE.json").read_bytes()),
                       "analyzer_sha256": sha((HERE / "analyze.py").read_bytes())}
        result.check("analysis_input_hashes", summary["input_files"] == input_files)
        accounting = {"schedule_supplied": True, "scheduled_requests": 4000,
                      "observed_prediction_rows": 4000, "valid_requests": 4000,
                      "unavailable_scheduled_requests": 0, "scheduled_status_counts": {"valid": 4000},
                      "failure_records": 0, "failure_code_counts": {}, "unique_source_items": 600,
                      "source_items_by_dataset": {dataset: 200 for dataset in EXPECTED_GROUPS},
                      "observed_total_input_tokens": sum(row["input_tokens"] for row in predictions),
                      "observed_total_output_tokens": 0, "observed_total_native_decode_count": 4000}
        result.check("independent_analysis_accounting", equivalent(summary["accounting"], accounting))
        grouped = defaultdict(list)
        lookup = {}
        for row in predictions:
            grouped[row["dataset"], row["condition"]].append(row)
            lookup[row["dataset"], row["item_id"], row["condition"]] = row
        by_metric = {(row["dataset"], row["condition"]): row for row in summary["per_dataset"]}
        result.check("summary_metric_rows_exact", set(by_metric) == set(grouped)
                     and len(by_metric) == len(summary["per_dataset"]))
        gold_metrics = []
        for key, rows in sorted(grouped.items()):
            expected = independent_gold_metrics(rows)
            reported = by_metric[key]
            result.check("independent_gold_metrics_" + "_".join(key),
                         all(equivalent(reported.get(field), value) for field, value in expected.items()))
            gold_metrics.append({"dataset": key[0], "condition": key[1], **expected})
        result.recomputed["gold_metrics_all_conditions"] = gold_metrics
        by_comparison = {(row["dataset"], row["condition"]): row for row in summary["condition_differences"]}
        expected_comparison_keys = {key for key in grouped if key[1] != "baseline"}
        result.check("summary_comparison_rows_exact", set(by_comparison) == expected_comparison_keys
                     and len(by_comparison) == len(summary["condition_differences"]))
        primary = []
        for dataset in sorted(EXPECTED_GROUPS):
            for condition in ("display_reverse", "baseline_repeat"):
                rows = grouped[dataset, condition]
                pairs = [(lookup[dataset, row["item_id"], "baseline"], row) for row in rows]
                expected = independently_compare(pairs, dataset, condition)
                result.check("independent_pair_summary_" + dataset + "_" + condition,
                             equivalent(by_comparison[dataset, condition], expected))
                primary.append(expected)
        result.recomputed["primary_and_repeat_comparisons"] = primary

    result.phase("independent_analysis_recomputation", analysis_checks)
    return {"schema_version": 1, "audit_created_at": datetime.now(timezone.utc).isoformat(),
            "passed": not result.failures, "checks_run": len(result.checks),
            "failed_check_count": len(result.failures), "checks": result.checks,
            "failures": result.failures, "independently_recomputed": result.recomputed,
            "audit_source_sha256": sha(Path(__file__).read_bytes()),
            "scope": "Post-run record and numerical audit; source rows verified, schedule independently reconstructed, summary metrics independently recomputed. Uses frozen analyzer validation as an additional check. No model inference, source-text publication, or study-file changes.",
            "limits": "Recorded runtime fingerprint and pinned identities are verified; this audit does not rehash the 20GB weight file/native binaries, replay inference, or validate human semantic equivalence. Descriptive fixed-sample results only."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path, required=True)
    parser.add_argument("--questions", type=Path, required=True)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    destination = args.output.resolve()
    if destination.is_relative_to((args.study / "results").resolve()):
        parser.error("write the audit outside results/ so the frozen completion inventory remains unchanged")
    if destination.exists():
        parser.error("output must be a new file; preserve earlier audit evidence")
    report = audit(args.study, args.questions, args.analysis)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"passed": report["passed"], "checks_run": report["checks_run"],
                      "failed_check_count": report["failed_check_count"], "output": str(destination)}))
    raise SystemExit(0 if report["passed"] else 1)


if __name__ == "__main__":
    main()
