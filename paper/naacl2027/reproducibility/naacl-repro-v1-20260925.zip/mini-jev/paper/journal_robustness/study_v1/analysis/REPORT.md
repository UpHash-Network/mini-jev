# Candidate-presentation robustness: descriptive results

4,000 scheduled requests concern 600 source items. 4,000 valid measurements; 0 scheduled requests unavailable. 0 failure/integrity records are retained.

Predictions and divergences are aligned by canonical semantic candidate keys. Reordered token positions do not themselves constitute changed answers. The exact-prompt baseline repeat is a control. Display-order reversal is the primary manipulation; other conditions are secondary.

| Dataset | Condition | Valid / scheduled | Accuracy | MCC | Expected-score MAE | Hard-stage MAE |
|---|---|---:|---:|---:|---:|---:|
| JCoLA | baseline | 200 / 200 | 0.860000 | 0.570821 | — | — |
| JCoLA | baseline_repeat | 200 / 200 | 0.860000 | 0.570821 | — | — |
| JCoLA | definition_reword | 200 / 200 | 0.875000 | 0.613785 | — | — |
| JCoLA | display_reverse | 200 / 200 | 0.825000 | 0.505486 | — | — |
| JCoLA | instruction_reword | 200 / 200 | 0.860000 | 0.570821 | — | — |
| JCoLA | label_reverse | 200 / 200 | 0.870000 | 0.589202 | — | — |
| JCoLA | opaque_keys | 200 / 200 | 0.845000 | 0.562570 | — | — |
| JCommonsenseQA | baseline | 200 / 200 | 0.950000 | — | — | — |
| JCommonsenseQA | baseline_repeat | 200 / 200 | 0.950000 | — | — | — |
| JCommonsenseQA | display_reverse | 200 / 200 | 0.960000 | — | — | — |
| JCommonsenseQA | display_rotate | 200 / 200 | 0.900000 | — | — | — |
| JCommonsenseQA | instruction_reword | 200 / 200 | 0.950000 | — | — | — |
| JCommonsenseQA | label_reverse | 200 / 200 | 0.910000 | — | — | — |
| JCommonsenseQA | opaque_keys | 200 / 200 | 0.955000 | — | — | — |
| JSTS | baseline | 200 / 200 | — | — | 0.506493 | 0.548000 |
| JSTS | baseline_repeat | 200 / 200 | — | — | 0.506493 | 0.548000 |
| JSTS | definition_reword | 200 / 200 | — | — | 0.510468 | 0.597000 |
| JSTS | display_reverse | 200 / 200 | — | — | 0.484406 | 0.539000 |
| JSTS | display_rotate | 200 / 200 | — | — | 0.539129 | 0.753000 |
| JSTS | instruction_reword | 200 / 200 | — | — | 0.523129 | 0.597000 |

| Dataset | Baseline vs condition | Complete / eligible pairs | Semantic label flips | Mean total variation | Mean absolute expected-score change |
|---|---|---:|---:|---:|---:|
| JCoLA | baseline_repeat | 200 / 200 | 0 (0.000000) | 0.000000 | — |
| JCoLA | definition_reword | 200 / 200 | 7 (0.035000) | 0.030507 | — |
| JCoLA | display_reverse | 200 / 200 | 11 (0.055000) | 0.112182 | — |
| JCoLA | instruction_reword | 200 / 200 | 10 (0.050000) | 0.033391 | — |
| JCoLA | label_reverse | 200 / 200 | 6 (0.030000) | 0.052140 | — |
| JCoLA | opaque_keys | 200 / 200 | 9 (0.045000) | 0.045423 | — |
| JCommonsenseQA | baseline_repeat | 200 / 200 | 0 (0.000000) | 0.000000 | — |
| JCommonsenseQA | display_reverse | 200 / 200 | 11 (0.055000) | 0.079104 | — |
| JCommonsenseQA | display_rotate | 200 / 200 | 17 (0.085000) | 0.150036 | — |
| JCommonsenseQA | instruction_reword | 200 / 200 | 2 (0.010000) | 0.014209 | — |
| JCommonsenseQA | label_reverse | 200 / 200 | 14 (0.070000) | 0.087274 | — |
| JCommonsenseQA | opaque_keys | 200 / 200 | 7 (0.035000) | 0.025967 | — |
| JSTS | baseline_repeat | 200 / 200 | 0 (0.000000) | 0.000000 | 0.000000 |
| JSTS | definition_reword | 200 / 200 | 43 (0.215000) | 0.120779 | 0.128667 |
| JSTS | display_reverse | 200 / 200 | 34 (0.170000) | 0.127835 | 0.181681 |
| JSTS | display_rotate | 200 / 200 | 49 (0.245000) | 0.208223 | 0.298259 |
| JSTS | instruction_reword | 200 / 200 | 22 (0.110000) | 0.088829 | 0.120884 |

JSTS label flips describe the selected hard stage; the primary JSTS stability quantity is the change in expected score on its original 0–5 scale. Classification and regression metrics are not pooled into one accuracy.

Split-level and group-level rows, all complete-pair measurements, high-maximum-probability flips, exact-top-logit tie diagnostics, and every scheduled request's status are available in the CSV files. Arbitrary error bodies and source text are not reproduced. Duplicate measurements are rejected, not resolved by selecting a preferred result.

These are descriptive results on fixed public-development examples and one measured model/environment. Repeated requests and condition variants are not independent questions. No confidence intervals, significance claims, or new calibration fit are supplied. Measured grouping proxies do not remove all dependencies; training-data contamination remains unknown. High maximum candidate probability does not establish correctness or suitability for deployment and differs from entropy-based concentration. Presentation sensitivity here concerns the model-plus-prompt system; it does not by itself identify a defect specific to direct readout or prove a causal token-position mechanism. A single exact-prompt repeat estimates a limited observed numerical floor and cannot establish universal invariance.
