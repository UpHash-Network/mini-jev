#!/usr/bin/env python3
"""Render the descriptive fixed-panel results; no fitting or inference."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    summary = json.loads(args.summary.read_text())
    rows = {(r['dataset'], r['condition']): r for r in summary['condition_differences']}
    conditions = ['baseline_repeat', 'display_reverse', 'display_rotate', 'label_reverse',
                  'opaque_keys', 'instruction_reword', 'definition_reword']
    names = ['Identical repeat (control)', 'Reverse display (primary)', 'Rotate display',
             'Reverse output letters', 'Substitute displayed keys', 'Reword instruction', 'Reword definitions']
    classification_maximum = max([r['label_flip_rate']*100 for r in rows.values()
                                  if r['dataset'] in {'JCoLA', 'JCommonsenseQA'}] + [.001])
    fig, axes = plt.subplots(1, 3, figsize=(13, 5.5), sharey=True)
    colors = ['#727b85', '#1e65a7'] + ['#a5b8ca']*5
    for ax, dataset, title in zip(axes, ['JCoLA', 'JCommonsenseQA', 'JSTS'],
                                  ['JCoLA: grammatical acceptability', 'JCQA: common-sense answers', 'JSTS: semantic similarity']):
        vals = []
        for i, condition in enumerate(conditions):
            row = rows.get((dataset, condition))
            val = None if row is None else (row['expected_score_absolute_delta_mean'] if dataset == 'JSTS' else row['label_flip_rate']*100)
            vals.append(val)
            if val is not None:
                ax.barh(i, val, height=.57, color=colors[i])
        maximum = (max([v for v in vals if v is not None] + [.001])
                   if dataset == 'JSTS' else classification_maximum)
        ax.set_xlim(0, maximum*1.33)
        for i, val in enumerate(vals):
            if val is None:
                ax.text(maximum*.025, i, 'Not tested', va='center', fontsize=9, color='#6e7781')
            else:
                label = f'{val:.3f}' if dataset == 'JSTS' else f'{val:.1f}%'
                ax.text(val+maximum*.025, i, label, va='center', fontsize=9)
        ax.set_title(title, fontsize=11, pad=14)
        ax.set_xlabel('Mean absolute score change (0–5)' if dataset == 'JSTS' else 'Semantic decision changes (%)', fontsize=9)
        ax.grid(axis='x', color='#e5e9ee', zorder=-1)
        ax.set_axisbelow(True)
        for spine in ['top', 'right', 'left']:
            ax.spines[spine].set_visible(False)
        ax.tick_params(axis='y', length=0)
    axes[0].set_yticks(range(len(names)), names, fontsize=9)
    axes[0].invert_yaxis()
    fig.suptitle('Mini Jev: sensitivity to fixed prompt changes', fontsize=16, x=.56, y=.98)
    fig.text(.56, .918, 'Each condition is compared with the original prompt on the same 200 items per dataset.',
             ha='center', fontsize=10, color='#49515a')
    fig.text(.02, .015, 'Qwen3.6-35B-A3B Q4_K_M · 600 reused public-development items · 4,000 requests\n'
             'Descriptive point estimates; no confidence intervals. One model, one fixed wording per rewording condition.',
             fontsize=9, color='#49515a')
    fig.tight_layout(rect=(0,.095,1,.895))
    args.output.mkdir(parents=True, exist_ok=True)
    for ext in ['png', 'svg', 'pdf']:
        fig.savefig(args.output/f'robustness_primary.{ext}', dpi=180, bbox_inches='tight')
    plt.close(fig)


if __name__ == '__main__':
    main()
