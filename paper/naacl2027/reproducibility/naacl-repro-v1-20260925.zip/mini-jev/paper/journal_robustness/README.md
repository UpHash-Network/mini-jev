# Fixed-sample prompt robustness extension

The native study completed **4,000/4,000** measurements with no inference errors.
Its 93-check independent audit passed. The separate two-checkpoint replication
completed **3,600/3,600** measurements and its 163-check audit passed, for **7,600
measured requests on the same 600 source items** across three checkpoints.
See the [Japanese report](REPORT.ja.md), [English empirical-section draft](JOURNAL_RESULTS_DRAFT.md),
[native results](study_v1/analysis/REPORT.md), and
[cross-checkpoint results](cross_model/study_v1/analysis/REPORT.md).

This experiment measures how typed decisions change under a small, fixed set of
prompt manipulations. It reuses the external pilot's **600 public-development
questions**: 200 JCoLA, 200 JSTS and 200 JCommonsenseQA. It plans **4,000 serial
requests**, not 4,000 independent questions. It does not train a model, fit a new
temperature, or alter the EACL submission results.

Read [PROTOCOL.json](PROTOCOL.json) for the frozen hypotheses, exact Japanese
rewordings, execution order, estimands, dependence groups and limitations.
Execution manifests record the actual frozen file and request-schedule hashes.
This is a local freeze, not an independent public preregistration.

| Condition | JCoLA | JSTS | JCQA | Change |
| --- | ---: | ---: | ---: | --- |
| `baseline` | 200 | 200 | 200 | Original native formatter |
| `baseline_repeat` | 200 | 200 | 200 | Identical content, separate execution |
| `display_reverse` | 200 | 200 | 200 | Reverse physical option-line order |
| `display_rotate` | — | 200 | 200 | Rotate physical lines left by one |
| `label_reverse` | 200 | — | 200 | Reverse assigned output letters |
| `opaque_keys` | 200 | — | 200 | Replace displayed keys with `slot_0`, etc. |
| `instruction_reword` | 200 | 200 | 200 | One fixed instruction rewording |
| `definition_reword` | 200 | 200 | — | One fixed set of criterion rewordings |
| **Requests** | **1,400** | **1,200** | **1,400** | **4,000 total** |

The main comparison is **display reversal versus baseline within each dataset**.
For Choice/Noul it measures semantic decision agreement; for JSTS it measures
absolute expected-score change on the original 0–5 scale. The identical baseline
repeat provides a numerical/runtime variability control. Secondary summaries
include mapped distribution changes, semantic flips and descriptive gold-label
performance. JSTS continuous gold scores are never rounded into class labels.

## Formatter interface

`conditions.variants(row)` returns a list of:

```python
{
    "condition": "display_reverse",
    "request": {
        "messages": [...],
        "candidates": [...],
        "max_input_tokens": 2048,
        # "assistant_prefix" appears only when the native formatter sets it.
    },
    "candidate_keys": [...],  # same order as request["candidates"] / returned logits
}
```

The adapter uses an uninitialized `NativeEngine` only as a formatter; importing
the module or generating variants never loads model weights or performs
inference. A runner must supply request IDs and use the verified native helper.

`candidate_keys` is essential when interpreting `label_reverse`: the allowed
token vector remains `A, B, ...`, while the vector's original semantic keys are
reversed. Display-order variants instead preserve each complete token/key/meaning
binding and reorder the rendered lines **after** formatting. Calling the native
formatter with reordered options would silently reassign labels and is not the
implemented manipulation. Both repeated prompt copies are changed consistently.
JSTS stage tokens remain `0, 1, 2, 3, 4, 5` with unchanged ordinal meanings.

`conditions.verify_source(path)` validates the external file's SHA-256, byte
count, 600 IDs, original selection order, per-question hashes, gold labels and
source metadata. The source file must remain outside the repository. The known
source digest is:

```text
4df650133880c935c885668b46b33d8d49c14fdb82b0703b4bf45e0bc297272b
```

Freeze the condition generator, protocol, source/native hashes and complete
ordered request-hash schedule before running. Use seed `2026092201`, shuffled item
blocks and randomized eligible condition order within each block. Source text and
full requests belong only in an external working cache; publish IDs/hashes,
mapped numeric results and metadata without source examples.

## Run and reproduce

Use Python 3.10 or later and the repository's verified native runtime, built
according to [NATIVE_BUILD.md](../../NATIVE_BUILD.md). Model download and native
build instructions are in the [main README](../../README.md). The run verifies
the pinned model and native files before loading; other models cannot be silently
substituted. The model is loaded once and each request clears its context.

First materialize the frozen source selection in a cache **outside** the checkout:

```bash
python3 paper/external_expanded/materialize.py \
  --cache-dir /absolute/external/expanded-cache
```

Then prepare a new directory, freezing the exact ordered requests without calling
a model. The supplied `study_v1` contains the recorded study and must not be
overwritten; choose a different directory for replication.

```bash
python3 paper/journal_robustness/run.py prepare \
  --questions /absolute/external/expanded-cache/questions.jsonl \
  --output /absolute/new-replication

python3 paper/journal_robustness/run.py run \
  --questions /absolute/external/expanded-cache/questions.jsonl \
  --output /absolute/new-replication \
  --model /absolute/models/Qwen3.6-35B-A3B-Q4_K_M.gguf \
  --native-binary /absolute/verified-runtime/bin/llama-decision-helper \
  --log /absolute/external/native.log

python3 paper/journal_robustness/analyze.py \
  --predictions /absolute/new-replication/results/predictions.jsonl \
  --schedule /absolute/new-replication/SCHEDULE.json \
  --output /absolute/new-replication/analysis
```

The log's parent directory must exist and the log must stay outside the checkout.
Three synthetic warm-up requests precede and are excluded from the 4,000 measured
requests. `FREEZE.json`, `RUNTIME.json`, and `COMPLETION.json` distinguish planned
work from verified execution and preserve hashes. Every measured request retains
its index, canonical mapping, logits and status. Analysis produces aggregate,
paired-item, split/group, and explicit failure/accounting tables. Exact top-logit
ties are kept, using the actual candidate-vector order for argmax.

## Verification

From the repository root:

```bash
python3 -m unittest discover -s paper/journal_robustness -p 'test_*.py' -v
```

The synthetic fixture tests check exact baseline formatter identity, independent
baseline-repeat copies, semantic decoding after label reassignment, invariant
token/meaning bindings under display reorder, unchanged Score scale, correct
eligibility/request budget, unchanged state even when it contains option-like
text, and rejection of unexpected schemas. They test the adapter's semantic
contract without requiring source data or a running model.

After analysis, independently audit a completed run (use a new output filename):

```bash
python3 paper/journal_robustness/audit.py \
  --study /absolute/new-replication \
  --questions /absolute/external/expanded-cache/questions.jsonl \
  --analysis /absolute/new-replication/analysis \
  --output /absolute/new-replication/AUDIT.json
```

`plot.py --summary /absolute/new-replication/analysis/SUMMARY.json --output
/absolute/new-replication/figures` renders the descriptive figure with Matplotlib.
`requirements-plot.txt` records the isolated plotting environment, separate from
both measured runtimes. The two classification panels share a horizontal scale;
the JSTS panel uses score units. Both studies' audits also recompute primary
statistics independently; they do not replay inference or validate generalization.

## Interpretation limits

The rewordings are AI-authored hypotheses of semantic equivalence, with **no
independent human validation**. Only one wording per manipulation is tested.
Results describe prompt sensitivity on this reused public-development sample;
they do not establish a direct-readout-specific weakness, causal position-bias
mechanism, model-wide generalization or calibrated correctness probabilities.
The existing 34 JCoLA source groups, 196 JSTS caption components and 200 JCQA
question-string groups are coarse dependence proxies.

This first phase reports descriptive point estimates, without confidence
intervals or significance claims. Argmax uses the first maximum in each actual
candidate-token vector, matching native inference; exact ties are retained and
flagged. Jensen–Shannon divergence is normalized by ln(2), in the range 0–1.

Failures and incomplete runs retain their original identities and planned
denominators. Do not replace difficult cases, select a favorable prompt from
these outcomes, or silently change the frozen protocol. The first-phase runner
refuses to overwrite or resume existing results. Any future resume implementation
must validate the identical frozen schedule and hashes and record an amendment.

## Dataset attribution and licenses

The source selection, gold/group metadata, prompt/rubric adaptations, model
predictions and derived results follow the **CC BY-SA 4.0** notice in
[external_expanded/README.md](../external_expanded/README.md#sources-and-licenses).
JGLUE was created by Kentaro Kurihara, Daisuke Kawahara and Tomohide Shibata through
Yahoo Japan Corporation and Kawahara Lab, Waseda University. JCoLA was created by
Taiga Someya, Yushi Sugimoto and Yohei Oseki. Pinned upstream revisions, papers and
license copies are provided in that source directory. Changes in this experiment
are fixed prompt manipulations and added predictions and descriptive summaries.
No endorsement is implied. The Python implementation and original synthetic test
fixtures use the project's MIT license; embedded adapted rubric text retains the
source data license. The repository's MIT license does not relicense datasets.
Original question/sentence/answer-option text, native binaries and model weights
are not included in the experiment records.
