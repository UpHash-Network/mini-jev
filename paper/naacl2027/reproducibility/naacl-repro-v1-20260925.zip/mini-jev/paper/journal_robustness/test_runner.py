"""Synthetic protocol fixtures; these never load a model or count as evidence."""
import math
import unittest

from paper.journal_robustness.run import ResearchEngine


class SyntheticEngine(ResearchEngine):
    def __init__(self, logits):
        self.fixture_logits = logits
        self.sequence = self.total_decode_count = 0
        self.max_input_tokens = 2048
        self.info = {'vocab_size': 100}

    @property
    def ready(self):
        return True

    def _assert_artifacts_unchanged(self):
        pass

    def _write(self, request, deadline):
        self.request = request

    def _read(self, timeout):
        return {'id': self.request['id'], 'candidate_ids': list(range(len(self.fixture_logits))),
                'logits': self.fixture_logits, 'input_tokens': 10, 'output_tokens': 0,
                'decode_count': 1, 'total_decode_count': self.total_decode_count + 1,
                'decode_count_semantics': 'llama_decode_API_calls', 'model_ms': 0,
                'latency_ms': 0, 'projection': 'full_vocab_then_candidate_gather',
                'state_cleared': True, 'template_applied': True, 'thinking_enabled': False}

    def _protocol_error(self, message):
        raise ValueError(message)


class RunnerTests(unittest.TestCase):
    def test_reversed_letters_decode_into_semantic_noul(self):
        engine = SyntheticEngine([0.0, math.log(3)])
        answer = engine.evaluate_request({'candidates': ['A', 'B']}, ['true', 'false'], 'noul')
        self.assertAlmostEqual(answer['typed_value'], .25)
        self.assertEqual(answer['label'], 'false')
        self.assertEqual(answer['native_total_decode_count'], 1)

    def test_score_expectation_and_large_logit_stability(self):
        engine = SyntheticEngine([1000.0, 1000.0])
        answer = engine.evaluate_request({'candidates': ['0', '5']}, ['0', '5'], 'score')
        self.assertEqual(answer['typed_value'], 2.5)
        self.assertEqual(answer['label'], '0')
        self.assertEqual(answer['exact_top_logit_tie_keys'], ['0', '5'])

    def test_ties_retain_actual_candidate_vector_order(self):
        engine = SyntheticEngine([2.0, 2.0])
        answer = engine.evaluate_request({'candidates': ['A', 'B']}, ['z', 'a'], 'choice')
        self.assertEqual(answer['typed_value'], 'z')
        self.assertEqual(answer['exact_top_logit_tie_keys'], ['z', 'a'])


if __name__ == '__main__':
    unittest.main()
