"""Measurement-integrity and semantic-alignment fixtures; no model or network."""
import copy
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("robustness_analyze", Path(__file__).with_name("analyze.py"))
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)


def measurement(index=0, item="item1", condition="baseline", dataset="JCoLA",
                keys=None, probabilities=None, label=None, gold=None, split="in_domain_valid"):
    keys = keys or ([str(i) for i in range(6)] if dataset == "JSTS" else ["false", "true"])
    if probabilities is None:
        probabilities = {k: (0.2 if k == "false" else 0.8) for k in keys}
    label = label or max(probabilities, key=probabilities.get)
    kind = "score" if dataset == "JSTS" else "noul" if dataset == "JCoLA" else "choice"
    row = dict(request_index=index, item_id=item, dataset=dataset, type=kind, group="source1", split=split,
               condition=condition, candidate_keys=keys, probabilities=probabilities,
               logits=[math.log(probabilities[k]) if probabilities[k] else -1000.0 for k in keys],
               label=label, request_sha256="0" * 64, input_tokens=123,
               output_tokens=0, native_decode_count=1, latency_ms=2.0, error=None,
               temperature=1.0, state_cleared=True, thinking_enabled=False)
    if kind == "score":
        row["score_values"] = {str(i): i for i in range(6)}
        row["gold_score"] = 2.7 if gold is None else gold
        row["typed_value"] = sum(probabilities[k] * row["score_values"][k] for k in keys)
    else:
        row["gold_label"] = gold or "true"
        row["typed_value"] = probabilities["true"] if kind == "noul" else label
    return row


def schedule(rows):
    measurements = ("probabilities", "logits", "label", "typed_value", "input_tokens",
                    "output_tokens", "native_decode_count", "latency_ms", "error")
    return [{k: v for k, v in row.items() if k not in measurements} for row in rows]


class AnalysisTests(unittest.TestCase):
    def test_reversed_token_vector_preserves_semantic_prediction(self):
        base = measurement()
        # Candidate A now means true; same semantic distribution must yield no flip.
        variant = measurement(index=1, condition="label_reverse", keys=["true", "false"])
        result = analysis.analyze([base, variant], schedule([base, variant]))
        self.assertEqual(result["summary"]["accounting"]["valid_requests"], 2)
        pair = result["paired_differences"][0]
        self.assertFalse(pair["label_flip"])
        self.assertEqual(pair["total_variation"], 0)
        self.assertEqual(pair["normalized_jensen_shannon"], 0)
        self.assertEqual(pair["p_true_delta"], 0)

    def test_positional_alignment_bug_is_rejected(self):
        row = measurement(keys=["true", "false"])
        row["logits"] = list(reversed(row["logits"]))
        self.assertIn("probabilities_do_not_match_t1_logits", analysis.validate_row(row))
        row = measurement()
        row["label"] = "false"
        self.assertIn("label_not_canonical_argmax", analysis.validate_row(row))

    def test_real_semantic_flip_and_correctness_transitions(self):
        base = measurement(probabilities={"false": 0.01, "true": 0.99})
        variant = measurement(index=1, condition="display_reverse", probabilities={"true": 0.02, "false": 0.98})
        result = analysis.analyze([base, variant], schedule([base, variant]))
        pair = result["paired_differences"][0]
        self.assertTrue(pair["label_flip"])
        self.assertTrue(pair["correct_to_incorrect"])
        self.assertFalse(pair["incorrect_to_correct"])
        self.assertAlmostEqual(pair["p_true_delta"], -0.97)
        self.assertAlmostEqual(pair["total_variation"], 0.97)
        self.assertEqual(len(result["high_max_probability_flips"]), 1)

    def test_zero_probabilities_and_equal_distributions(self):
        self.assertEqual(analysis.divergences({"a": 1.0, "b": 0.0}, {"b": 1.0, "a": 0.0}), (1.0, 1.0))
        self.assertEqual(analysis.divergences({"a": 0.5, "b": 0.5}, {"b": 0.5, "a": 0.5}), (0.0, 0.0))
        row = measurement(probabilities={"false": 0.0, "true": 1.0})
        self.assertEqual(analysis.validate_row(row), [])
        tie = measurement(keys=["true", "false"], probabilities={"false": 0.5, "true": 0.5}, label="true")
        self.assertEqual(analysis.validate_row(tie), [])

    def test_direct_readout_contract_is_independently_checked(self):
        for field, value, code in [
            ("input_tokens", 2049, "input_tokens_outside_1_to_2048"),
            ("output_tokens", 1, "direct_readout_output_tokens_must_be_zero"),
            ("native_decode_count", 2, "native_decode_count_must_be_one_prefill"),
            ("state_cleared", False, "state_not_cleared"),
            ("thinking_enabled", True, "thinking_must_be_disabled"),
            ("temperature", 0.5, "temperature_must_be_one")]:
            row = measurement()
            row[field] = value
            self.assertIn(code, analysis.validate_row(row))

    def test_ties_follow_actual_candidate_vector_order(self):
        row = measurement(keys=["false", "true"], probabilities={"false": .5, "true": .5}, label="true")
        self.assertIn("label_not_first_candidate_vector_argmax", analysis.validate_row(row))
        row["label"] = "false"
        self.assertNotIn("label_not_first_candidate_vector_argmax", analysis.validate_row(row))

    def test_tie_flips_are_distinguished_from_distribution_changes(self):
        base = measurement(probabilities={"false": 0.5, "true": 0.5}, label="false")
        variant = measurement(index=1, condition="label_reverse", keys=["true", "false"],
                              probabilities={"false": 0.5, "true": 0.5}, label="true")
        result = analysis.analyze([base, variant], schedule([base, variant]))
        pair = result["paired_differences"][0]
        self.assertTrue(pair["label_flip"])
        self.assertTrue(pair["tie_associated_flip"])
        self.assertEqual(pair["total_variation"], 0)
        self.assertTrue(pair["canonical_probabilities_exact_equal"])
        self.assertEqual(pair["baseline_top_logit_tie_candidates"], 2)

    def test_jsts_uses_continuous_gold_and_explicit_original_scale(self):
        probs = {str(i): 0.0 for i in range(6)}
        probs.update({"2": 0.75, "3": 0.25})
        base = measurement(dataset="JSTS", probabilities=probs)
        reverse = measurement(index=1, condition="display_reverse", dataset="JSTS", keys=list(reversed(list(probs))), probabilities=probs)
        result = analysis.analyze([base, reverse], schedule([base, reverse]))
        metrics = result["summary"]["per_dataset"][0]
        self.assertAlmostEqual(metrics["expected_score_mae"], 0.45)
        self.assertAlmostEqual(metrics["hard_label_mae"], 0.7)
        self.assertNotIn("accuracy", metrics)
        self.assertEqual(result["paired_differences"][0]["expected_score_absolute_delta"], 0)
        wrong_scale = copy.deepcopy(base)
        wrong_scale["score_values"] = {k: v/5 for k, v in wrong_scale["score_values"].items()}
        self.assertIn("jsts_scale_must_be_0_to_5", analysis.validate_row(wrong_scale))
        wrong_output = copy.deepcopy(base)
        wrong_output["typed_value"] = 2
        self.assertIn("typed_value_not_expected_score", analysis.validate_row(wrong_output))

    def test_missing_and_failed_requests_preserve_denominators(self):
        base = measurement()
        variant = measurement(index=1, condition="display_reverse")
        repeat = measurement(index=2, condition="baseline_repeat")
        planned = schedule([base, variant, repeat])
        variant["error"] = "PRIVATE SOURCE TEXT MUST NOT BE COPIED"
        result = analysis.analyze([base, variant], planned)
        accounting = result["summary"]["accounting"]
        self.assertEqual(accounting["scheduled_requests"], 3)
        self.assertEqual(accounting["valid_requests"], 1)
        self.assertEqual(accounting["unavailable_scheduled_requests"], 2)
        self.assertEqual(accounting["scheduled_status_counts"]["inference_error"], 1)
        self.assertEqual(accounting["scheduled_status_counts"]["missing_prediction"], 1)
        self.assertNotIn("PRIVATE SOURCE TEXT", json.dumps(result))
        for comparison in result["summary"]["condition_differences"]:
            self.assertEqual(comparison["n_eligible_pairs"], 1)
            self.assertEqual(comparison["n_complete_pairs"], 0)
            self.assertIsNone(comparison["label_flip_rate"])

    def test_duplicates_are_not_silently_chosen(self):
        base = measurement()
        variant = measurement(index=1, condition="display_reverse")
        result = analysis.analyze([base, variant, copy.deepcopy(variant)], schedule([base, variant]))
        self.assertEqual(result["summary"]["accounting"]["valid_requests"], 1)
        self.assertEqual(result["summary"]["accounting"]["scheduled_status_counts"]["duplicate_request_index"], 1)
        self.assertEqual(result["summary"]["condition_differences"][0]["n_incomplete_pairs"], 1)
        other_index = copy.deepcopy(variant)
        other_index["request_index"] = 2
        result = analysis.analyze([base, variant, other_index], schedule([base, variant]))
        self.assertEqual(result["summary"]["accounting"]["valid_requests"], 1)
        self.assertIn("duplicate_item_condition", result["summary"]["accounting"]["failure_code_counts"])
        self.assertIn("unscheduled_prediction", result["summary"]["accounting"]["failure_code_counts"])

    def test_exact_repeat_hash_mismatch_is_not_a_valid_control_pair(self):
        base = measurement()
        repeat = measurement(index=1, condition="baseline_repeat")
        repeat["request_sha256"] = "1" * 64
        result = analysis.analyze([base, repeat], schedule([base, repeat]))
        self.assertEqual(result["summary"]["accounting"]["valid_requests"], 2)
        self.assertEqual(result["summary"]["condition_differences"][0]["n_complete_pairs"], 0)
        self.assertIn("baseline_repeat_prompt_hash_mismatch", str(result["failures"]))

    def test_gold_changes_are_integrity_failure_not_model_error(self):
        base = measurement()
        variant = measurement(index=1, condition="display_reverse", gold="false")
        result = analysis.analyze([base, variant], schedule([base, variant]))
        self.assertEqual(result["summary"]["accounting"]["valid_requests"], 0)
        self.assertEqual(result["summary"]["accounting"]["scheduled_status_counts"], {"inconsistent_item_metadata": 2})

    def test_jcola_mcc_and_domain_splits_remain_separate(self):
        base1 = measurement(gold="true")
        base2 = measurement(index=1, item="item2", probabilities={"false": .8, "true": .2}, gold="false", split="out_of_domain_valid")
        base2["group"] = "source2"
        result = analysis.analyze([base1, base2], schedule([base1, base2]))
        combined = result["summary"]["per_dataset"][0]
        self.assertEqual(combined["mcc"], 1)
        self.assertEqual(combined["accuracy"], 1)
        self.assertEqual(combined["unique_groups"], 2)
        self.assertEqual(len(result["summary"]["per_split"]), 2)
        self.assertTrue(all(row["n_valid"] == 1 for row in result["summary"]["per_split"]))
        self.assertTrue(all(row["mcc"] is None for row in result["summary"]["per_split"]))

    def test_cli_writes_traceable_outputs_and_reads_both_schedule_formats(self):
        rows = [measurement(), measurement(index=1, condition="display_reverse", keys=["true", "false"])]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            predictions = root / "predictions.jsonl"
            predictions.write_text("\n".join(json.dumps(r) for r in rows), encoding="utf-8")
            planned = root / "schedule.json"
            planned.write_text(json.dumps(schedule(rows)), encoding="utf-8")
            subprocess.run([sys.executable, str(Path(__file__).with_name("analyze.py")), "--predictions", str(predictions),
                            "--schedule", str(planned), "--output", str(root / "output")], check=True, capture_output=True, text=True)
            summary = json.loads((root / "output" / "SUMMARY.json").read_text())
            self.assertEqual(summary["accounting"]["valid_requests"], 2)
            self.assertEqual(len(summary["input_files"]["predictions_sha256"]), 64)
            self.assertTrue((root / "output" / "request_accounting.csv").exists())
            planned.write_text("\n".join(json.dumps(r) for r in schedule(rows)), encoding="utf-8")
            self.assertEqual(len(analysis.read_records(planned)), 2)


if __name__ == "__main__":
    unittest.main()
