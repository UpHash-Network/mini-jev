function process(response) {
  const raw = JSON.parse(response.text);
  const byId = new Map(raw.calls.map(c => [c.id, c]));
  const aligned = id => {
    const c = byId.get(id);
    if (!c) throw new Error('Unknown physical call: ' + id);
    return raw.canonical_keys.map(k => c.probabilities[c.display_order.indexOf(k)]);
  };
  const average = members => raw.canonical_keys.map((_,i) => members.reduce((sum,id) => sum+aligned(id)[i],0)/members.length);
  const a=average(raw.a_members), b=average(raw.b_members);
  const intersection=raw.a_members.filter(id=>raw.b_members.includes(id));
  const union=[...new Set([...raw.a_members,...raw.b_members])].sort();
  const output={case_id:raw.case_id,canonical_keys:raw.canonical_keys,a,b,delta:b.map((p,i)=>p-a[i]),shared_physical_calls:intersection.length,unique_physical_calls:union.length,physical_ids:union,processor_execution:'native-chainforge-js'};
  console.log('Processed raw input ' + raw.case_id);
  return {text:JSON.stringify(output),metavars:{case_id:raw.case_id,computed_by:'native JavaScript Processor'}};
}
